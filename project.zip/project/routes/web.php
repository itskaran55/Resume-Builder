<?php

use GuzzleHttp\Middleware;
use Illuminate\Support\Facades\Route;
use App\Models\rdetails;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//adminLogin page

Route::get('adminLogin',function(){
    return view('adminLogin');
});

//noAccess page

Route::get('restrictedpage',function(){
    return view('restrictedpage');
});

//adminDashboard page

Route::get('adminDashboard',function(){
    return view('adminDashboard');
});

//Main Page of website Index page

Route::get('resumebuilder',function(){
    return view('resumebuilder');
});

Route::get('resumeuploadform',function(){
    return view('resumeuploadform');
});

Route::post('resumeuploadform','\App\Http\Controllers\search_resume_details@insert_rdetails');

// search_data view

Route::get('search_resume_data','\App\Http\Controllers\search_resume_details@search');

// search_registration_data view

Route::get('search_registration_data','\App\Http\Controllers\login_controller@registration_serach');

// Login

Route::post("userLogin",'App\Http\Controllers\login_controller@index');

Route::get('userLogin',function(){
    if(session()->has('username'))
    {
        return redirect('resumebuilder');
    }
    return view('userLogin');
});

Route::get('home1',function(){
    return view('home1');
});

Route::get('home',function(){
    return view('home');
});

//Register

Route::post("userRegister",'App\Http\Controllers\login_controller@insert_data');

Route::get('userRegister',function(){
    return view('userRegister');
});

//Logout

Route::get('logout', function () {
    if(session()->has('username'))
    {
        session()->pull('username');
    }
    return redirect('resumebuilder');
});

//Delete Operation in Resume Details

Route::get('Delete/{id}','\App\Http\Controllers\search_resume_details@Delete');

//Edit Operation in Resume Details

Route::get('EditResume/{id}','\App\Http\Controllers\search_resume_details@Edit');

Route::PUT('editresume','\App\Http\Controllers\search_resume_details@Update');

//Delete Operation in Registration

Route::get('Delete/{id}','\App\Http\Controllers\login_controller@Delete');

//Edit Operation in Registration

Route::get('Edit/{id}','\App\Http\Controllers\login_controller@Edit');

Route::PUT('edit','\App\Http\Controllers\login_controller@Update');

//AdminPage

Route::get('AdminPage',function(){
    return view('AdminPage');
});

//Resume Template 1
Route::get('ResumeTemp1','\App\Http\Controllers\resumetemp1@rtemp1');

//ResumeTemplateUpload

Route::post('/ResumeTemplateUpload','\App\Http\Controllers\resumetemplateupload@store');
Route::get('/ResumeTemplateUpload','\App\Http\Controllers\resumetemplateupload@upload');

//resumetemplates

Route::get('/resumetemplates','\App\Http\Controllers\resumetemplateupload@search');

Route::get('Delete/{id}','\App\Http\Controllers\resumetemplateupload@Delete');

// Route::get('/resumetemplates', [resumetemplateupload::class, 'search']);
// Route::get('/resumetemplates/{id}', [resumetemplateupload::class, 'show'])->name('template.show');
// Route::get('/resumetemplates/{id}','\App\Http\Controllers\resumetemplateupload@show')->name('template.show');

// Resume1form

Route::post('resume1form','\App\Http\Controllers\resume1cntrl@insert_resume1');

Route::get('resume1form',function(){
    return view('resume1form');
});

Route::get('search_resume1_data','\App\Http\Controllers\resume1cntrl@search');

Route::get('Delete/{id}','\App\Http\Controllers\resume1cntrl@Delete');

Route::get('ResumeTemplate1','\App\Http\Controllers\resume1cntrl@rtemp1');