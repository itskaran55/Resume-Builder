<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateResume1Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('resume1', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('fullname');
            $table->string('address');
            $table->string('city');
            $table->integer('pincode');
            $table->string('email');
            $table->string('number');
            $table->string('professionalsummary');
            $table->string('firstjobfiled');
            $table->string('firstyourrole');
            $table->string('firstcity');
            $table->string('firststate');
            $table->string('firstdoj');
            $table->string('secondjobfiled');
            $table->string('secondyourrole');
            $table->string('secondcity');
            $table->string('secondstate');
            $table->string('seconddoj');
            $table->string('schoolname');
            $table->string('schoolcity');
            $table->string('schoolstate');
            $table->string('xpr');
            $table->string('passingyearx');
            $table->string('xiipr');
            $table->string('passingyearxii');
            $table->string('collegename');
            $table->string('collegecity');
            $table->string('collegestate');
            $table->string('fieldofstudy');
            $table->string('degree');
            $table->string('skill1');
            $table->string('skill2');
            $table->string('skill3');
            $table->string('skill4');
            $table->string('skill5');
            $table->string('hobby1');
            $table->string('hobby2');
            $table->string('hobby3');
            $table->string('hobby4');
            $table->string('hobby5');
            $table->string('language1');
            $table->string('language2');
            $table->string('language3');
            $table->string('language4');
            $table->string('language5');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('resume1');
    }
}
