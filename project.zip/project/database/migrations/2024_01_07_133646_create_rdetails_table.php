<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRdetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rdetails', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('fname');
            $table->string('address');
            $table->string('city');
            $table->string('email');  
            $table->string('professionalsummary');  
            $table->string('lname');  
            $table->string('country');  
            $table->string('phone');  
            $table->string('sname');  
            $table->string('schoolstate');  
            $table->string('fos');  
            $table->string('scity');  
            $table->string('degreename');  
            $table->date('graduationdate');  
            $table->string('tskill');  
            $table->string('askill');  
            $table->string('lskill');  
            $table->string('topskilllevel');  
            $table->string('averageskilllevel');  
            $table->string('lawskilllevel');  
            $table->string('ename');  
            $table->string('ecity');  
            $table->date('startdate');  
            $table->string('jobtitle');  
            $table->string('jobstate');  
            $table->date('enddate');  
    
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rdetails');
    }
}
