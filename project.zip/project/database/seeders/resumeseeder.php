<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class resumeseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('rdetails')->insert([
            'id'=>1,
            'name'=>'Karan',
            'jobtitle'=>'WebDevloper',
            'no'=>'9924069118',
            'email'=>'rajeshpt248@gmail.com',
            'discription'=>'i am eager to apply this job',
            'school'=>'Navyug Vidhyalaya',
            'college'=>'Lj University',
            'experience'=>'Freshers',
            'additionalskills'=>'Singing'
        ]);
    }
}
