<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="{{asset('userLogin.css')}}">
</head>
<body>
    <section>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
            
        <form action="/edit" method="post" class="login">
        {{method_field('PUT')}}
            @csrf
            <div class="content">
                <h2>Update Form</h2>
                <div class="form">
                    <div class="inputBx">
                        <input type="hidden" required name="id" value="{{$data['id']}}">    
                        <!-- <i>Id</i> -->
                    </div>
                    <div class="inputBx">
                        <input type="text" required name="fullname" value="{{$data['fullname']}}">    
                        <i>FullName</i>
                    </div>
                    <div class="inputBx">
                        <input type="text" required name="username" value="{{$data['username']}}">    
                        <i>Username</i>
                    </div>
                    <!-- <div class="inputBx">
                        <input type="Password" name="password" value="{{$data['password']}}">    
                        <i>Password</i>
                    </div> -->
                    <div class="inputBx">
                        <input type="submit" value="Edit" name="Edit">
                    </div>
                </div>
            </div>
        </form>
        </div>
    </section>
</body>
</html>




<!-- <form action="/edit" method="post" >
{{method_field('PUT')}}
    @csrf
    <input type="hidden" name="id" value="{{$data['id']}}"/><br>
    Name:<input type="text" name="name" value="{{$data['fullname']}}"/><br>
    Username:<input type="text" name="name" value="{{$data['username']}}"/><br>
    Password:<input type="password" name="password" value="{{$data['password']}}"/><br>
    <input type="submit" name="Edit" value="Edit"/><br>
</form> -->