<!-- resources/views/resumetemplates/index.blade.php -->

@extends('layouts.app')

@section('content')
    <h1 style="color: white;">Resume Templates</h1>
    <div class="container">
        @foreach($image as $img)
            <div class="main">
                <a href="{{ route('template.show'}}">
                    <img style="height: 200px; width:200px;" src="{{ asset('storage/images/'.$img->templatename) }}">
                </a>
            </div>
        @endforeach
    </div>
@endsection

