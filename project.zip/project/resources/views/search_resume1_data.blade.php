<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">Resume Template-1 Details</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                        <th>Sr. No</th>
                        <th>Full Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Pincode</th>
                        <th>Email Address</th>
                        <th>Number</th>
                        <th>Professional Summary</th>
                        <th>First Job Field</th>
                        <th>First Job Role</th>
                        <th>First Job City</th>
                        <th>First Job State</th>
                        <th>First Job Joining Date</th>
                        <th>Second Job Field</th>
                        <th>Second Job Role</th>
                        <th>Second Job City</th>
                        <th>Second Job State</th>
                        <th>Second Job Joining Date</th>
                        <th>School Name</th>
                        <th>School City</th>
                        <th>School State</th>
                        <th>10th PR</th>
                        <th>10th Passing Year</th>
                        <th>12th PR</th>
                        <th>12th Passing Year</th>
                        <th>College Name</th>
                        <th>College City</th>
                        <th>College State</th>
                        <th>Filed of Study</th>
                        <th>Degree</th>
                        <th>Skills 1</th>
                        <th>Skills 2</th>
                        <th>Skills 3</th>
                        <th>Skills 4</th>
                        <th>Skills 5</th>
                        <th>Hobby 1</th>
                        <th>Hobby 2</th>
                        <th>Hobby 3</th>
                        <th>Hobby 4</th>
                        <th>Hobby 5</th>
                        <th>Language 1</th>
                        <th>Language 2</th>
                        <th>Language 3</th>
                        <th>Language 4</th>
                        <th>Language 5</th>
                        <!-- <th>Edit</th> -->
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($info as $in)
                    <tr>
                        <!-- <td>{{$in['id']}}</td> -->
                        <td>{{$loop->iteration}}</td>
                        <td>{{$in['fullname']}}</td>
                        <td>{{$in['address']}}</td>
                        <td>{{$in['city']}}</td>
                        <td>{{$in['pincode']}}</td>
                        <td>{{$in['email']}}</td>
                        <td>{{$in['number']}}</td>
                        <td>{{$in['professionalsummary']}}</td>
                        <td>{{$in['firstjobfiled']}}</td>
                        <td>{{$in['firstyourrole']}}</td>
                        <td>{{$in['firstcity']}}</td>
                        <td>{{$in['firststate']}}</td>
                        <td>{{$in['firstdoj']}}</td>
                        <td>{{$in['secondjobfiled']}}</td>
                        <td>{{$in['secondyourrole']}}</td>
                        <td>{{$in['secondcity']}}</td>
                        <td>{{$in['secondstate']}}</td>
                        <td>{{$in['seconddoj']}}</td>
                        <td>{{$in['schoolname']}}</td>
                        <td>{{$in['schoolcity']}}</td>
                        <td>{{$in['schoolstate']}}</td>
                        <td>{{$in['xpr']}}</td>
                        <td>{{$in['passingyearx']}}</td>
                        <td>{{$in['xiipr']}}</td>
                        <td>{{$in['passingyearxii']}}</td>
                        <td>{{$in['collegename']}}</td>
                        <td>{{$in['collegecity']}}</td>
                        <td>{{$in['collegestate']}}</td>
                        <td>{{$in['fieldofstudy']}}</td>
                        <td>{{$in['degree']}}</td>
                        <td>{{$in['skill1']}}</td>
                        <td>{{$in['skill2']}}</td>
                        <td>{{$in['skill3']}}</td>
                        <td>{{$in['skill4']}}</td>
                        <td>{{$in['skill5']}}</td>
                        <td>{{$in['hobby1']}}</td>
                        <td>{{$in['hobby2']}}</td>
                        <td>{{$in['hobby3']}}</td>
                        <td>{{$in['hobby4']}}</td>
                        <td>{{$in['hobby5']}}</td>
                        <td>{{$in['language1']}}</td>
                        <td>{{$in['language2']}}</td>
                        <td>{{$in['language3']}}</td>
                        <td>{{$in['language4']}}</td>
                        <td>{{$in['language5']}}</td>                        
                        <!-- <td><a href="EditResume/{{$in['id']}}">Edit</a></td> -->
                        <td><a href="Delete/{{$in['id']}}">Delete</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>
