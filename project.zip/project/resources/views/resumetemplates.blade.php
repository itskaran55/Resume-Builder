<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Templates</title>
    <link rel="stylesheet" href="{{asset('resumetemplatestyle.css')}}">
</head>
<body>
    <h1 style="color: white;">Resume Templates</h1>
    <div class="container">
        @foreach($image as $img)
        <div class="main">
            <p><img style="height: 500px; width:340px;" src="{{asset('storage/images/'.$img->templatename)}}"></p>
            <!-- <p>{{ asset('storage/images/'.$img->templatename) }}</p> -->

            <!-- <td><a href="Edit/{{$img['id']}}">Edit</a></td> -->
            <td><a href="Delete/{{$img['id']}}">Delete</a></td>
        </div>
        @endforeach
    </div>
</body>
</html>