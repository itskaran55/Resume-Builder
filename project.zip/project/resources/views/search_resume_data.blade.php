<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">Resume Details</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                   
                        <th>Sr. No</th>
                        <th>First Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Email Address</th>
                        <th>Professional Summary</th>
                        <th>Last Name</th>
                        <th>Country</th>
                        <th>Phone</th>
                        <th>School Name</th>
                        <th>School State</th>
                        <th>Filed of Study</th>
                        <th>School City</th>
                        <th>Degree Name</th>
                        <th>Graduation Date</th>
                        <th>Top Skill</th>
                        <th>Average Skill</th>
                        <th>Law Skill</th>
                        <th>Top Skill Level</th>
                        <th>Average Skill Level</th>
                        <th>Law Skill Level</th>
                        <th>Employer</th>
                        <th>City</th>
                        <th>Start Date</th>
                        <th>Job Title</th>
                        <th>Job State</th>
                        <th>End Date</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($info as $in)
                    <tr>
                        <!-- <td>{{$in['id']}}</td> -->
                        <td>{{$loop->iteration}}</td>
                        <td>{{$in['fname']}}</td>
                        <!-- <td><h5>{{$in['fname']}} {{$in[ 'lname']}}<h5><//td> -->
                        <td>{{$in['address']}}</td>
                        <td>{{$in['city']}}</td>
                        <td>{{$in['email']}}</td>
                        <td>{{$in['professionalsummary']}}</td>
                        <td>{{$in['lname']}}</td>
                        <td>{{$in['country']}}</td>
                        <td>{{$in['phone']}}</td>
                        <td>{{$in['sname']}}</td>
                        <td>{{$in['schoolstate']}}</td>
                        <td>{{$in['fos']}}</td>
                        <td>{{$in['scity']}}</td>
                        <td>{{$in['degreename']}}</td>
                        <td>{{$in['graduationdate']}}</td>
                        <td>{{$in['tskill']}}</td>
                        <td>{{$in['askill']}}</td>
                        <td>{{$in['lskill']}}</td>
                        <td>{{$in['topskilllevel']}}</td>
                        <td>{{$in['averageskilllevel']}}</td>
                        <td>{{$in['lawskilllevel']}}</td>
                        <td>{{$in['ename']}}</td>
                        <td>{{$in['city']}}</td>
                        <td>{{$in['startdate']}}</td>
                        <td>{{$in['jobtitle']}}</td>
                        <td>{{$in['jobstate']}}</td>
                        <td>{{$in['enddate']}}</td>
                        <td><a href="EditResume/{{$in['id']}}">Edit</a></td>
                        <td><a href="Delete/{{$in['id']}}">Delete</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>
