<h1>Welcome to Home page</h1>
<h2>Hello, {{session('fullname')}}</h2>

<a href="logout">Logout</a>