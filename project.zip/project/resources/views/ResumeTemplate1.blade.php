<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Template 1</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Hedvig+Letters+Serif:opsz@12..24&family=Mooli&family=Nunito+Sans:opsz,wght@6..12,300&family=Poppins:wght@300;500&display=swap');
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            list-style: none;
        }
        body
        {
            background-color: rgba(28, 29, 47, 0.92);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        body::after
        {
            position: absolute;
            content: '';
            height: 170px;
            width: 170px;
            background: linear-gradient(rgba(156, 48, 19, 0.6),rgba(138, 17, 186, 0.305));
            border-radius: 50%;
            bottom: 75%;
            left: 27%; 
        }
        body::before
        {
            position: absolute;
            content: '';
            height: 170px;
            width: 170px;
            background: linear-gradient(rgba(37, 156, 19, 0.341),rgba(186, 17, 37, 0.305));
            border-radius: 50%;
            top: 110%;
            right: 25%; 
        }
        .container
        {
            z-index: 2;
            height: 135vh;
            width: 600px;
            border: 2px solid black;
            padding: 15px 22px;
            background: rgba(211, 211, 211, 0.11);
            box-shadow: 2px 2px 30px rgba(0, 0, 0, 0.5),
                        -2px -2px 30px rgba(0, 0, 0, 0.5);
            transition: 0.5s; 
            color: white;
        }
        .container:hover
        {
            backdrop-filter: blur(7px);
            box-shadow:  20px 20px 50px rgba(0, 0, 0, 0.5),
                        -20px -20px 50px rgba(0, 0, 0, 0.5);
            border-radius: 18px;
        }
        .personalinfo
        {
            background-color: rgba(243, 121, 32, 1);
            padding: 10px 12px;
        }
        .part1,.part2,.part3
        {
            display: flex;
            justify-content: space-between;
        }
        .skills
        {
            margin-right: 60px;
        }
        .hobbies
        {
            margin-right: 30px;
        }
        .languages
        {
            margin-right: 10px;
        }
        .download
        {
            margin-left: 300px;
            margin-top: -15px;
        }
        .download a
        {
            text-decoration: none;
            background-color: wheat;
            padding: 10px 12px;
            border-radius: 10px;
            color: black;
            font-weight: bold;
        }
    </style>
</head>
<body>
    @if ($info->isNotEmpty())
        <div class="container">
            <div class="personalinfo">
                <h1>{{ $info->last()['fullname']}}</h1><br>
                <strong>Address : </strong>{{$info->last()['address'].','.$info->last()['city'].'-'.$info->last()['pincode']}}<br>
                <strong>Email : </strong>{{$info->last()['email']}}<br>
                <strong>Contact : </strong>+91 {{$info->last()['number']}}<br>
            </div>
            <hr>
            <div class="part1">
                <div class="pf">
                    <h3>Professional Summary:-</h3><br>
                    <p>{{$info->last()['professionalsummary']}}</p>
                </div>
                <div class="skills">
                    <h3>Skills:-</h3><br>
                    <p>{{$info->last()['skill1']}}</p>
                    <p>{{$info->last()['skill2']}}</p>
                    <p>{{$info->last()['skill3']}}</p>
                    <p>{{$info->last()['skill4']}}</p>
                    <p>{{$info->last()['skill5']}}</p>
                </div>
            </div><br>
            <div class="part2">
                <div class="ehistory">
                    <h3>Employement History:-</h3><br>
                    <p><Strong>1 : </Strong>{{$info->last()['firstjobfiled'].','.$info->last()['firstyourrole'].','.$info->last()['firstcity'].','.$info->last()['firststate']}}</p>
                    <p><strong>Date of Joining : </strong>{{$info->last()['firstdoj']}}</p><br><br>
                    <p><Strong>2 : </Strong>{{$info->last()['secondjobfiled'].','.$info->last()['secondyourrole'].','.$info->last()['secondcity'].','.$info->last()['secondstate']}}</p>
                    <p><strong>Date of Joining : </strong>{{$info->last()['seconddoj']}}</p><br><br>
                </div>
                <div class="hobbies">
                    <h3>Hobbies:-</h3><br>
                    <p>{{$info->last()['hobby1']}}</p>
                    <p>{{$info->last()['hobby2']}}</p>
                    <p>{{$info->last()['hobby3']}}</p>
                    <p>{{$info->last()['hobby4']}}</p>
                    <p>{{$info->last()['hobby5']}}</p>
                </div>
            </div>
            <div class="part3">
                <div class="education">
                    <h3>Education:-</h3><br>
                    <p><strong>School Name : </strong>{{$info->last()['schoolname'].','.$info->last()['schoolcity'].','.$info->last()['schoolstate']}}</p>
                    <p><strong>10th PR : </strong>{{$info->last()['xpr'].'%'.' , '.$info->last()['passingyearx']}}</p>
                    <p><strong>12th PR : </strong>{{$info->last()['xiipr'].'%'.' , '.$info->last()['passingyearxii']}}</p><br><br>
                    <p><strong>College Name : </strong>{{$info->last()['collegename'].','.$info->last()['collegecity'].','.$info->last()['collegestate']}}</p>
                    <p><strong>Field of Study : </strong>{{$info->last()['fieldofstudy']}}</p>
                    <p><strong>Degree : </strong>{{$info->last()['degree']}}</p><br><br>
                </div>
                <div class="languages">
                    <h3>Languages:-</h3><br>
                    <p>{{$info->last()['language1']}}</p>
                    <p>{{$info->last()['language2']}}</p>
                    <p>{{$info->last()['language3']}}</p>
                    <p>{{$info->last()['language4']}}</p>
                    <p>{{$info->last()['language5']}}</p>
                </div>
            </div>
            <div class="download">
                <a href="http://127.0.0.1:8000/ResumeTemplate1" download="ResumeTemplate1.pdf">Download Resume</a>
            </div>
        </div>
    @else
    <p>No data available</p>
    @endif
</body>
</html>