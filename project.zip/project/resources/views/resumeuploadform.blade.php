<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>resumeuploadform</title>
    <link rel="stylesheet" href="{{asset('resumedesignform.css')}}">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <h2><a href="#">Resume</a></h2>
            </div>
            <div class="links">
                <ul>
                    <li><a href="#page1">Personal Information</a></li>
                    <li><a href="#page2">Education</a></li>
                    <li><a href="#page3">Skills</a></li>
                    <li><a href="#page4">Experience</a></li>
                </ul>
            </div>
        </div>
        <form action="/resumeuploadform" method="post">
            @csrf
            <section class="information" id="page1">
                <div class="form1">
                    <h1>Personal Infromation</h1>
                        <div class="left1">
                            <span>First Name : </span><br>
                            <input type="text" name="fname" class="fname"/><br><br>
                            <span>Address : </span><br>
                            <textarea type="text" name="address"></textarea><br><br>
                            <span>City : </span><br>
                            <input type="text" name="city"/><br><br>
                            <span>Email Address : </span><br>
                            <input type="text" name="email"/><br><br>
                            <span>Professional Summary : </span><br>
                            <textarea name="professionalsummary"></textarea><br><br>
                        </div>
                        <div class="right1">
                            <span>Last Name : </span><br>
                            <input type="text" name="lname"/><br><br>
                            <span>Country : </span><br>
                            <input type="text" name="country"><br><br>
                            <!-- <span>City : </span><br>
                            <input type="text" name="city"/><br><br> -->
                            <span>Phone : </span><br>
                            <input type="number" name="phone"/><br><br>
                        </div>
                </div>
            </section>
            <section class="education" id="page2">
                <div class="form2">
                <h1>Education</h1>
                        <div class="left4">
                            <span>School Name : </span><br>
                            <input type="text" name="sname" class="sname"/><br><br>
                            <span>School State : </span><br>
                            <input type="text" name="schoolstate"></input><br><br>
                            <span>Filed of Study : </span><br>
                            <input type="text" name="fos"/><br><br>
                        </div>
                        <div class="right4">
                            <span>School City : </span><br>
                            <input type="text" name="scity"/><br><br>
                            <span>Degree Name : </span><br>
                            <input type="text" name="degreename"><br><br>
                            <span>Graduation Date : </span><br>
                            <input type="date" name="graduationdate"/><br><br>
                        </div>
                </div>
            </section>
            <section class="skills" id="page3">
                <div class="form3">
                <h1>Skills</h1>
                        <div class="left3">
                            <span>Top Skill : </span><br>
                            <input type="text" name="tskill" class="ename"/><br><br>
                            <span>Average Skill : </span><br>
                            <input type="text" name="askill"></input><br><br>
                            <span>Law Skill : </span><br>
                            <input type="text" name="lskill"/><br><br>
                        </div>
                        <div class="right3">
                            <span>Top Skill Level : </span><br>
                            <input type="text" name="topskilllevel"/><br><br>
                            <span>Average Skill Level : </span><br>
                            <input type="text" name="averageskilllevel"><br><br>
                            <span>Law Skill Level : </span><br>
                            <input type="text" name="lawskilllevel"/><br><br>
                        </div>  
                </div>
            </section>
            <section class="experience" id="page4">
                <div class="form4">
                <h1>Experience</h1>
                        <div class="left4">
                            <span>Employer : </span><br>
                            <input type="text" name="ename" class="ename"/><br><br>
                            <span>City : </span><br>
                            <input type="text" name="ecity"></input><br><br>
                            <span>Start Date : </span><br>
                            <input type="date" name="startdate"/><br><br>
                        </div>
                        <div class="right4">
                            <span>Job Title : </span><br>
                            <input type="text" name="jobtitle"/><br><br>
                            <span>Job State : </span><br>
                            <input type="text" name="jobstate"><br><br>
                            <span>End Date : </span><br>
                            <input type="date" name="enddate"/><br><br>
                            <input type="submit" value="Add">
                        </div>
                </div>
            </section>
        </form>
    </div>
</body>
</html>