<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">User Registration Data</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                        <th>Sr. No</th>
                        <th>Full Name</th>
                        <th>Username</th>
                        <th>Password</th>
                        <!-- <th>Confirm Password</th> -->
                        <th>Role</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($info as $in)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <!-- <td>{{$in['id']}}</td> -->
                        <td>{{$in['fullname']}}</td>
                        <td><strong>{{$in['username']}}</strong></td>
                        <td>{{$in['password']}}</td>
                        <!-- <td>{{$in['cpassword']}}</td> -->
                        <td>{{$in['role']}}</td>
                        <td><a href="Edit/{{$in['id']}}">Edit</a></td>
                        <td><a href="Delete/{{$in['id']}}">Delete</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>




