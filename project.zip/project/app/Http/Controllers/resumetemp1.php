<?php

namespace App\Http\Controllers;
use App\Models\rdetails;
use Illuminate\Http\Request;

class resumetemp1 extends Controller
{
    public function rtemp1()
    {
        $info= rdetails::all();
        return view('ResumeTemp1',['info'=>$info],compact('info'));
    }   
}
