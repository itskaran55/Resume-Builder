<?php

namespace App\Http\Controllers;
use App\Models\rdetails;
use Illuminate\Http\Request;

class search_resume_details extends Controller
{
    public function search()
    { 
        $info = rdetails::all();
        return view('search_resume_data',['info'=>$info]);
    }
    public function insert_rdetails(Request $req)
    {
        $rdetails = new rdetails();
        $rdetails->fname = request('fname');
        $rdetails->address = request('address');
        $rdetails->city = request('city');
        $rdetails->email = request('email');
        $rdetails->professionalsummary = request('professionalsummary');
        $rdetails->lname = request('lname');
        $rdetails->country = request('country');
        $rdetails->phone = request('phone');
        $rdetails->sname = request('sname');
        $rdetails->schoolstate = request('schoolstate');
        $rdetails->fos = request('fos');
        $rdetails->scity = request('scity');
        $rdetails->degreename = request('degreename');
        $rdetails->graduationdate = request('graduationdate');
        $rdetails->tskill = request('tskill');
        $rdetails->askill = request('askill');
        $rdetails->lskill = request('lskill');
        $rdetails->topskilllevel = request('topskilllevel');
        $rdetails->averageskilllevel = request('averageskilllevel');
        $rdetails->lawskilllevel = request('lawskilllevel');
        $rdetails->ename = request('ename');
        $rdetails->ecity = request('ecity');
        $rdetails->startdate = request('startdate');
        $rdetails->jobtitle = request('jobtitle');
        $rdetails->jobstate = request('jobstate');
        $rdetails->enddate = request('enddate');
        $id=$rdetails->save();
        if($id>0)
        {
            return redirect('ResumeTemp1');
        }
    }
    public function Delete($id)
    {
        $data = rdetails::find($id);
        $data->Delete();
        return redirect('search_resume_data');
    }
    public function Edit($id)
    {
        $data= rdetails::find($id);
        return view('editresumeData',['data'=>$data]);
    }
    public function Update(Request $req)
    {
        $data = rdetails::find($req->id);
        $data->fname = $req->fname;
        $data->address = $req->address;
        $data->city = $req->city;
        $data->email = $req->email;
        $data->lname = $req->lname;
        $data->country = $req->country;
        $data->phone = $req->phone;
        $data->sname = $req->sname;
        $data->schoolstate = $req->schoolstate;
        $data->fos = $req->fos;
        $data->scity = $req->scity;
        $data->degreename = $req->degreename;
        $data->graduationdate = $req->graduationdate;
        $data->tskill = $req->tskill;
        $data->askill = $req->askill;
        $data->lskill = $req->lskill;
        $data->topskilllevel = $req->topskilllevel;
        $data->averageskilllevel = $req->averageskilllevel;
        $data->lawskilllevel = $req->lawskilllevel;
        $data->ename = $req->ename;
        $data->ecity = $req->ecity;
        // $data->startdate = $req->startdate;
        $data->jobtitle = $req->jobtitle;
        $data->jobstate = $req->jobstate;
        // $data->enddate = $req->enddata;
        $data->save();
        return redirect('ResumeTemp1');
    }

    //Resume Template 1
   
}
