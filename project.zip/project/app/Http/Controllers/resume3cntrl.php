<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class resume3cntrl extends Controller
{
    //
}
