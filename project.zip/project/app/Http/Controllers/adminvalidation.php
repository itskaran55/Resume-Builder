<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class adminvalidation extends Controller
{
    //
    // public function validate()
    // {
    //     if(username == "admin1113@gmail.com" && password == "rarest_55")
    //     {
    //         return view('adminDashboard');
    //     }
    //     else
    //     {
    //         return view('restrictedpage');
    //     }
    // }
}
