<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\login;
use App\Models\rdetails;
use Illuminate\Support\Facades\Hash;

class login_controller extends Controller
{
    function index(Request $req)
    {
          $data=login::where('username',$req->username)->get();
          if($data->isNotEmpty())
          {
                if(Hash::check($req->password,$data[0]->password))
                {
                   if($data[0]->role=='user')
                   {
                       $req->session()->put('username',$data[0]->username);
                       return redirect('resumebuilder');
                   }
                   else if($data[0]->role=='admin')
                   {
                       $req->session()->put('username',$data[0]->username);
                       return redirect('adminDashboard');
                   }    
               }
               else{
                  return redirect()->back()->withErrors(['failure' => 'Invalid username or password']);
               }
          } 
    }
        
    public function insert_data(Request $req)
    {
        if($req->password==$req->cpassword)
        {
            $info=new login;    
            $info->fullname=$req->fullname;
            $info->username=$req->username;
            $info->password=Hash::make($req->password);
            // $info->password=Hash::make($req->cpassword);
            $id=$info->save();
            if($id>0)
            {
                $req->session()->put('username',$req->username);
                return redirect('resumebuilder');
            }
        }
        else
        {
            return redirect()->back()->withErrors(['failure' => 'Password and confirm password must be same']);;
        }
    }

    public function registration_serach()
    { 
        $info = login::all();
        return view('search_registration_data',['info'=>$info]);
    }

    public function Delete($id)
    {
        $data = login::find($id);
        $data->Delete();
        return redirect('search_registration_data');
    }

    public function Edit($id)
    {
        $data= login::find($id);
        return view('editloginData',['data'=>$data]);
    }
    public function Update(Request $req)
    {
        $data = login::find($req->id);
        $data->fullname = $req->fullname;
        $data->username = $req->username;
        // $data->password = $req->password;

        $data->save();
        return redirect('search_registration_data');
    }
}
