<?php

namespace App\Http\Controllers;

use App\Models\resumetempmodel;
use Illuminate\Http\Request;

class resumetemplateupload extends Controller
{
    public function upload()
    {
        return view('ResumeTemplateUpload');
    }
    public function store(Request $req)
    {
        $size = $req->file('image')->getSize();
        $templatename = $req->file('image')->getClientOriginalName();

        $req->file('image')->storeAs('public/images', $templatename);
        $img = new resumetempmodel;
        $img->templatename = $templatename;
        $img->size = $size;
        $img->save();
        return redirect("resumetemplates");
    }
    public function search()
    {
        $image= resumetempmodel::all();
        return view('resumetemplates',compact('image'));
    }
    public function Delete($id)
    {
        $data = resumetempmodel::find($id);
        $data->Delete();
        return redirect('resumetemplates');
    }

    // for indicating different images in Hover Links

    // public function show($id)
    // {
    //     $image = resumetempmodel::find($id);
    //     return view('resumetemplates', compact('image'));
    // }
}
