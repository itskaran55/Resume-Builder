<?php

namespace App\Http\Controllers;
use App\Models\resume1;
use Illuminate\Http\Request;

class resume1cntrl extends Controller
{
    //
    public function insert_resume1(Request $req)
    {
        $resume1= new resume1();
        $resume1->fullname = request('fullname');
        $resume1->address = request('address');
        $resume1->city = request('city');
        $resume1->pincode = request('pincode');
        $resume1->email = request('email');
        $resume1->number = request('number');
        $resume1->professionalsummary = request('professionalsummary');
        $resume1->firstjobfiled = request('firstjobfiled');
        $resume1->firstyourrole = request('firstyourrole');
        $resume1->firstcity = request('firstcity');
        $resume1->firststate = request('firststate');
        $resume1->firstdoj = request('firstdoj');
        $resume1->secondjobfiled = request('secondjobfiled');
        $resume1->secondyourrole = request('secondyourrole');
        $resume1->secondcity = request('secondcity');
        $resume1->secondstate = request('secondstate');
        $resume1->seconddoj = request('seconddoj');
        $resume1->schoolname = request('schoolname');
        $resume1->schoolcity = request('schoolcity');
        $resume1->schoolstate = request('schoolstate');
        $resume1->xpr = request('xpr');
        $resume1->passingyearx = request('passingyearx');
        $resume1->xiipr = request('xiipr');
        $resume1->passingyearxii = request('passingyearxii');
        $resume1->collegename = request('collegename');
        $resume1->collegecity = request('collegecity');
        $resume1->collegestate = request('collegestate');
        $resume1->fieldofstudy = request('fieldofstudy');
        $resume1->degree = request('degree');
        $resume1->skill1 = request('skill1');
        $resume1->skill2 = request('skill2');
        $resume1->skill3 = request('skill3');
        $resume1->skill4 = request('skill4');
        $resume1->skill5 = request('skill5');
        $resume1->hobby1 = request('hobby1');
        $resume1->hobby2 = request('hobby2');
        $resume1->hobby3 = request('hobby3');
        $resume1->hobby4 = request('hobby4');
        $resume1->hobby5 = request('hobby5');
        $resume1->language1 = request('language1');
        $resume1->language2 = request('language2');
        $resume1->language3 = request('language3');
        $resume1->language4 = request('language4');
        $resume1->language5 = request('language5');
        $id=$resume1->save();
        if($id>0)
        {
            return redirect('ResumeTemplate1');
        }
    }
    public function search()
    { 
        $info = resume1::all();
        return view('search_resume1_data',['info'=>$info]);
    }
    public function Delete($id)
    {
        $data = resume1::find($id);
        $data->Delete();
        return redirect('search_resume1_data');
    }
    public function rtemp1()
    {
        $info= resume1::all();
        return view('ResumeTemplate1',['info'=>$info],compact('info'));
    } 
}
