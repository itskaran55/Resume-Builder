<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class resumetempmodel extends Model
{
    public $table = "resumetempmodel";
    public $timestamps = false;
    use HasFactory;
}
