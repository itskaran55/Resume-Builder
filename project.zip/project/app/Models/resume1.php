<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class resume1 extends Model
{
    public $table = "resume1";
    public $timestamps = false;
    use HasFactory;
}
