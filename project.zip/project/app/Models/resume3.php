<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class resume3 extends Model
{
    public $table = "resume3";
    public $timestamps = false;
    use HasFactory;
}
