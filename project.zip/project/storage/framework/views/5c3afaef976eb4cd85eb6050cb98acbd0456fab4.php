<h1>Welcome to Home page</h1>
<h2>Hello, <?php echo e(session('fullname')); ?></h2>

<a href="logout">Logout</a><?php /**PATH L:\Sem-4\Website\project\resources\views/home.blade.php ENDPATH**/ ?>