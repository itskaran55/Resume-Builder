<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume 1 Form</title>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Hedvig+Letters+Serif:opsz@12..24&family=Mooli&family=Nunito+Sans:opsz,wght@6..12,300&family=Poppins:wght@300;500&display=swap');
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            text-decoration: none;
            list-style: none;
        }
        body
        {
            background-color: rgba(23, 31, 56, 1);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
            color: white;
            width: 110vw;
            font-family: 'Poppins', sans-serif;
        }
        .container
        {
            background-color: rgba(36, 46, 76, 1);
            height: 120vh;
            width: 100vw;
            box-shadow: 0 0 20px black;
        }
        input
        {
            padding: 7px 10px;
        }
        .text
        {
            text-align: center;
            margin: 10px 16px;
        }
        .info
        {
            display: flex;
            justify-content: space-around;
        }
        .submit
        {
            text-align: center;
        }
    </style>
</head>
<body>
    <form action="/resume1form" method="post">
        <?php echo csrf_field(); ?>
        <div class="container">
            <div class="text">
                <h1>Resume Details</h1>
            </div>
            <div class="info">
                <div class="firstside">
                    <div class="personalinfo">
                        <h2>Personal Infromation :-</h2>
                        Full Name : <input type="text" name="fullname"><br><br>
                        Address : <input type="text" name="address"><br><br>
                        City : <input type="text" name="city"><br><br>
                        Pincode : <input type="text" name="pincode"><br><br>
                        Email : <input type="email" name="email"><br><br>
                        Number : <input type="text" name="number"><br><br>
                        <span>Professional Summary : </span>
                        <textarea name="professionalsummary"></textarea>
                    </div>
                </div>
                <div class="secondside">
                    <h2>Job Details :-</h2>
                    Job Field : <input type="text" name="firstjobfiled"><br><br>
                    Job Role : <input type="text" name="firstyourrole"><br><br>
                    Job City : <input type="text" name="firstcity"><br><br>
                    Job State : <input type="text" name="firststate"><br><br>
                    Date of Joining : <input type="date" name="firstdoj"><br><br>
                    <h2>Past Job Deatils :-</h2>
                    Job Field : <input type="text" name="secondjobfiled"><br><br>
                    Job Role : <input type="text" name="secondyourrole"><br><br>
                    Job City : <input type="text" name="secondcity"><br><br>
                    Job State : <input type="text" name="secondstate"><br><br>
                    Date of Joining : <input type="date" name="seconddoj"><br><br>
                </div>
                <div class="thirdside">
                    <h3>Education :-</h3>
                    School Name : <input type="text" name="schoolname"><br><br>
                    School City : <input type="text" name="schoolcity"><br><br>
                    School State : <input type="text" name="schoolstate"><br><br>
                    10th PR : <input type="text" name="xpr"><br><br>
                    10th Passing Year : <input type="text" name="passingyearx"><br><br>
                    12th PR : <input type="text" name="xiipr"><br><br>
                    12th Passing Year : <input type="text" name="passingyearxii"><br><br>
                    College Name : <input type="text" name="collegename"><br><br>
                    College City : <input type="text" name="collegecity"><br><br>
                    College State : <input type="text" name="collegestate"><br><br>
                    Field of Study : <input type="text" name="fieldofstudy"><br><br>
                    Degree : <input type="text" name="degree"><br><br>
                </div>
                <div class="fourthside">
                    <h3>Additional Details :-</h3>
                    <h4>Skills :-</h4>
                    <input type="text" name="skill1"><br><br>
                    <input type="text" name="skill2"><br><br>
                    <input type="text" name="skill3"><br><br>
                    <input type="text" name="skill4"><br><br>
                    <input type="text" name="skill5"><br><br>
                    <h4>Languages :-</h4>
                    <input type="text" name="language1"><br><br>
                    <input type="text" name="language2"><br><br>
                    <input type="text" name="language3"><br><br>
                    <input type="text" name="language4"><br><br>
                    <input type="text" name="language5"><br><br>
                </div>
                <div class="fifthside">
                    <h4>Hobbies :-</h4>
                    <input type="text" name="hobby1"><br><br>
                    <input type="text" name="hobby2"><br><br>
                    <input type="text" name="hobby3"><br><br>
                    <input type="text" name="hobby4"><br><br>
                    <input type="text" name="hobby5"><br><br>
                </div>
            </div>
                <div class="submit">
                    <input type="submit" name="submit" value="Add">
                </div>
        </div>
    </form>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/resume1form.blade.php ENDPATH**/ ?>