<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>resumeuploadform</title>
    <link rel="stylesheet" href="<?php echo e(asset('resumedesignform.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <h2><a href="#">Resume</a></h2>
            </div>
            <div class="links">
                <ul>
                    <li><a href="#page1">Personal Information</a></li>
                    <li><a href="#page2">Education</a></li>
                    <li><a href="#page3">Skills</a></li>
                    <li><a href="#page4">Experience</a></li>
                </ul>
            </div>
        </div>
        <form action="/editresume" method="post">
        <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>
            <section class="information" id="page1">
                <div class="form1">
                    <h1>Personal Infromation</h1>
                        <div class="left1">
                            <input type="hidden" required name="id" value="<?php echo e($data['id']); ?>">
                            <span>First Name : </span><br>
                            <input type="text" name="fname" class="fname" value="<?php echo e($data['fname']); ?>"/><br><br>
                            <span>Address : </span><br>
                            <textarea type="text" name="address" value="<?php echo e($data['address']); ?>"></textarea><br><br>
                            <span>City : </span><br>
                            <input type="text" name="city" value="<?php echo e($data['city']); ?>"/><br><br>
                            <span>Email Address : </span><br>
                            <input type="text" name="email" value="<?php echo e($data['email']); ?>"/><br><br>
                            <span>Professional Summary : </span><br>
                            <textarea name="email" value="<?php echo e($data['professionalsummary']); ?>"></textarea><br><br>
                        </div>
                        <div class="right1">
                            <span>Last Name : </span><br>
                            <input type="text" name="lname" value="<?php echo e($data['lname']); ?>"/><br><br>
                            <span>Country : </span><br>
                            <input type="text" name="country" value="<?php echo e($data['country']); ?>"><br><br>
                            <!-- <span>City : </span><br>
                            <input type="text" name="city"/><br><br> -->
                            <span>Phone : </span><br>
                            <input type="number" name="phone" value="<?php echo e($data['phone']); ?>"/><br><br>
                        </div>
                </div>
            </section>
            <section class="education" id="page2">
                <div class="form2">
                <h1>Education</h1>
                        <div class="left4">
                            <span>School Name : </span><br>
                            <input type="text" name="sname" class="sname" value="<?php echo e($data['sname']); ?>"/><br><br>
                            <span>School State : </span><br>
                            <input type="text" name="schoolstate" value="<?php echo e($data['schoolstate']); ?>"></input><br><br>
                            <span>Filed of Study : </span><br>
                            <input type="text" name="fos" value="<?php echo e($data['fos']); ?>"/><br><br>
                        </div>
                        <div class="right4">
                            <span>School City : </span><br>
                            <input type="text" name="scity" value="<?php echo e($data['scity']); ?>"/><br><br>
                            <span>Degree Name : </span><br>
                            <input type="text" name="degreename" value="<?php echo e($data['degreename']); ?>"><br><br>
                            <span>Graduation Date : </span><br>
                            <input type="date" name="graduationdate" value="<?php echo e($data['graduationdate']); ?>"/><br><br>
                        </div>
                </div>
            </section>
            <section class="skills" id="page3">
                <div class="form3">
                <h1>Skills</h1>
                        <div class="left3">
                            <span>Top Skill : </span><br>
                            <input type="text" name="tskill" class="ename" value="<?php echo e($data['tskill']); ?>"/><br><br>
                            <span>Average Skill : </span><br>
                            <input type="text" name="askill" value="<?php echo e($data['askill']); ?>"></input><br><br>
                            <span>Law Skill : </span><br>
                            <input type="text" name="lskill" value="<?php echo e($data['lskill']); ?>"/><br><br>
                        </div>
                        <div class="right3">
                            <span>Top Skill Level : </span><br>
                            <input type="text" name="topskilllevel" value="<?php echo e($data['topskilllevel']); ?>"/><br><br>
                            <span>Average Skill Level : </span><br>
                            <input type="text" name="averageskilllevel" value="<?php echo e($data['averageskilllevel']); ?>"><br><br>
                            <span>Law Skill Level : </span><br>
                            <input type="text" name="lawskilllevel" value="<?php echo e($data['lawskilllevel']); ?>"/><br><br>
                        </div>  
                </div>
            </section>
            <section class="experience" id="page4">
                <div class="form4">
                <h1>Experience</h1>
                        <div class="left4">
                            <span>Employer : </span><br>
                            <input type="text" name="ename" class="ename" value="<?php echo e($data['ename']); ?>"/><br><br>
                            <span>City : </span><br>
                            <input type="text" name="ecity" value="<?php echo e($data['ecity']); ?>"></input><br><br>
                            <!-- <span>Start Date : </span><br>
                            <input type="date" name="startdate" value="<?php echo e($data['startdate']); ?>"/><br><br> -->
                        </div>
                        <div class="right4">
                            <span>Job Title : </span><br>
                            <input type="text" name="jobtitle" value="<?php echo e($data['jobtitle']); ?>"/><br><br>
                            <span>Job State : </span><br>
                            <input type="text" name="jobstate" value="<?php echo e($data['jobstate']); ?>"><br><br>
                            <span>End Date : </span><br>
                            <!-- <input type="date" name="enddate" value="<?php echo e($data['enddate']); ?>"/><br><br>-->
                            <input type="submit" value="Edit" name="EditResume"> 
                        </div>
                </div>
            </section>
        </form>
    </div>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/editresumeData.blade.php ENDPATH**/ ?>