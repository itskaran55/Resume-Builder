<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="pingback" href="https://www.drivco-wp.egenslab.com/xmlrpc.php">

					<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
				<title>Home 02 – Drivco</title>
<meta name="robots" content="max-image-preview:large">
<link rel="dns-prefetch" href="//stats.wp.com">
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="alternate" type="application/rss+xml" title="Drivco » Feed" href="https://www.drivco-wp.egenslab.com/feed/">
<link rel="alternate" type="application/rss+xml" title="Drivco » Comments Feed" href="https://www.drivco-wp.egenslab.com/comments/feed/">
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.drivco-wp.egenslab.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id="wp-emoji-styles-inline-css" type="text/css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel="stylesheet" id="wp-block-library-css" href="https://www.drivco-wp.egenslab.com/wp-includes/css/dist/block-library/style.min.css?ver=6.4.2" type="text/css" media="all">
<style id="wp-block-library-theme-inline-css" type="text/css">
.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video{margin:0 0 1em}.wp-block-template-part.has-background{margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<link rel="stylesheet" id="jquery-selectBox-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css?ver=1.2.0" type="text/css" media="all">
<link rel="stylesheet" id="yith-wcwl-font-awesome-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/font-awesome.css?ver=4.7.0" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce_prettyPhoto_css-css" href="//www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=3.1.6" type="text/css" media="all">
<link rel="stylesheet" id="yith-wcwl-main-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/yith-woocommerce-wishlist/assets/css/style.css?ver=3.27.0" type="text/css" media="all">
<style id="yith-wcwl-main-inline-css" type="text/css">
.yith-wcwl-share li a{color: #FFFFFF;}.yith-wcwl-share li a:hover{color: #FFFFFF;}.yith-wcwl-share a.facebook{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.facebook:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.twitter{background: #45AFE2; background-color: #45AFE2;}.yith-wcwl-share a.twitter:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.pinterest{background: #AB2E31; background-color: #AB2E31;}.yith-wcwl-share a.pinterest:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.email{background: #FBB102; background-color: #FBB102;}.yith-wcwl-share a.email:hover{background: #39599E; background-color: #39599E;}.yith-wcwl-share a.whatsapp{background: #00A901; background-color: #00A901;}.yith-wcwl-share a.whatsapp:hover{background: #39599E; background-color: #39599E;}
</style>
<style id="classic-theme-styles-inline-css" type="text/css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id="global-styles-inline-css" type="text/css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="contact-form-7-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8.3" type="text/css" media="all">
<style id="egns-stylesheet-inline-css" type="text/css">

        .inner-page-banner{
            background-image: url(https://www.drivco-wp.egenslab.com/wp-content/plugins/drivco-core//inc/theme-options/images/breadcrumb/breadcrumb-bg.png), linear-gradient(#FAFAFA, #FAFAFA);
            background-size: cover;
            background-repeat: no-repeat;
        }
    
        footer {
            background-image: url(https://www.drivco-wp.egenslab.com/wp-content/plugins/drivco-core//inc/theme-options/images/footer/footer-bg.png), linear-gradient(#1d1d1d, #1d1d1d) ;
            background-size: cover;
            background-repeat: no-repeat;
            overflow: hidden;
        }
    
</style>
<link rel="stylesheet" id="woocommerce-layout-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=8.3.1" type="text/css" media="all">
<link rel="stylesheet" id="woocommerce-smallscreen-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=8.3.1" type="text/css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" id="woocommerce-general-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=8.3.1" type="text/css" media="all">
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" id="egns-fonts-css" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;300;400;500;600;700;800;900&amp;family=Open+Sans:wght@300;400;500;600;700;800&amp;display=swap" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/bootstrap.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-icons-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/bootstrap-icons.css?ver=1699532534" type="text/css" media="all">
<link rel="stylesheet" id="all-fontawesome-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/all.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="fontawesome-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/fontawesome.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="datatable-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/datatable.css?ver=1698935724" type="text/css" media="all">
<link rel="stylesheet" id="fancybox-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/jquery.fancybox.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="swiper-bundle-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/swiper-bundle.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="slick-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/slick.css?ver=1699532534" type="text/css" media="all">
<link rel="stylesheet" id="slick-theme-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/slick-theme.css?ver=1699532534" type="text/css" media="all">
<link rel="stylesheet" id="magnific-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/magnific-popup.css?ver=1699532534" type="text/css" media="all">
<link rel="stylesheet" id="boxicons-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/boxicons.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="nice-select-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/nice-select.css?ver=1699532534" type="text/css" media="all">
<link rel="stylesheet" id="rangeSlider-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/rangeSlider.min.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="jquery-ui-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/jquery-ui.css?ver=1695285017" type="text/css" media="all">
<link rel="stylesheet" id="blog-css-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/blog-and-pages.css?ver=1701166065" type="text/css" media="all">
<link rel="stylesheet" id="WooCommerce-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/woocommerce-custom.css?ver=1701166065" type="text/css" media="all">
<link rel="stylesheet" id="egns-style-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/css/style.css?ver=1701174743" type="text/css" media="all">
<link rel="stylesheet" id="egns-theme-css" href="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/style.css?ver=74" type="text/css" media="all">
<link rel="stylesheet" id="dashicons-css" href="https://www.drivco-wp.egenslab.com/wp-includes/css/dashicons.min.css?ver=6.4.2" type="text/css" media="all">
<style id="dashicons-inline-css" type="text/css">
[data-font="Dashicons"]:before {font-family: 'Dashicons' !important;content: attr(data-icon) !important;speak: none !important;font-weight: normal !important;font-variant: normal !important;text-transform: none !important;line-height: 1 !important;font-style: normal !important;-webkit-font-smoothing: antialiased !important;-moz-osx-font-smoothing: grayscale !important;}
</style>
<link rel="stylesheet" id="simple-auction-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce-simple-auctions/css/frontend.css?ver=6.4.2" type="text/css" media="all">
<link rel="stylesheet" id="elementor-icons-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.23.0" type="text/css" media="all">
<link rel="stylesheet" id="elementor-frontend-legacy-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/css/frontend-legacy.min.css?ver=3.17.3" type="text/css" media="all">
<link rel="stylesheet" id="elementor-frontend-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.17.3" type="text/css" media="all">
<link rel="stylesheet" id="swiper-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/swiper/css/swiper.min.css?ver=5.3.6" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-8-css" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/elementor/css/post-8.css?ver=1699539698" type="text/css" media="all">
<link rel="stylesheet" id="elementor-global-css" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/elementor/css/global.css?ver=1699539699" type="text/css" media="all">
<link rel="stylesheet" id="elementor-post-18-css" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/elementor/css/post-18.css?ver=1701245638" type="text/css" media="all">
<link rel="stylesheet" id="google-fonts-1-css" href="https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=swap&amp;ver=6.4.2" type="text/css" media="all">
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin=""><script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/dist/hooks.min.js?ver=c6aec9a8d4e5a5d543a1" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://stats.wp.com/w.js?ver=202401" id="woo-tracks-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.8.3.1" id="jquery-blockui-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/www.drivco-wp.egenslab.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=8.3.1" id="wc-add-to-cart-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.8.3.1" id="js-cookie-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" id="woocommerce-js-extra">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=8.3.1" id="woocommerce-js" defer="defer" data-wp-strategy="defer"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce-simple-auctions/js/jquery.countdown.min.js?ver=2.1.4" id="simple-auction-countdown-js"></script>
<script type="text/javascript" id="simple-auction-countdown-language-js-extra">
/* <![CDATA[ */
var countdown_language_data = {"labels":{"Years":"Years","Months":"Months","Weeks":"Weeks","Days":"Days","Hours":"Hours","Minutes":"Minutes","Seconds":"Seconds"},"labels1":{"Year":"Year","Month":"Month","Week":"Week","Day":"Day","Hour":"Hour","Minute":"Minute","Second":"Second"},"compactLabels":{"y":"y","m":"m","w":"w","d":"d"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce-simple-auctions/js/jquery.countdown.language.js?ver=2.1.4" id="simple-auction-countdown-language-js"></script>
<script type="text/javascript" id="autoNumeric-js-extra">
/* <![CDATA[ */
var autoNumericdata = {"currencySymbolPlacement":"p","digitGroupSeparator":",","decimalCharacter":".","currencySymbol":"$","decimalPlacesOverride":"2"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce-simple-auctions/js/autoNumeric.min.js?ver=2.0.13" id="autoNumeric-js"></script>
<script type="text/javascript" id="simple-auction-frontend-js-extra">
/* <![CDATA[ */
var data = {"finished":"Auction has finished!","checking":"Patience please, we are checking if auction is finished!","gtm_offset":"0","started":"Auction has started! Please refresh your page.","no_need":"No need to bid. Your bid is winning! ","compact_counter":"no","outbid_message":"<ul class=\"woocommerce-error\" role=\"alert\">\n\t\t\t<li>\n\t\t\tYou've been outbid!\t\t<\/li>\n\t<\/ul>\n","interval":"1"};
var SA_Ajax = {"ajaxurl":"\/home-02\/?wsa-ajax","najax":"1","last_activity":"1703753298","focus":"yes"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce-simple-auctions/js/simple-auction-frontend.js?ver=2.1.4" id="simple-auction-frontend-js"></script>
<link rel="https://api.w.org/" href="https://www.drivco-wp.egenslab.com/wp-json/"><link rel="alternate" type="application/json" href="https://www.drivco-wp.egenslab.com/wp-json/wp/v2/pages/18"><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.drivco-wp.egenslab.com/xmlrpc.php?rsd">
<meta name="generator" content="WordPress 6.4.2">
<meta name="generator" content="WooCommerce 8.3.1">
<link rel="canonical" href="https://www.drivco-wp.egenslab.com/home-02/">
<link rel="shortlink" href="https://www.drivco-wp.egenslab.com/?p=18">
<link rel="alternate" type="application/json+oembed" href="https://www.drivco-wp.egenslab.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.drivco-wp.egenslab.com%2Fhome-02%2F">
<link rel="alternate" type="text/xml+oembed" href="https://www.drivco-wp.egenslab.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.drivco-wp.egenslab.com%2Fhome-02%2F&amp;format=xml">
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.17.3; settings: css_print_method-external, google_font-enabled, font_display-swap">
<style type="text/css">.top-bar .company-logo img,.top-bar.style-2 .company-logo img,header.style-3 .header-logo img,header.style-4 .header-logo img,.top-bar.style-5 .logo-and-menu .company-logo img,.top-bar.style-6 .logo-and-menu .company-logo img{width:220px!important;}</style><link rel="icon" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/av-car.svg" sizes="32x32">
<link rel="icon" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/av-car.svg" sizes="192x192">
<link rel="apple-touch-icon" href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/av-car.svg">
<meta name="msapplication-TileImage" content="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/av-car.svg">
<style>@-webkit-keyframes marqueeAnimation-4880718  { 100%  {transform:translateX(-1210px)}}</style><style>@-webkit-keyframes marqueeAnimation-7970853  { 100%  {transform:translateX(-1772.19px)}}</style><script src="https://www.drivco-wp.egenslab.com/wp-includes/js/wp-emoji-release.min.js?ver=6.4.2" defer=""></script></head>
    <body class="page-template page-template-elementor_header_footer page page-id-18 theme-drivco woocommerce-js elementor-default elementor-template-full-width elementor-kit-8 elementor-page elementor-page-18 e--ua-blink e--ua-chrome e--ua-webkit" itemtype="https://schema.org/WebPage" data-elementor-device-mode="desktop">

<!-- app -->
<div id="app" class="">
    <!-- Preloader Start -->
<div class="egns-preloader" style="display: none;">
<div class="preloader-close-btn">
    <span><i class="bi bi-x-lg"></i> Close</span>
</div>
<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-6">
            <div class="circle-border">
                <div class="moving-circle"></div>
                <div class="moving-circle"></div>
                <div class="moving-circle"></div>
                                            <img style="left: 50%; top: 50%; position: absolute; transform: translate(-50%, -50%) matrix(1, 0, 0, 1, 0, 0);" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/av-car.svg" alt="">
                                    </div>
        </div>
    </div>
</div>
</div>
<!-- Preloader End --><!-- Sidebar Menu -->
<div class="sidebar-menu">
<div class="mobile-logo-area d-flex justify-content-between align-items-center">
<div class="mobile-logo-wrap">
                    <a href="https://www.drivco-wp.egenslab.com/" title="Drivco">
                                    <img class="img-fluid" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/drivco-core//inc/theme-options/images/logo/logo.svg" alt="Drivco"></a>
                        </div>
<div class="menu-button menu-close-btn">
    <i class="bi bi-x"></i>
</div>
</div>


<!-- Main Menu -->
<div class="main-menu"><ul id="menu-main-menu" class="menu-list"><li id="menu-item-40" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children menu-item-40"><a href="https://www.drivco-wp.egenslab.com/">Home</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-50" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-18 current_page_item menu-item-50"><a href="https://www.drivco-wp.egenslab.com/home-02/" aria-current="page">Home 02</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-1295" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children has-mega-menu menu-item-1295"><a href="#" class="active">New Car</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu row mega-col-4">
<li id="menu-item-1323" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1323 col-4"><a href="#" class="active">Browse by Brand</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1297" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1297"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/">Audi</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1298" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1298"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/">BMW</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1299" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1299"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/">Ferrari</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1300" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1300"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/hyundai/">Hyundai</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1302" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1302"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/">Mercedes</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1308" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1308"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/toyota/">Toyota</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-1309" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1309 col-4"><a href="#" class="active">Popular Models</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1310" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1310"><a href="https://www.drivco-wp.egenslab.com/model/bmw-2023/">BMW-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1311" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1311"><a href="https://www.drivco-wp.egenslab.com/model/c-class-2023/">C-Class-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1312" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1312"><a href="https://www.drivco-wp.egenslab.com/model/escalade-2023/">Escalade-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1313" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1313"><a href="https://www.drivco-wp.egenslab.com/model/ferrari-f8/">Ferrari F8</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1314" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1314"><a href="https://www.drivco-wp.egenslab.com/model/golf-2023/">Golf-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1315" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1315"><a href="https://www.drivco-wp.egenslab.com/model/rx-2021/">RX-2021</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-1316" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1316 col-4"><a href="#" class="active">Popular Cities</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1317" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1317"><a href="https://www.drivco-wp.egenslab.com/location/kualalumpur/">Kualalumpur</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1321" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1321"><a href="https://www.drivco-wp.egenslab.com/location/panama-city/">Panama City</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1319" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1319"><a href="https://www.drivco-wp.egenslab.com/location/new-delhi/">New Delhi</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1320" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1320"><a href="https://www.drivco-wp.egenslab.com/location/new-york/">New York</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1322" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1322"><a href="https://www.drivco-wp.egenslab.com/location/sydney-city/">Sydney City</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1318" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1318"><a href="https://www.drivco-wp.egenslab.com/location/melbourne-city/">Melbourne City</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
</ul>
</li>
<li id="menu-item-1468" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-category menu-item-1468"><a href="https://www.drivco-wp.egenslab.com/vehicle-category/used-car/">Used Car</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-58" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-58"><a href="#" class="active">Pages</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-41" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-41"><a href="https://www.drivco-wp.egenslab.com/about-us/">About Us</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1854" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1854"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/">Single Brand Category</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1802" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1802"><a href="https://www.drivco-wp.egenslab.com/offer/">Special Offer</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-61" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-61"><a href="#" class="active">Car Listing System</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-44" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44"><a href="https://www.drivco-wp.egenslab.com/car-listing-left-sidebar/">Car Listing Left Sidebar</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-45" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-45"><a href="https://www.drivco-wp.egenslab.com/car-listing-right-sidebar/">Car Listing Right Sidebar</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-866" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-866"><a href="/vehicle">Car Listing No Sidebar</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-871" class="menu-item menu-item-type-post_type menu-item-object-vehicle menu-item-871"><a href="https://www.drivco-wp.egenslab.com/vehicle/cadillac-escalade-2023/">Car Details</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1730" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1730"><a href="https://www.drivco-wp.egenslab.com/auction-vehicle-list/">Auctions Vehicle</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-872" class="menu-item menu-item-type-post_type menu-item-object-vehicle menu-item-872"><a href="https://www.drivco-wp.egenslab.com/vehicle/lexus-rx-2021/">Auction Car Details</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-59" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-59"><a href="#" class="active">Blog</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-43" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-43"><a href="https://www.drivco-wp.egenslab.com/blog-standard/">Blog Standard</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-42" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42"><a href="https://www.drivco-wp.egenslab.com/blog-grid/">Blog Grid</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-200" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-200"><a href="https://www.drivco-wp.egenslab.com/the-car-enthusiast-exploring-the-world-of-cars-and-driving/">Blog Details</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-60" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-60"><a href="#" class="active">Shop</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57"><a href="https://www.drivco-wp.egenslab.com/shop/">Shop</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-46" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-46"><a href="https://www.drivco-wp.egenslab.com/cart/">Cart</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47"><a href="https://www.drivco-wp.egenslab.com/checkout/">Checkout</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55"><a href="https://www.drivco-wp.egenslab.com/my-account/">My account</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-912" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-912"><a href="https://www.drivco-wp.egenslab.com/faqs/">FAQ’s</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-738" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-738"><a href="/error">Error</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-884" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-884"><a href="https://www.drivco-wp.egenslab.com/customer-feedback/">Customer Review</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-927" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-927"><a href="https://www.drivco-wp.egenslab.com/refund_returns/">Return &amp; Exchange</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-48" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-48"><a href="https://www.drivco-wp.egenslab.com/contact-us/">Contact Us</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul></div>

<div class="topbar-right">

                            <a href="https://www.drivco-wp.egenslab.com/wishlist/">
            <svg width="16" height="16" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.00012 2.40453L6.37273 1.75966C4.90006 0.245917 2.19972 0.76829 1.22495 2.67141C0.767306 3.56653 0.664053 4.8589 1.4997 6.50827C2.30473 8.09639 3.97953 9.99864 7.00012 12.0706C10.0207 9.99864 11.6946 8.09639 12.5005 6.50827C13.3362 4.85803 13.2338 3.56653 12.7753 2.67141C11.8005 0.76829 9.10019 0.245042 7.62752 1.75879L7.00012 2.40453ZM7.00012 13.125C-6.41666 4.25953 2.86912 -2.65995 6.84612 1.00016C6.89862 1.04829 6.95024 1.09816 7.00012 1.14979C7.04949 1.09821 7.10087 1.04859 7.15413 1.00104C11.1302 -2.6617 20.4169 4.25865 7.00012 13.125Z"></path>
            </svg>
            SAVE                </a>
            
                                                <a class="primary-btn3" href="https://www.drivco-wp.egenslab.com/my-account/">
                <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.4311 12.759C15.417 11.4291 16 9.78265 16 8C16 3.58169 12.4182 0 8 0C3.58169 0 0 3.58169 0 8C0 12.4182 3.58169 16 8 16C10.3181 16 12.4058 15.0141 13.867 13.4387C14.0673 13.2226 14.2556 12.9957 14.4311 12.759ZM13.9875 12C14.7533 10.8559 15.1999 9.48009 15.1999 8C15.1999 4.02355 11.9764 0.799983 7.99991 0.799983C4.02355 0.799983 0.799983 4.02355 0.799983 8C0.799983 9.48017 1.24658 10.8559 2.01245 12C2.97866 10.5566 4.45301 9.48194 6.17961 9.03214C5.34594 8.45444 4.79998 7.49102 4.79998 6.39995C4.79998 4.63266 6.23271 3.19993 8 3.19993C9.76729 3.19993 11.2 4.63266 11.2 6.39995C11.2 7.49093 10.654 8.45444 9.82039 9.03206C11.5469 9.48194 13.0213 10.5565 13.9875 12ZM13.4722 12.6793C12.3495 10.8331 10.3188 9.59997 8.00008 9.59997C5.68126 9.59997 3.65049 10.8331 2.52776 12.6794C3.84829 14.2222 5.80992 15.2 8 15.2C10.1901 15.2 12.1517 14.2222 13.4722 12.6793ZM8 8.79998C9.32551 8.79998 10.4 7.72554 10.4 6.39995C10.4 5.07444 9.32559 3.99992 8 3.99992C6.6744 3.99992 5.59997 5.07452 5.59997 6.40003C5.59997 7.72554 6.67449 8.79998 8 8.79998Z"></path>
                </svg>
                SIGN UP                    </a>
                                </div>

    <div class="hotline-area d-flex">
                    <div class="icon">
            <img src="https://www.drivco-wp.egenslab.com/wp-content/plugins/drivco-core//inc/theme-options/images/icon/hotline-icon.svg" alt="">
        </div>
    
                    <div class="content">
            <span>To More Inquiry</span>
                                    <h6><a href="tel:990737621432">+990-737 621 432</a></h6>
                            </div>
            </div>

</div>
<!-- End Sidebar Menu -->


<div class="topbar-header">
<div class="top-bar style-2">
<div class="company-logo">
                    <a href="https://www.drivco-wp.egenslab.com/" title="Drivco">
                                    <img class="img-fluid" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/footer-logo.svg" alt="Drivco"></a>
                        </div>

<!-- Topbar Menu -->
<div class="top-bar-items"><ul id="menu-topbar-menu" class="ul"><li id="menu-item-409" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-409"><a href="#" class="active">Newly Listed Car</a></li>
<li id="menu-item-410" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-410"><a href="#" class="active">Lowest Mileage</a></li>
<li id="menu-item-411" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-411"><a href="#" class="active">Offer</a></li>
</ul></div>
            <div class="search-area">
                    <form method="get" id="searchform" action="https://www.drivco-wp.egenslab.com/vehicle/">
    <div class="form-inner">
        <input type="text" name="s" id="s" placeholder="Search your products" fdprocessedid="mad4h3">
        <input type="hidden" name="post_type" value="vehicle"> <!-- Change 'vehicle' to your custom post type name -->
        <button type="submit" fdprocessedid="4bo5dc"><i class="bi bi-search"></i></button>
    </div>
</form>
        </div>

            <div class="topbar-right">
        <div class="hotline-area d-xl-flex d-none">
                                    <div class="icon">
                    <img src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/Call-white.svg" alt="">
                </div>
            
                                    <div class="content">
                    <span>To More Inquiry</span>
                                                    <h6><a href="tel:990737621432">+990-737 621 432</a></h6>
                                            </div>
                            </div>
    </div>

</div>

<!-- Start header section -->
<header class="header-area style-2">
<div class="header-logo d-lg-none d-flex">
                    <a href="https://www.drivco-wp.egenslab.com/" title="Drivco">
                                    <img class="img-fluid" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/footer-logo.svg" alt="Drivco"></a>
                        </div>

            <div class="menu-button sidebar-button mobile-menu-btn">
        <svg width="15" height="12" viewBox="0 0 15 12" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0.75C0 0.551088 0.0790176 0.360322 0.21967 0.21967C0.360322 0.0790178 0.551088 0 0.75 0H10.5C10.6989 0 10.8897 0.0790178 11.0303 0.21967C11.171 0.360322 11.25 0.551088 11.25 0.75C11.25 0.948912 11.171 1.13968 11.0303 1.28033C10.8897 1.42098 10.6989 1.5 10.5 1.5H0.75C0.551088 1.5 0.360322 1.42098 0.21967 1.28033C0.0790176 1.13968 0 0.948912 0 0.75ZM14.25 5.25H0.75C0.551088 5.25 0.360322 5.32902 0.21967 5.46967C0.0790176 5.61032 0 5.80109 0 6C0 6.19891 0.0790176 6.38968 0.21967 6.53033C0.360322 6.67098 0.551088 6.75 0.75 6.75H14.25C14.4489 6.75 14.6397 6.67098 14.7803 6.53033C14.921 6.38968 15 6.19891 15 6C15 5.80109 14.921 5.61032 14.7803 5.46967C14.6397 5.32902 14.4489 5.25 14.25 5.25ZM7.5 10.5H0.75C0.551088 10.5 0.360322 10.579 0.21967 10.7197C0.0790176 10.8603 0 11.0511 0 11.25C0 11.4489 0.0790176 11.6397 0.21967 11.7803C0.360322 11.921 0.551088 12 0.75 12H7.5C7.69891 12 7.88968 11.921 8.03033 11.7803C8.17098 11.6397 8.25 11.4489 8.25 11.25C8.25 11.0511 8.17098 10.8603 8.03033 10.7197C7.88968 10.579 7.69891 10.5 7.5 10.5Z"></path>
        </svg>
        <span>MENU</span>
    </div>
                    <div class="main-menu">
        <div class="mobile-logo-area d-lg-none d-flex justify-content-between align-items-center">
            <div class="mobile-logo-wrap">
                                <a href="https://www.drivco-wp.egenslab.com/" title="Drivco">
                                    <img class="img-fluid" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/drivco-core//inc/theme-options/images/logo/logo.svg" alt="Drivco"></a>
                                    </div>
        </div>

        <!-- mega menu  -->
        <div class="mega-menu"><ul id="menu-header-two-second-menu" class="menu-list"><li id="menu-item-1790" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1790"><a href="#" class="active">New Car</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1547" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1547"><a href="#" class="active">Browse by Brand</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1551" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1551"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/">Audi</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1552" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1552"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/">BMW</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1553" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1553"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/">Mercedes</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1554" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1554"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/">Ferrari</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1555" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1555"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/hyundai/">Hyundai</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1550" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-1550"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/toyota/">Toyota</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-1548" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1548"><a href="#" class="active">Popular Models</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1559" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1559"><a href="https://www.drivco-wp.egenslab.com/model/bmw-2023/">BMW-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1556" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1556"><a href="https://www.drivco-wp.egenslab.com/model/escalade-2023/">Escalade-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1557" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1557"><a href="https://www.drivco-wp.egenslab.com/model/c-class-2023/">C-Class-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1558" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1558"><a href="https://www.drivco-wp.egenslab.com/model/rx-2021/">RX-2021</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1561" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1561"><a href="https://www.drivco-wp.egenslab.com/model/ferrari-f8/">Ferrari F8</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1560" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-model menu-item-1560"><a href="https://www.drivco-wp.egenslab.com/model/golf-2023/">Golf-2023</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
<li id="menu-item-1549" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1549"><a href="#" class="active">Popular Cities</a><i class="bi bi-plus dropdown-icon"></i>
<ul class="sub-menu">
<li id="menu-item-1562" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1562"><a href="https://www.drivco-wp.egenslab.com/location/panama-city/">Panama City</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1564" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1564"><a href="https://www.drivco-wp.egenslab.com/location/new-delhi/">New Delhi</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1563" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1563"><a href="https://www.drivco-wp.egenslab.com/location/melbourne-city/">Melbourne City</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1565" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1565"><a href="https://www.drivco-wp.egenslab.com/location/sydney-city/">Sydney City</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1566" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1566"><a href="https://www.drivco-wp.egenslab.com/location/kualalumpur/">Kualalumpur</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1567" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1567"><a href="https://www.drivco-wp.egenslab.com/location/new-york/">New York</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul>
</li>
</ul>
</li>
<li id="menu-item-1545" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-category menu-item-1545"><a href="https://www.drivco-wp.egenslab.com/vehicle-category/used-car/">Used Car</a><i class="bi bi-plus dropdown-icon"></i></li>
<li id="menu-item-1544" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1544"><a href="https://www.drivco-wp.egenslab.com/contact-us/">Contact Us</a><i class="bi bi-plus dropdown-icon"></i></li>
</ul></div>
    </div>

<div class="nav-right d-flex jsutify-content-end align-items-center">
    <!-- Button trigger modal -->
                    <!-- Button trigger modal -->
        <div class="dropdown">
                                    <button class="modal-btn header-cart-btn" type="button" fdprocessedid="9by0br">
                    <i class="bi bi-bag-check"></i> CART (0)                        </button>
                                                        <div class="cart-menu">
                    <div class="cart-body">
                        <div class="widget_shopping_cart_content">

<p class="woocommerce-mini-cart__empty-message">No products in the cart.</p>


</div>
                    </div>
                </div>
                            </div>
    
    <div class="header-right">
        <ul>
                                    <li>
                                                    <a href="https://www.drivco-wp.egenslab.com/wishlist/">
                            <svg width="16" height="16" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.00012 2.40453L6.37273 1.75966C4.90006 0.245917 2.19972 0.76829 1.22495 2.67141C0.767306 3.56653 0.664053 4.8589 1.4997 6.50827C2.30473 8.09639 3.97953 9.99864 7.00012 12.0706C10.0207 9.99864 11.6946 8.09639 12.5005 6.50827C13.3362 4.85803 13.2338 3.56653 12.7753 2.67141C11.8005 0.76829 9.10019 0.245042 7.62752 1.75879L7.00012 2.40453ZM7.00012 13.125C-6.41666 4.25953 2.86912 -2.65995 6.84612 1.00016C6.89862 1.04829 6.95024 1.09816 7.00012 1.14979C7.04949 1.09821 7.10087 1.04859 7.15413 1.00104C11.1302 -2.6617 20.4169 4.25865 7.00012 13.125Z"></path>
                            </svg>
                            SAVE                                </a>
                                            </li>
            

                                    <li>
                                                                                        <a class="primary-btn1" href="https://www.drivco-wp.egenslab.com/my-account/">
                                <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M14.4311 12.759C15.417 11.4291 16 9.78265 16 8C16 3.58169 12.4182 0 8 0C3.58169 0 0 3.58169 0 8C0 12.4182 3.58169 16 8 16C10.3181 16 12.4058 15.0141 13.867 13.4387C14.0673 13.2226 14.2556 12.9957 14.4311 12.759ZM13.9875 12C14.7533 10.8559 15.1999 9.48009 15.1999 8C15.1999 4.02355 11.9764 0.799983 7.99991 0.799983C4.02355 0.799983 0.799983 4.02355 0.799983 8C0.799983 9.48017 1.24658 10.8559 2.01245 12C2.97866 10.5566 4.45301 9.48194 6.17961 9.03214C5.34594 8.45444 4.79998 7.49102 4.79998 6.39995C4.79998 4.63266 6.23271 3.19993 8 3.19993C9.76729 3.19993 11.2 4.63266 11.2 6.39995C11.2 7.49093 10.654 8.45444 9.82039 9.03206C11.5469 9.48194 13.0213 10.5565 13.9875 12ZM13.4722 12.6793C12.3495 10.8331 10.3188 9.59997 8.00008 9.59997C5.68126 9.59997 3.65049 10.8331 2.52776 12.6794C3.84829 14.2222 5.80992 15.2 8 15.2C10.1901 15.2 12.1517 14.2222 13.4722 12.6793ZM8 8.79998C9.32551 8.79998 10.4 7.72554 10.4 6.39995C10.4 5.07444 9.32559 3.99992 8 3.99992C6.6744 3.99992 5.59997 5.07452 5.59997 6.40003C5.59997 7.72554 6.67449 8.79998 8 8.79998Z"></path>
                                </svg>
                                SIGN UP                                    </a>
                                                                            </li>
                            </ul>
    </div>
</div>
</header>
<!-- End header section -->
</div>		<div data-elementor-type="wp-page" data-elementor-id="18" class="elementor elementor-18">
                <div class="elementor-inner">
        <div class="elementor-section-wrap">
                            <section class="elementor-section elementor-top-section elementor-element elementor-element-b699e8e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="b699e8e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a6bb90b" data-id="a6bb90b" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-6760a21 elementor-widget elementor-widget-drivco_hero_banner_two" data-id="6760a21" data-element_type="widget" data-widget_type="drivco_hero_banner_two.default">
        <div class="elementor-widget-container">
    


<div class="banner-section2">
    <div class="row">
        <div class="col-lg-8">
            <div class="banner-content">
                                            <h1>The Largest Car Marketplace </h1>
                                                                    <p>Car dealerships may sell new cars from one or several manufacturers, as well as used cars. </p>
                                        <div class="banner-content-bottom">
                                                    <a href="/vehicle" class="primary-btn3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="15" viewBox="0 0 24 15"><path d="M3.25985 0C3.15704 0 3.05844 0.0413135 2.98574 0.114852C2.91304 0.18839 2.87219 0.28813 2.87219 0.392129C2.87219 0.496128 2.91304 0.595867 2.98574 0.669405C3.05844 0.742944 3.15704 0.784257 3.25985 0.784257H4.8105C4.91332 0.784257 5.01192 0.742944 5.08462 0.669405C5.15732 0.595867 5.19816 0.496128 5.19816 0.392129C5.19816 0.28813 5.15732 0.18839 5.08462 0.114852C5.01192 0.0413135 4.91332 0 4.8105 0H3.25985ZM5.77966 0C5.67684 0 5.57824 0.0413135 5.50554 0.114852C5.43284 0.18839 5.39199 0.28813 5.39199 0.392129C5.39199 0.496128 5.43284 0.595867 5.50554 0.669405C5.57824 0.742944 5.67684 0.784257 5.77966 0.784257H10.3347C10.4375 0.784257 10.5361 0.742944 10.6088 0.669405C10.6815 0.595867 10.7223 0.496128 10.7223 0.392129C10.7223 0.28813 10.6815 0.18839 10.6088 0.114852C10.5361 0.0413135 10.4375 0 10.3347 0H5.77966Z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4.22917 2.7464C4.12636 2.7464 4.02776 2.78771 3.95505 2.86125C3.88235 2.93479 3.84151 3.03453 3.84151 3.13853C3.84151 3.24253 3.88235 3.34227 3.95505 3.4158C4.02776 3.48934 4.12636 3.53066 4.22917 3.53066H13.1454C14.653 3.53066 15.5822 3.76829 16.3256 4.15002C16.9575 4.47431 17.4672 4.90546 18.1055 5.44542C18.2375 5.55698 18.3749 5.67305 18.5201 5.79402L18.6101 5.86892L18.726 5.88127C22.2653 6.25811 23.0622 7.46822 23.2246 8.08778V9.60865C23.2246 9.71265 23.1838 9.81239 23.1111 9.88593C23.0384 9.95947 22.9398 10.0008 22.8369 10.0008H21.8356C21.6511 8.88811 20.6943 8.04014 19.5418 8.04014C18.3893 8.04014 17.4325 8.88811 17.248 10.0008H10.2058C10.0212 8.88811 9.06448 8.04014 7.91196 8.04014C6.75944 8.04014 5.80269 8.88811 5.61816 10.0008H3.7446C3.64178 10.0008 3.54318 10.0421 3.47048 10.1156C3.39778 10.1892 3.35693 10.2889 3.35693 10.3929C3.35693 10.4969 3.39778 10.5966 3.47048 10.6702C3.54318 10.7437 3.64178 10.785 3.7446 10.785H5.61816C5.80269 11.8977 6.75944 12.7457 7.91196 12.7457C9.06448 12.7457 10.0212 11.8977 10.2058 10.785H17.248C17.4325 11.8977 18.3893 12.7457 19.5418 12.7457C20.6943 12.7457 21.6511 11.8977 21.8356 10.785H22.8369C23.1454 10.785 23.4412 10.6611 23.6593 10.4405C23.8774 10.2199 23.9999 9.92065 23.9999 9.60865V7.99543L23.99 7.95191C23.7431 6.86983 22.5791 5.52855 18.9239 5.11407C18.8217 5.02859 18.7215 4.9435 18.6227 4.85978C17.9828 4.31766 17.3942 3.81887 16.6766 3.45047C15.7966 2.99893 14.7391 2.7464 13.1454 2.7464H4.22917ZM17.9912 10.3929C17.9912 9.97691 18.1545 9.57795 18.4453 9.2838C18.7361 8.98965 19.1306 8.82439 19.5418 8.82439C19.9531 8.82439 20.3475 8.98965 20.6383 9.2838C20.9291 9.57795 21.0925 9.97691 21.0925 10.3929C21.0925 10.8089 20.9291 11.2079 20.6383 11.502C20.3475 11.7962 19.9531 11.9614 19.5418 11.9614C19.1306 11.9614 18.7361 11.7962 18.4453 11.502C18.1545 11.2079 17.9912 10.8089 17.9912 10.3929ZM7.91196 8.82439C7.5007 8.82439 7.10629 8.98965 6.81549 9.2838C6.52468 9.57795 6.36131 9.97691 6.36131 10.3929C6.36131 10.8089 6.52468 11.2079 6.81549 11.502C7.10629 11.7962 7.5007 11.9614 7.91196 11.9614C8.32322 11.9614 8.71763 11.7962 9.00843 11.502C9.29923 11.2079 9.46261 10.8089 9.46261 10.3929C9.46261 9.97691 9.29923 9.57795 9.00843 9.2838C8.71763 8.98965 8.32322 8.82439 7.91196 8.82439Z"></path><path d="M0 5.09873C0 4.99473 0.0408428 4.89499 0.113543 4.82146C0.186244 4.74792 0.284847 4.7066 0.387662 4.7066H4.74886C4.85167 4.7066 4.95027 4.74792 5.02297 4.82146C5.09567 4.89499 5.13652 4.99473 5.13652 5.09873C5.13652 5.20273 5.09567 5.30247 5.02297 5.37601C4.95027 5.44955 4.85167 5.49086 4.74886 5.49086H0.387662C0.284847 5.49086 0.186244 5.44955 0.113543 5.37601C0.0408428 5.30247 0 5.20273 0 5.09873ZM15.6836 5.60575C15.7563 5.67929 15.7971 5.77901 15.7971 5.88299C15.7971 5.98697 15.7563 6.08669 15.6836 6.16022L15.6532 6.19101C15.2897 6.55865 14.7968 6.76522 14.2828 6.76528H8.14089C8.03808 6.76528 7.93948 6.72397 7.86678 6.65043C7.79408 6.57689 7.75323 6.47715 7.75323 6.37315C7.75323 6.26915 7.79408 6.16941 7.86678 6.09587C7.93948 6.02234 8.03808 5.98102 8.14089 5.98102H14.2826C14.4354 5.98104 14.5866 5.95063 14.7277 5.89152C14.8688 5.83241 14.997 5.74577 15.105 5.63654L15.1355 5.60575C15.2082 5.53224 15.3068 5.49094 15.4096 5.49094C15.5123 5.49094 15.6109 5.53224 15.6836 5.60575ZM8.52856 14.6079C8.52856 14.5039 8.5694 14.4041 8.6421 14.3306C8.7148 14.257 8.8134 14.2157 8.91622 14.2157H10.5638C10.6666 14.2157 10.7652 14.257 10.8379 14.3306C10.9106 14.4041 10.9514 14.5039 10.9514 14.6079C10.9514 14.7118 10.9106 14.8116 10.8379 14.8851C10.7652 14.9587 10.6666 15 10.5638 15H8.91622C8.8134 15 8.7148 14.9587 8.6421 14.8851C8.5694 14.8116 8.52856 14.7118 8.52856 14.6079ZM11.2422 14.6079C11.2422 14.5039 11.283 14.4041 11.3557 14.3306C11.4284 14.257 11.527 14.2157 11.6298 14.2157H15.991C16.0939 14.2157 16.1925 14.257 16.2652 14.3306C16.3379 14.4041 16.3787 14.5039 16.3787 14.6079C16.3787 14.7118 16.3379 14.8116 16.2652 14.8851C16.1925 14.9587 16.0939 15 15.991 15H11.6298C11.527 15 11.4284 14.9587 11.3557 14.8851C11.283 14.8116 11.2422 14.7118 11.2422 14.6079Z"></path></svg>                                    Find Your Car                                </a>
                                                <div class="rating">
                        <a href="/vehicle">
                            <div class="review-top">
                                <div class="logo">
                                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/trustpilot-logo2.svg" alt="Banner Logo">
                                                                            </div>
                                <div class="star">
                                    
                                                                                    <ul class="trustpilot">
                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                    </ul>
                                                                            </div>
                            </div>
                            <div class="content">
                                <ul>
                                                                                    <li>Trust Ratings<span> 5.0</span></li>
                                                                                                                                <li>Based On 2348 Reviews</li>
                                                                            </ul>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-79426f0 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="79426f0" data-element_type="section">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-45a0e2b" data-id="45a0e2b" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-a31873d elementor-widget elementor-widget-drivco_marquee_slider" data-id="a31873d" data-element_type="widget" data-widget_type="drivco_marquee_slider.default">
        <div class="elementor-widget-container">
            


            <div class="text-slider2">
        <div class="marquee_text"><div style="width: 100000px; transform: translateX(0px); animation: 27.082s linear 0s infinite normal none running marqueeAnimation-7970853;" class="js-marquee-wrapper"><div class="js-marquee" style="margin-right: 50px; float: left;">
                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 30% OFFER ON TOYOTA CAR                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 24% OFFER ON BMW LATEST MODEL                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 45% OFFER ON FERRARI LAMBORGINI                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 15% OFFER ON NISSAN CAR                                                            </div><div class="js-marquee" style="margin-right: 50px; float: left;">
                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 30% OFFER ON TOYOTA CAR                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 24% OFFER ON BMW LATEST MODEL                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 45% OFFER ON FERRARI LAMBORGINI                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home2/icon/text-slider-vec.svg" alt="slider-image">
                                            GET 15% OFFER ON NISSAN CAR                                                            </div></div></div>
    </div>


</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-bfbf8fc elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="bfbf8fc" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e5eb51c" data-id="e5eb51c" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-6a34066 elementor-widget elementor-widget-drivco_brands" data-id="6a34066" data-element_type="widget" data-widget_type="drivco_brands.default">
        <div class="elementor-widget-container">
            


            <div class="dream-car-area">
        <div class="container">
            <div class="row mb-50">
                <div class="col-lg-12">
                    <div class="section-title-2 text-center">
                                                            <h2 class="styletwobrandt">Search Your Dream Car</h2>
                                                                                            <p class="styletwobrands">There has 30+ Brand Category Available </p>
                                                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="filter-area d-flex flex-wrap align-items-center justify-content-between">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-make-tab" data-bs-toggle="pill" data-bs-target="#pills-make" type="button" role="tab" aria-controls="pills-make" aria-selected="true" fdprocessedid="axqaii">Make</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-body-tab" data-bs-toggle="pill" data-bs-target="#pills-body" type="button" role="tab" aria-controls="pills-body" aria-selected="false" tabindex="-1">Body Type</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-location-tab" data-bs-toggle="pill" data-bs-target="#pills-location" type="button" role="tab" aria-controls="pills-location" aria-selected="false" tabindex="-1">Location</button>
                            </li>
                        </ul>
                                                            <div class="explore-btn d-lg-flex d-none">
                                <a class="explore-btn2" href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/" target="_blank" rel="nofollow">View More <i class="bi bi-arrow-right-short"></i></a>
                            </div>
                                                    </div>
                </div>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-make" role="tabpanel" aria-labelledby="pills-make-tab">
                    <div class="row g-4 justify-content-center">


                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(4)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/bmw.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Ferrari-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/hyundai/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/hyundai.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/jeep/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Jeep-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mercedes-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mezda/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mask-grou.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/sedan/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/sedan.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(2)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/suzuki/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Suzuki-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(1)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/tata/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Tata-Logo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(1)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/tesla/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/TeslaLogo.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(1)</span>
                                    </div>
                                </a>
                            </div>
                                                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/toyota/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Toyota.svg" alt="brand-icon">
                                        </div>
                                     <div class="content">
                                                                                            <h6>Available Cars</h6>
                                                                                        <span>(1)</span>
                                    </div>
                                </a>
                            </div>
                        
                    </div>
                </div>
                <div class="tab-pane fade" id="pills-body" role="tabpanel" aria-labelledby="pills-body-tab">
                    <div class="row g-4 justify-content-center">
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/coupe/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-03.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Coupe</h6>
                                        <span>(4)</span>
                                    </div>
                                </a>
                            </div>
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/hatchback/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-02-1.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Hatchback</h6>
                                        <span>(12)</span>
                                    </div>
                                </a>
                            </div>
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/hybrid-vehicle/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-01.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Hybrid Vehicle</h6>
                                        <span>(7)</span>
                                    </div>
                                </a>
                            </div>
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/muv-suv/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-03.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>MUV/SUV</h6>
                                        <span>(11)</span>
                                    </div>
                                </a>
                            </div>
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/sedan/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-02-1.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Sedan</h6>
                                        <span>(13)</span>
                                    </div>
                                </a>
                            </div>
                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/body-type/supercar/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/body-01.svg" alt="logo-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Supercar</h6>
                                        <span>(6)</span>
                                    </div>
                                </a>
                            </div>
                                                    </div>
                </div>
                <div class="tab-pane fade" id="pills-location" role="tabpanel" aria-labelledby="pills-location-tab">
                    <div class="row g-4 justify-content-center">

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/kualalumpur/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/sydne.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Kualalumpur</h6>
                                        <span>(4)</span>
                                    </div>
                                </a>
                            </div>

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/melbourne-city/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/merchester.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Melbourne City</h6>
                                        <span>(6)</span>
                                    </div>
                                </a>
                            </div>

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/new-delhi/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/delhi.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>New Delhi</h6>
                                        <span>(3)</span>
                                    </div>
                                </a>
                            </div>

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/new-york/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/new-work.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>New York</h6>
                                        <span>(1)</span>
                                    </div>
                                </a>
                            </div>

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/panama-city/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/panama.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Panama City</h6>
                                        <span>(5)</span>
                                    </div>
                                </a>
                            </div>

                        
                            <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                                <a href="https://www.drivco-wp.egenslab.com/location/sydney-city/" class="car-category text-center">
                                                                                    <div class="icon">
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/abu-dabi.svg" alt="loction-icon">
                                        </div>
                                                                                <div class="content">
                                        <h6>Sydney City</h6>
                                        <span>(3)</span>
                                    </div>
                                </a>
                            </div>

                                                    </div>
                </div>
            </div>

        </div>
    </div>








</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-19cd424 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="19cd424" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4ba26d0" data-id="4ba26d0" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-89b2d82 elementor-widget elementor-widget-drivco_vehicle_product_slider" data-id="89b2d82" data-element_type="widget" data-widget_type="drivco_vehicle_product_slider.default">
        <div class="elementor-widget-container">
    

            <div class="featured-car-section">
        <div class="container">
            <div class="row mb-50">
                <div class="col-lg-12 d-flex align-items-center justify-content-between gap-3 flex-wrap">
                    <div class="section-title-2">
                                                            <h2>Featured Cars</h2>
                                                                                            <p>Here are some of the featured cars in different categories</p>
                                                    </div>
                                                    <div class="slider-btn-group2">
                            <div class="slider-btn prev-1 swiper-button-disabled" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="true" fdprocessedid="o0v0py">
                                <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M0 6.50008L8 0L2.90909 6.50008L8 13L0 6.50008Z"></path>
                                </svg>
                            </div>
                            <div class="slider-btn next-1" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false" fdprocessedid="vxi5ts">
                                <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 6.50008L0 0L5.09091 6.50008L0 13L8 6.50008Z"></path>
                                </svg>
                            </div>
                        </div>
                                            </div>
            </div>
        </div>
        <div class="row">
            <div class="swiper home2-featured-slider swiper-container-initialized swiper-container-horizontal">
                <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">
                                                    <div class="swiper-slide swiper-slide-active" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img fetchpriority="high" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c3f4fe" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c3f4fe" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $85,032				<del>$89,600</del>
                                                    </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-tt-roadster/">Audi TT Roadster</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                                    <div class="swiper-slide swiper-slide-next" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c3fe11" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c3fe11" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $75,000				<del>$78,200</del>
                                                    </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a4-sedan/">Audi A4 Sedan</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                                    <div class="swiper-slide" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c4040a" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c4040a" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $654,165			                                                </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-296-gtb/">Ferrari 296 GTB</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                                    <div class="swiper-slide" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c40864" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c40864" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $654,165			                                                </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a8i/">Audi a8i 2023</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                                    <div class="swiper-slide" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c40c7b" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c40c7b" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $98,764			                                                </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/tucsonplug-in-hybrid/">TUCSONPlug-in Hybrid</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                                    <div class="swiper-slide" style="width: 785px; margin-right: 15px;">
                            <div class="feature-card">
                                <div class="product-img">
                                                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                                                                                                        <div id="6594e66c41221" class="hidden">
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg"></a>
                                                                                                    <a href="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg"></a>
                                                                                            </div>
                                        <div class="number-of-img">
                                            <a href="#6594e66c41221" class="btn-gallery"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/home1/icon/gallery-icon-1.svg" alt="gallery-icon">3</a>
                                        </div>
                                                                            </div>
                                <div class="product-content">
                                    <div class="price">
                                        <strong>
                                                                        $94,785				<del>$96,765</del>
                                                    </strong>
                                    </div>
                                    <h5><a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/">The new SONATA</a></h5>
                                    <ul class="features">
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/milage_two.svg" alt="features-img">
                                            25,100 miles
                                        </li>
                                        <li>

                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/info_two.svg" alt="features-img">
                                            Petrol + Gas                                                </li>
                                        <li>
                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/img/icons/engine_two.svg" alt="features-img">
                                            22,231 cc                                                </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                            </div>
            <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
        </div>
    </div>











</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-17a4338 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="17a4338" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-840a178" data-id="840a178" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-922b167 elementor-widget elementor-widget-drivco_banner" data-id="922b167" data-element_type="widget" data-widget_type="drivco_banner.default">
        <div class="elementor-widget-container">
    

            <div class="home2-inner-banner">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-banner-content section-title-2">
                                                            <h2>Confusion, Which is Best Car?</h2>
                                                                                            <p>Car servicing is the regular maintenance and inspection of a vehicle to ensure that it is operating safely and efficiently.</p>
                                                                                            <button class="primary-btn3" type="button" data-bs-toggle="modal" data-bs-target="#sellUsModal01" fdprocessedid="vhmvoi">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="15" viewBox="0 0 24 15"><path d="M3.25985 0C3.15704 0 3.05844 0.0413135 2.98574 0.114852C2.91304 0.18839 2.87219 0.28813 2.87219 0.392129C2.87219 0.496128 2.91304 0.595867 2.98574 0.669405C3.05844 0.742944 3.15704 0.784257 3.25985 0.784257H4.8105C4.91332 0.784257 5.01192 0.742944 5.08462 0.669405C5.15732 0.595867 5.19816 0.496128 5.19816 0.392129C5.19816 0.28813 5.15732 0.18839 5.08462 0.114852C5.01192 0.0413135 4.91332 0 4.8105 0H3.25985ZM5.77966 0C5.67684 0 5.57824 0.0413135 5.50554 0.114852C5.43284 0.18839 5.39199 0.28813 5.39199 0.392129C5.39199 0.496128 5.43284 0.595867 5.50554 0.669405C5.57824 0.742944 5.67684 0.784257 5.77966 0.784257H10.3347C10.4375 0.784257 10.5361 0.742944 10.6088 0.669405C10.6815 0.595867 10.7223 0.496128 10.7223 0.392129C10.7223 0.28813 10.6815 0.18839 10.6088 0.114852C10.5361 0.0413135 10.4375 0 10.3347 0H5.77966Z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4.22917 2.7464C4.12636 2.7464 4.02776 2.78771 3.95505 2.86125C3.88235 2.93479 3.84151 3.03453 3.84151 3.13853C3.84151 3.24253 3.88235 3.34227 3.95505 3.4158C4.02776 3.48934 4.12636 3.53066 4.22917 3.53066H13.1454C14.653 3.53066 15.5822 3.76829 16.3256 4.15002C16.9575 4.47431 17.4672 4.90546 18.1055 5.44542C18.2375 5.55698 18.3749 5.67305 18.5201 5.79402L18.6101 5.86892L18.726 5.88127C22.2653 6.25811 23.0622 7.46822 23.2246 8.08778V9.60865C23.2246 9.71265 23.1838 9.81239 23.1111 9.88593C23.0384 9.95947 22.9398 10.0008 22.8369 10.0008H21.8356C21.6511 8.88811 20.6943 8.04014 19.5418 8.04014C18.3893 8.04014 17.4325 8.88811 17.248 10.0008H10.2058C10.0212 8.88811 9.06448 8.04014 7.91196 8.04014C6.75944 8.04014 5.80269 8.88811 5.61816 10.0008H3.7446C3.64178 10.0008 3.54318 10.0421 3.47048 10.1156C3.39778 10.1892 3.35693 10.2889 3.35693 10.3929C3.35693 10.4969 3.39778 10.5966 3.47048 10.6702C3.54318 10.7437 3.64178 10.785 3.7446 10.785H5.61816C5.80269 11.8977 6.75944 12.7457 7.91196 12.7457C9.06448 12.7457 10.0212 11.8977 10.2058 10.785H17.248C17.4325 11.8977 18.3893 12.7457 19.5418 12.7457C20.6943 12.7457 21.6511 11.8977 21.8356 10.785H22.8369C23.1454 10.785 23.4412 10.6611 23.6593 10.4405C23.8774 10.2199 23.9999 9.92065 23.9999 9.60865V7.99543L23.99 7.95191C23.7431 6.86983 22.5791 5.52855 18.9239 5.11407C18.8217 5.02859 18.7215 4.9435 18.6227 4.85978C17.9828 4.31766 17.3942 3.81887 16.6766 3.45047C15.7966 2.99893 14.7391 2.7464 13.1454 2.7464H4.22917ZM17.9912 10.3929C17.9912 9.97691 18.1545 9.57795 18.4453 9.2838C18.7361 8.98965 19.1306 8.82439 19.5418 8.82439C19.9531 8.82439 20.3475 8.98965 20.6383 9.2838C20.9291 9.57795 21.0925 9.97691 21.0925 10.3929C21.0925 10.8089 20.9291 11.2079 20.6383 11.502C20.3475 11.7962 19.9531 11.9614 19.5418 11.9614C19.1306 11.9614 18.7361 11.7962 18.4453 11.502C18.1545 11.2079 17.9912 10.8089 17.9912 10.3929ZM7.91196 8.82439C7.5007 8.82439 7.10629 8.98965 6.81549 9.2838C6.52468 9.57795 6.36131 9.97691 6.36131 10.3929C6.36131 10.8089 6.52468 11.2079 6.81549 11.502C7.10629 11.7962 7.5007 11.9614 7.91196 11.9614C8.32322 11.9614 8.71763 11.7962 9.00843 11.502C9.29923 11.2079 9.46261 10.8089 9.46261 10.3929C9.46261 9.97691 9.29923 9.57795 9.00843 9.2838C8.71763 8.98965 8.32322 8.82439 7.91196 8.82439Z"></path><path d="M0 5.09873C0 4.99473 0.0408428 4.89499 0.113543 4.82146C0.186244 4.74792 0.284847 4.7066 0.387662 4.7066H4.74886C4.85167 4.7066 4.95027 4.74792 5.02297 4.82146C5.09567 4.89499 5.13652 4.99473 5.13652 5.09873C5.13652 5.20273 5.09567 5.30247 5.02297 5.37601C4.95027 5.44955 4.85167 5.49086 4.74886 5.49086H0.387662C0.284847 5.49086 0.186244 5.44955 0.113543 5.37601C0.0408428 5.30247 0 5.20273 0 5.09873ZM15.6836 5.60575C15.7563 5.67929 15.7971 5.77901 15.7971 5.88299C15.7971 5.98697 15.7563 6.08669 15.6836 6.16022L15.6532 6.19101C15.2897 6.55865 14.7968 6.76522 14.2828 6.76528H8.14089C8.03808 6.76528 7.93948 6.72397 7.86678 6.65043C7.79408 6.57689 7.75323 6.47715 7.75323 6.37315C7.75323 6.26915 7.79408 6.16941 7.86678 6.09587C7.93948 6.02234 8.03808 5.98102 8.14089 5.98102H14.2826C14.4354 5.98104 14.5866 5.95063 14.7277 5.89152C14.8688 5.83241 14.997 5.74577 15.105 5.63654L15.1355 5.60575C15.2082 5.53224 15.3068 5.49094 15.4096 5.49094C15.5123 5.49094 15.6109 5.53224 15.6836 5.60575ZM8.52856 14.6079C8.52856 14.5039 8.5694 14.4041 8.6421 14.3306C8.7148 14.257 8.8134 14.2157 8.91622 14.2157H10.5638C10.6666 14.2157 10.7652 14.257 10.8379 14.3306C10.9106 14.4041 10.9514 14.5039 10.9514 14.6079C10.9514 14.7118 10.9106 14.8116 10.8379 14.8851C10.7652 14.9587 10.6666 15 10.5638 15H8.91622C8.8134 15 8.7148 14.9587 8.6421 14.8851C8.5694 14.8116 8.52856 14.7118 8.52856 14.6079ZM11.2422 14.6079C11.2422 14.5039 11.283 14.4041 11.3557 14.3306C11.4284 14.257 11.527 14.2157 11.6298 14.2157H15.991C16.0939 14.2157 16.1925 14.257 16.2652 14.3306C16.3379 14.4041 16.3787 14.5039 16.3787 14.6079C16.3787 14.7118 16.3379 14.8116 16.2652 14.8851C16.1925 14.9587 16.0939 15 15.991 15H11.6298C11.527 15 11.4284 14.9587 11.3557 14.8851C11.283 14.8116 11.2422 14.7118 11.2422 14.6079Z"></path></svg>                                        Sell Your Car                                    </button>
                                                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal signUp-modal sell-with-us fade" id="sellUsModal01" tabindex="-1" aria-labelledby="sellUsModal01Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                                                    <h4 class="modal-title" id="sellUsModal01Label">Sell Your Car</h4>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
                </div>
                <div class="modal-body">
                    
<div class="wpcf7 js" id="wpcf7-f693-p18-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/home-02/#wpcf7-f693-p18-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="693">
<input type="hidden" name="_wpcf7_version" value="5.8.3">
<input type="hidden" name="_wpcf7_locale" value="en_US">
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f693-p18-o1">
<input type="hidden" name="_wpcf7_container_post" value="18">
<input type="hidden" name="_wpcf7_posted_data_hash" value="">
</div>
<div class="row">
    <div class="col-lg-12 mb-15">
        <h5>Your Personal Info</h5>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Full Name*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name*" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Phone*</label>
            <span class="wpcf7-form-control-wrap" data-name="tel-362"><input size="40" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="+880- 123 234 ***" value="" type="tel" name="tel-362"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Email (Optional)</label>
            <span class="wpcf7-form-control-wrap" data-name="email-336"><input size="40" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Enter your email address" value="" type="email" name="email-336"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Location*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Enter your address" value="" type="text" name="text-651"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 mb-15 mt-25">
        <h5>Your Car Info</h5>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Car Brand Name*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Toyota" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Model*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="RS eTN 80" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Reg. Year*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="2023" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Mileage*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="23,456 miles" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Fuel Type*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Petrol" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-6 mb-20">
        <div class="form-inner">
            <label>Selling Price*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-651"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Ex- $23,342.000" value="" type="text" name="text-651"></span>
        </div>
    </div>
    <div class="col-md-12 mb-35">
        <div class="form-inner">
            <label>Your Car Note*</label>
            <span class="wpcf7-form-control-wrap" data-name="textarea-39"><textarea cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Write somethings" name="textarea-39"></textarea></span>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="form-inner">
            <button class="primary-btn2" type="submit">Submit Now</button>
        </div>
    </div>
</div><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
                </div>
            </div>
        </div>
    </div>





</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-c41830d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c41830d" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0f12c96" data-id="0f12c96" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-4f8cb2d elementor-widget elementor-widget-drivco_vehicle_product_slider" data-id="4f8cb2d" data-element_type="widget" data-widget_type="drivco_vehicle_product_slider.default">
        <div class="elementor-widget-container">
    



            <div class="recent-launched-car ">
        <div class="row mb-50">
            <div class="col-lg-12 d-flex align-items-end justify-content-between gap-3 flex-wrap">
                <div class="section-title-2">
                                                    <h2>Recent Launched Car</h2>
                                                                                <p>Here are some of the featured cars in different categories</p>
                                            </div>
                                            <div class="slider-btn-group2">
                        <div class="slider-btn prev-1 swiper-button-disabled" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="true" fdprocessedid="167r3l">
                            <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 6.50008L8 0L2.90909 6.50008L8 13L0 6.50008Z"></path>
                            </svg>
                        </div>
                        <div class="slider-btn next-1" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false" fdprocessedid="yfc3k">
                            <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8 6.50008L0 0L5.09091 6.50008L0 13L8 6.50008Z"></path>
                            </svg>
                        </div>
                    </div>
                                    </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="swiper recent-launch-car-slider swiper-container-initialized swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">
                                                            <div class="swiper-slide swiper-slide-active" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img fetchpriority="high" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/audi-tt-roadster/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $85,032				<del>$89,600</del>
                                                        </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-tt-roadster/">Audi TT Roadster</a></h6>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide swiper-slide-next" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a4-sedan/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $75,000				<del>$78,200</del>
                                                        </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a4-sedan/">Audi A4 Sedan</a></h6>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-296-gtb/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $654,165			                                                    </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-296-gtb/">Ferrari 296 GTB</a></h6>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a8i/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $654,165			                                                    </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a8i/">Audi a8i 2023</a></h6>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/tucsonplug-in-hybrid/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $98,764			                                                    </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/tucsonplug-in-hybrid/">TUCSONPlug-in Hybrid</a></h6>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                            </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                        <div class="price">
                                            <strong>
                                                                            $94,785				<del>$96,765</del>
                                                        </strong>
                                        </div>
                                        <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/">The new SONATA</a></h6>
                                    </div>
                                </div>
                            </div>
                                                    </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            </div>
        </div>
    </div>









</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-fb7e63b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fb7e63b" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a36cbda" data-id="a36cbda" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-0e20e9f elementor-widget elementor-widget-drivco_vehicle_brand_grid" data-id="0e20e9f" data-element_type="widget" data-widget_type="drivco_vehicle_brand_grid.default">
        <div class="elementor-widget-container">
    
<div class="browse-used-car-section mb-100">
    <div class="container">
        <div class="row mb-50">
            <div class="col-lg-12">
                <div class="section-title-2 text-center">
                                                    <h2>Browse Used Car </h2>
                                                                                <p>There has 30+ Category Available</p>
                                            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="browse-car-filter-area">
                    <ul class="nav nav-tabs" id="myTab3" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="tab-all" data-bs-toggle="tab" data-bs-target="#car-all" type="button" role="tab" aria-controls="car-all" aria-selected="true" fdprocessedid="dr9kks">All</button>
                        </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab33" data-bs-toggle="tab" data-bs-target="#car33" type="button" role="tab" aria-controls="car33" aria-selected="false" tabindex="-1">Audi</button>
                            </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab26" data-bs-toggle="tab" data-bs-target="#car26" type="button" role="tab" aria-controls="car26" aria-selected="false" tabindex="-1">BMW</button>
                            </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab29" data-bs-toggle="tab" data-bs-target="#car29" type="button" role="tab" aria-controls="car29" aria-selected="false" tabindex="-1">Ferrari</button>
                            </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab34" data-bs-toggle="tab" data-bs-target="#car34" type="button" role="tab" aria-controls="car34" aria-selected="false" tabindex="-1">Mercedes</button>
                            </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab31" data-bs-toggle="tab" data-bs-target="#car31" type="button" role="tab" aria-controls="car31" aria-selected="false" tabindex="-1">Sedan</button>
                            </li>
                                                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="tab28" data-bs-toggle="tab" data-bs-target="#car28" type="button" role="tab" aria-controls="car28" aria-selected="false" tabindex="-1">Tesla</button>
                            </li>
                                                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content" id="myTab3Content">
                    
                        <div class="tab-pane fade" id="car33" role="tabpanel" aria-labelledby="tab33">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img fetchpriority="high" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $85,032				<del>$89,600</del>
                                                                </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-tt-roadster/">Audi TT Roadster</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $75,000				<del>$78,200</del>
                                                                </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a4-sedan/">Audi A4 Sedan</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $654,165			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a8i/">Audi a8i 2023</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-7.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-7.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-7-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-7-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-7-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $54,614			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/mazda-cx-30-2021/">Mazda CX-30-2021</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                        <div class="tab-pane fade" id="car26" role="tabpanel" aria-labelledby="tab26">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/bmw.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $654,165			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/bmw-3-series-sedan/">BMW 3 Series Sedan</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/bmw.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $79,876			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/subaru-outback-2023/">Subaru Outback-2023</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                        <div class="tab-pane fade" id="car29" role="tabpanel" aria-labelledby="tab29">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Ferrari-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $94,785				<del>$96,765</del>
                                                                </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/">The new SONATA</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-13-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Ferrari-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $57,432				<del>$65,735</del>
                                                                </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/bmw-x3-sport-utility-vehicle/">BMW X3 Sport Utility Vehicle</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                        <div class="tab-pane fade" id="car34" role="tabpanel" aria-labelledby="tab34">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mercedes-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $654,165			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-296-gtb/">Ferrari 296 GTB</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mercedes-Logo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $4,160				<del>$4,250</del>
                                                                </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/toyota-highlander/">Toyota Highlander</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                        <div class="tab-pane fade" id="car31" role="tabpanel" aria-labelledby="tab31">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-12.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-12.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-12-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-12-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-12-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/sedan/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/sedan.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $46,545			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-sf90-stradale/">Ferrari SF90 Stradale</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-3.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-3.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-3-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-3-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-3-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/sedan/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/sedan.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $55,656			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/volkswagen-golf-2023/">Volkswagen Golf-2023</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                        <div class="tab-pane fade" id="car28" role="tabpanel" aria-labelledby="tab28">
                            <div class="row justify-content-center g-4">
                                                                            <div class="col-xl-3 col-md-4 col-sm-6">
                                        <div class="product-card2 two">
                                                                                                    <div class="product-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                <div class="product-content">
                                                <div class="company-logo">
                                                    <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/tesla/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/TeslaLogo.svg" alt="brand-icon"></a>
                                                </div>
                                                <div class="price">
                                                    <strong>
                                                                                    $36,464			                                                            </strong>
                                                </div>
                                                <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/kia-telluride-2023/">Kia Telluride-2023</a></h6>
                                            </div>
                                        </div>
                                    </div>

                                                                    </div>
                        </div>
                    
                    <div class="tab-pane fade active show" id="car-all" role="tabpanel" aria-labelledby="tab-all">
                        <div class="row justify-content-center g-4">
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img fetchpriority="high" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-25-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $85,032				<del>$89,600</del>
                                                            </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-tt-roadster/">Audi TT Roadster</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/11/vehicle-24-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $75,000				<del>$78,200</del>
                                                            </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a4-sedan/">Audi A4 Sedan</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-20-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mercedes-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $654,165			                                                        </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-296-gtb/">Ferrari 296 GTB</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-23-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/audi/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Audi-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $654,165			                                                        </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/audi-a8i/">Audi a8i 2023</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mezda/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mask-grou.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $98,764			                                                        </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/tucsonplug-in-hybrid/">TUCSONPlug-in Hybrid</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Ferrari-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $94,785				<del>$96,765</del>
                                                            </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/">The new SONATA</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-16.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-16.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-16-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-16-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-16-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/jeep/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Jeep-Logo.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $45,645			                                                        </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/toyota-crown-royal/">Toyota Crown Royal</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                                    <div class="col-xl-3 col-md-4 col-sm-6">
                                    <div class="product-card2 two">
                                                                                            <div class="product-img">
                                                <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                    </div>
                                                                                        <div class="product-content">
                                            <div class="company-logo">
                                                <a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mezda/"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/Mask-grou.svg" alt="brand-icon"></a>
                                            </div>
                                            <div class="price">
                                                <strong>
                                                                                $45,500				<del>$46,545</del>
                                                            </strong>
                                            </div>
                                            <h6><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-f8-tributo/">Ferrari F8 Tributo</a></h6>
                                        </div>
                                    </div>
                                </div>
                                                            </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-8a4a4d9 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="8a4a4d9" data-element_type="section">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-391917a" data-id="391917a" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-33b0d52 elementor-widget elementor-widget-drivco_how_it_work" data-id="33b0d52" data-element_type="widget" data-widget_type="drivco_how_it_work.default">
        <div class="elementor-widget-container">
    

            <div class="how-it-work-section style-2">
        <div class="container">
            <div class="row mb-50">
                <div class="col-lg-12 d-flex align-items-end justify-content-between gap-3 flex-wrap">
                    <div class="section-title-2">
                                                            <h2>How Does It Work</h2>
                                                                                            <p>Here are some of the featured cars in different categories</p>
                                                    </div>
                                                    <div class="video-btn">
                            <a class="video-popup" href="https://www.youtube.com/watch?v=YIrR5uQuFlQ"><i class="bi bi-play-circle"></i>Watch Video</a>
                        </div>
                                            </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="work-process-group">
                        <div class="row justify-content-center g-lg-0 gy-5">
                                                                    <div class="col-lg-3 col-sm-6">
                                    <div class="single-work-process text-center">
                                        <div class="step">
                                            <span>01</span>
                                        </div>
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none"><mask id="mask0_807_15" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36"><rect width="36" height="36" fill="#D9D9D9"></rect></mask><g mask="url(#mask0_807_15)"><path d="M35.9655 35.2853L30.692 21.3937C30.6482 21.2784 30.5654 21.182 30.4579 21.1215L24.8409 17.957L26.4808 15.3569C27.4873 13.7598 28.0193 11.9141 28.0193 10.0195C28.0193 4.49472 23.5246 0 17.9998 0C12.475 0 7.9803 4.49472 7.9803 10.0195C7.9803 11.9146 8.51256 13.7603 9.51958 15.357L11.159 17.9571L5.54187 21.1215C5.43434 21.182 5.35146 21.2784 5.30765 21.3937L0.0342276 35.2853C-0.00416178 35.3867 -0.0104268 35.4973 0.0162842 35.6023C0.0429951 35.7073 0.101386 35.8015 0.183522 35.8722C0.265657 35.9428 0.367552 35.9865 0.475359 35.9972C0.583165 36.0079 0.691653 35.9851 0.786078 35.932L9.2635 31.156L17.7409 35.932C17.8199 35.9765 17.9091 35.9999 17.9998 35.9999C18.0905 35.9999 18.1796 35.9765 18.2586 35.932L26.7361 31.156L35.2135 35.932C35.3079 35.9853 35.4164 36.0081 35.5243 35.9975C35.6321 35.9868 35.7341 35.9431 35.8163 35.8725C35.8984 35.8018 35.9569 35.7075 35.9836 35.6025C36.0103 35.4974 36.0039 35.3867 35.9655 35.2853ZM18.5272 27.3312C18.8626 27.2127 19.1481 26.9843 19.3373 26.6831C19.3641 26.6409 23.8534 19.5229 23.8534 19.5229L26.1399 30.2813L18.5272 34.5701V27.3312ZM10.4117 14.7943C9.51107 13.3662 9.03505 11.7152 9.03505 10.0194C9.03505 5.0762 13.0566 1.05462 17.9999 1.05462C22.9431 1.05462 26.9647 5.0762 26.9647 10.0194C26.9647 11.7148 26.4888 13.366 25.5888 14.7943C25.5184 14.9059 18.57 25.9247 18.4488 26.115C18.4476 26.1166 18.4466 26.1183 18.4456 26.1199C18.3478 26.2746 18.1812 26.3671 17.9999 26.3671C17.8184 26.3671 17.6511 26.2742 17.5531 26.1202C17.4827 26.0085 10.5204 14.9679 10.4141 14.7982L10.4117 14.7943ZM6.22586 21.9466L11.1418 19.1772L10.2854 23.2064C10.269 23.2833 10.2701 23.3629 10.2884 23.4393C10.3068 23.5158 10.342 23.5871 10.3915 23.6482C10.441 23.7093 10.5035 23.7585 10.5745 23.7923C10.6455 23.8261 10.7231 23.8436 10.8017 23.8436C10.9224 23.8434 11.0395 23.8018 11.1332 23.7258C11.227 23.6497 11.2919 23.5438 11.317 23.4258L12.1464 19.5233L16.662 26.6845C16.8519 26.9849 17.1374 27.2126 17.4724 27.3311V34.5702L9.85989 30.2814L10.8785 25.4889C10.8929 25.4212 10.8938 25.3513 10.8812 25.2832C10.8686 25.2151 10.8427 25.1502 10.805 25.0921C10.7673 25.034 10.7185 24.9839 10.6614 24.9447C10.6044 24.9054 10.5401 24.8778 10.4724 24.8634C10.4046 24.849 10.3347 24.848 10.2666 24.8606C10.1985 24.8732 10.1335 24.8991 10.0754 24.9368C10.0173 24.9745 9.96726 25.0233 9.92804 25.0804C9.88882 25.1375 9.86124 25.2018 9.84688 25.2696L8.79719 30.208L1.53701 34.2984L6.22586 21.9466ZM27.2025 30.2081L24.8581 19.1771L29.7738 21.9466L34.4627 34.2984L27.2025 30.2081Z" fill="#13141A"></path><path d="M23.8007 10.0195C23.8007 6.82102 21.1984 4.21875 17.9999 4.21875C14.8014 4.21875 12.1991 6.82102 12.1991 10.0195C12.1991 13.218 14.8014 15.8203 17.9999 15.8203C21.1984 15.8203 23.8007 13.218 23.8007 10.0195ZM13.2538 10.0195C13.2538 7.4025 15.3828 5.27344 17.9999 5.27344C20.6169 5.27344 22.746 7.4025 22.746 10.0195C22.746 12.6366 20.6169 14.7656 17.9999 14.7656C15.3828 14.7656 13.2538 12.6366 13.2538 10.0195Z" fill="#13141A"></path><path d="M21.6913 10.0195C21.6913 7.98413 20.0353 6.32812 17.9999 6.32812C15.9645 6.32812 14.3085 7.98413 14.3085 10.0195C14.3085 12.0549 15.9645 13.7109 17.9999 13.7109C20.0353 13.7109 21.6913 12.0549 21.6913 10.0195ZM15.3632 10.0195C15.3632 8.56561 16.546 7.38281 17.9999 7.38281C19.4538 7.38281 20.6366 8.56561 20.6366 10.0195C20.6366 11.4735 19.4538 12.6562 17.9999 12.6562C16.546 12.6562 15.3632 11.4735 15.3632 10.0195Z" fill="#13141A"></path></g></svg>                                                </div>
                                        <div class="content">
                                                                                                    <h6>Choose Any where</h6>
                                                                                                                                                        <p>Car servicing is the regular maintenance and inspection of a vehicle to ensure.</p>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="col-lg-3 col-sm-6">
                                    <div class="single-work-process text-center">
                                        <div class="step">
                                            <span>02</span>
                                        </div>
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none"><mask id="mask0_807_17" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36"><rect width="36" height="36" fill="#D9D9D9"></rect></mask><g mask="url(#mask0_807_17)"><path d="M34.4696 1H9.32342C8.47862 1.00098 7.79403 1.68161 7.79304 2.52153V9.41735L6.64315 7.70248C6.1168 6.91312 5.05826 6.67629 4.24258 7.16547L1.87682 8.5796C1.10208 9.03156 0.533728 9.76452 0.291229 10.6244C-0.57179 13.7487 0.0685646 19.1313 8.01515 27.0331C14.3346 33.3095 19.0464 34.9999 22.2938 34.9999C23.0456 35.0033 23.7946 34.9062 24.5204 34.7111C25.3849 34.47 26.1221 33.9058 26.5777 33.1365L27.9982 30.782C28.4883 29.9717 28.2503 28.9214 27.4581 28.3983L21.7933 24.6439C21.0162 24.1329 19.9746 24.301 19.3999 25.03L17.7506 27.138C17.6672 27.2472 17.5471 27.3228 17.4123 27.3512C17.2774 27.3796 17.1368 27.3588 17.016 27.2926L16.7022 27.1207C15.6693 26.561 14.3838 25.8641 11.7876 23.2829C11.5261 23.0227 11.268 22.7591 11.0134 22.4923H34.4696C35.3123 22.4929 35.9967 21.8157 36 20.9779V2.52153C35.999 1.68161 35.3144 1.00098 34.4696 1ZM16.1278 28.1686L16.4327 28.3351C17.1991 28.7611 18.1638 28.5634 18.6983 27.8708L20.3475 25.7628C20.4379 25.6483 20.5683 25.5718 20.7129 25.5484C20.8574 25.5251 21.0055 25.5567 21.1277 25.6369L26.7925 29.3912C26.9164 29.4733 27.0037 29.5996 27.0364 29.744C27.0692 29.8884 27.0448 30.0398 26.9683 30.1668L25.5478 32.5213C25.2511 33.0271 24.7692 33.3991 24.2029 33.5596C21.366 34.3352 16.4009 33.6789 8.86544 26.1865C1.32993 18.694 0.672276 13.7582 1.45062 10.9401C1.61186 10.3771 1.98582 9.89801 2.49424 9.60292L4.86246 8.18999C4.99024 8.11408 5.14247 8.0899 5.28767 8.12244C5.43288 8.15497 5.55996 8.24174 5.64264 8.36479L9.42055 13.9968C9.50136 14.1183 9.53319 14.2655 9.50972 14.4093C9.48625 14.553 9.40919 14.6827 9.29388 14.7725L7.17294 16.4127C6.47647 16.9439 6.27757 17.9029 6.70602 18.6646L6.87404 18.9677C7.47417 20.062 8.22016 21.4236 10.9395 24.1266C13.6588 26.8296 15.0278 27.5718 16.1278 28.1686ZM34.7997 20.9779C34.7988 21.0641 34.7635 21.1465 34.7017 21.2068C34.6398 21.2672 34.5564 21.3008 34.4697 21.3002H9.93072C9.15126 20.414 8.47909 19.4399 7.92801 18.3979L7.75514 18.0847C7.68846 17.9649 7.66741 17.8253 7.69585 17.6914C7.72429 17.5575 7.80032 17.4382 7.91 17.3555L10.0309 15.7153C10.7645 15.144 10.9335 14.1083 10.4192 13.3357L8.99329 11.2079V2.52153C8.99282 2.4783 9.00102 2.43542 9.01744 2.39539C9.03386 2.35536 9.05815 2.31899 9.0889 2.28843C9.11964 2.25786 9.15622 2.23371 9.19648 2.21738C9.23674 2.20106 9.27988 2.1929 9.32335 2.19338H34.4696C34.5131 2.1929 34.5562 2.20106 34.5965 2.21738C34.6368 2.23371 34.6733 2.25786 34.7041 2.28843C34.7348 2.31899 34.7591 2.35536 34.7755 2.39539C34.792 2.43542 34.8002 2.4783 34.7997 2.52153V20.9779H34.7997Z" fill="#13141A"></path><path d="M32.4026 3.76292L22.3723 11.3258C22.234 11.4257 22.0674 11.4796 21.8964 11.4796C21.7254 11.4796 21.5588 11.4257 21.4205 11.3258L11.3939 3.76292C11.3311 3.71555 11.2595 3.68095 11.1832 3.66108C11.107 3.64122 11.0275 3.63649 10.9494 3.64716C10.8713 3.65782 10.7961 3.68368 10.728 3.72326C10.66 3.76283 10.6004 3.81535 10.5528 3.8778C10.5052 3.94025 10.4704 4.01142 10.4504 4.08724C10.4304 4.16306 10.4256 4.24205 10.4364 4.3197C10.4471 4.39736 10.4731 4.47214 10.5129 4.5398C10.5527 4.60746 10.6055 4.66665 10.6684 4.71401L20.6962 12.2763C21.0437 12.5315 21.4644 12.6693 21.8965 12.6693C22.3286 12.6693 22.7493 12.5315 23.0968 12.2763L33.1277 4.71401C33.1905 4.66666 33.2434 4.60744 33.2832 4.53974C33.323 4.47205 33.3491 4.39722 33.3598 4.31952C33.3705 4.24183 33.3656 4.16279 33.3456 4.08695C33.3255 4.01111 33.2906 3.93994 33.2429 3.87752C33.1467 3.75163 33.0042 3.66884 32.8466 3.64736C32.6891 3.62587 32.5294 3.66743 32.4026 3.76292ZM16.7748 12.3264L10.6269 18.872C10.5206 18.9881 10.4647 19.1412 10.4712 19.2981C10.4777 19.4549 10.5461 19.6029 10.6616 19.71C10.7771 19.8171 10.9304 19.8746 11.0882 19.8701C11.2461 19.8655 11.3958 19.7994 11.5049 19.6859L17.6528 13.1374C17.7503 13.02 17.799 12.87 17.7889 12.7181C17.7788 12.5661 17.7106 12.4238 17.5985 12.3202C17.4863 12.2166 17.3385 12.1595 17.1854 12.1607C17.0322 12.1618 16.8854 12.2211 16.7748 12.3264ZM27.0578 12.3264C27.004 12.2691 26.9394 12.2229 26.8677 12.1903C26.796 12.1578 26.7185 12.1397 26.6398 12.137C26.561 12.1342 26.4824 12.1469 26.4086 12.1744C26.3348 12.2018 26.2671 12.2435 26.2095 12.2969C26.1518 12.3503 26.1053 12.4145 26.0726 12.4859C26.0399 12.5572 26.0217 12.6342 26.0189 12.7125C26.0162 12.7908 26.0289 12.8689 26.0565 12.9423C26.0841 13.0157 26.126 13.083 26.1798 13.1403L32.3259 19.6859C32.3797 19.7432 32.4442 19.7894 32.516 19.8219C32.5877 19.8544 32.6651 19.8726 32.7439 19.8753C32.8227 19.8781 32.9012 19.8654 32.9751 19.8379C33.0489 19.8105 33.1166 19.7688 33.1742 19.7154C33.2319 19.662 33.2784 19.5977 33.3111 19.5264C33.3438 19.4551 33.362 19.3781 33.3648 19.2998C33.3675 19.2215 33.3547 19.1434 33.3271 19.07C33.2995 18.9966 33.2577 18.9293 33.2039 18.872L27.0578 12.3264Z" fill="#13141A"></path></g></svg>                                                </div>
                                        <div class="content">
                                                                                                    <h6>Contact With Us</h6>
                                                                                                                                                        <p>Car servicing is the regular maintenance and inspection of a vehicle to ensure.</p>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="col-lg-3 col-sm-6">
                                    <div class="single-work-process text-center">
                                        <div class="step">
                                            <span>03</span>
                                        </div>
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none"><mask id="mask0_807_23" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36"><rect width="36" height="36" fill="#D9D9D9"></rect></mask><g mask="url(#mask0_807_23)"><path d="M30 6.35639V3C29.9979 1.344 28.656 0.002112 27 0H3C1.344 0.002112 0.002112 1.344 0 3V16.2C0.0046464 17.7322 1.16609 19.0137 2.69042 19.1691L4.94581 25.0237C5.54162 26.5697 7.27768 27.3398 8.82374 26.7447L22.908 21.3192C21.9348 23.8613 22.2117 26.7129 23.6553 29.0203L24 29.5716V35.4C24 35.7315 24.2685 36 24.6 36H35.4C35.7315 36 36 35.7315 36 35.4V15.5947C35.9945 13.5199 35.1681 11.5317 33.7013 10.0643L30 6.35639ZM30 9.94472L31.821 14.6718C32.1779 15.5997 31.7154 16.6408 30.7877 16.998L29.7468 17.4C29.9129 17.0217 29.9991 16.6132 30 16.2V9.94472ZM1.2 16.2V3C1.2 2.00609 2.00609 1.2 3 1.2H27C27.9939 1.2 28.8 2.00609 28.8 3V6.81362H28.7947L28.8 6.82725V16.2C28.7953 16.3046 28.7817 16.4086 28.7592 16.5108L23.2632 11.0142C22.0278 9.80732 20.0583 9.79799 18.8118 10.9923C17.565 12.1873 17.4902 14.1553 18.6432 15.4408L20.9862 18H3C2.00609 18 1.2 17.1939 1.2 16.2ZM8.88661 19.2L4.61998 20.8426L3.98884 19.2H8.88661ZM8.39221 25.6247C7.46461 25.9822 6.42286 25.5198 6.0654 24.5922L5.05317 21.96L12.2154 19.2V19.1964H22.086L22.8659 20.0466L8.39221 25.6247ZM34.8 34.8H25.2V30H34.8V34.8ZM34.8 28.8H24.933L24.6728 28.3842C23.2098 26.0463 23.1516 23.0934 24.5208 20.7C24.584 20.5896 24.6104 20.462 24.5963 20.3356C24.5821 20.2092 24.5282 20.0905 24.4422 19.9968L19.5254 14.6328C18.7922 13.8303 18.8334 12.5896 19.6184 11.838C20.4036 11.0862 21.6449 11.0985 22.4147 11.8653L31.9758 21.4242L32.8242 20.5758L30.6042 18.3558L31.2198 18.1158C32.7645 17.5198 33.5343 15.7852 32.94 14.2396L30.9092 8.96625L32.8529 10.914C34.095 12.1556 34.795 13.8385 34.8 15.5947V28.8Z" fill="#13141A"></path><path d="M6.83996 8.3999C7.70158 8.3999 8.39996 7.70148 8.39996 6.8399V3.9599C8.39996 3.09828 7.70154 2.3999 6.83996 2.3999H3.95996C3.09834 2.3999 2.39996 3.09832 2.39996 3.9599V6.8399C2.39996 7.70152 3.09838 8.3999 3.95996 8.3999H6.83996ZM3.59996 6.8399V5.9999H4.79996V4.7999H3.59996V3.9599C3.59996 3.76114 3.76124 3.5999 3.95996 3.5999H6.83996C7.03872 3.5999 7.19996 3.76118 7.19996 3.9599V4.7999H5.99996V5.9999H7.19996V6.8399C7.19996 7.03866 7.03868 7.1999 6.83996 7.1999H3.95996C3.7612 7.1999 3.59996 7.03862 3.59996 6.8399ZM2.99996 10.1999H5.39996V11.3999H2.99996V10.1999ZM2.99996 13.7999H5.39996V14.9999H2.99996V13.7999ZM13.8 13.7999H16.2V14.9999H13.8V13.7999ZM6.59996 10.1999H8.99996V11.3999H6.59996V10.1999ZM10.2 10.1999H12.6V11.3999H10.2V10.1999ZM13.8 10.1999H16.2V11.3999H13.8V10.1999ZM25.2 2.9999H26.4V4.7999H25.2V2.9999ZM22.8 2.9999H24V4.7999H22.8V2.9999ZM20.4 2.9999H21.6V4.7999H20.4V2.9999ZM18 2.9999H19.2V4.7999H18V2.9999ZM26.4 31.1999H27.6V32.3999H26.4V31.1999Z" fill="#13141A"></path></g></svg>                                                </div>
                                        <div class="content">
                                                                                                    <h6>Pay For The Car</h6>
                                                                                                                                                        <p>Car servicing is the regular maintenance and inspection of a vehicle to ensure.</p>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="col-lg-3 col-sm-6">
                                    <div class="single-work-process text-center">
                                        <div class="step">
                                            <span>04</span>
                                        </div>
                                        <div class="icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36" fill="none"><mask id="mask0_807_29" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="36" height="36"><rect width="36" height="36" fill="#D9D9D9"></rect></mask><g mask="url(#mask0_807_29)"><path d="M8.15663 20.3067C7.00062 20.1376 5.83666 20.0277 4.66933 19.9774C4.15747 19.9459 3.48278 20.2114 3.36593 21.4954C3.34413 21.8183 3.37545 22.1426 3.45865 22.4554C3.53619 22.7821 3.71099 23.0779 3.96021 23.3042C4.20942 23.5304 4.52146 23.6766 4.85553 23.7237L9.84525 24.4227C9.87017 24.4267 9.89538 24.4288 9.92063 24.4287C10.0181 24.4287 10.1139 24.4038 10.1988 24.3561C10.2837 24.3085 10.3548 24.2399 10.4052 24.1568C10.4555 24.0738 10.4835 23.9793 10.4863 23.8823C10.4891 23.7854 10.4667 23.6894 10.4212 23.6037C8.78006 20.4979 8.35942 20.3689 8.15663 20.3067ZM5.01309 22.6099C4.90348 22.5932 4.80142 22.5442 4.72011 22.4692C4.6388 22.3942 4.58198 22.2966 4.55701 22.1892C4.50441 21.9965 4.48254 21.7968 4.49218 21.5974C4.49396 21.4267 4.53279 21.2583 4.60601 21.1039H4.62184C5.91092 21.1842 7.36057 21.3004 7.75332 21.3694C8.17776 21.9344 8.55734 22.5315 8.88862 23.1552L5.01309 22.6099ZM31.3307 19.9774C30.1633 20.0277 28.9994 20.1376 27.8434 20.3067C27.6406 20.3689 27.2192 20.4979 25.5758 23.6067C25.5303 23.6924 25.5079 23.7884 25.5107 23.8853C25.5135 23.9823 25.5414 24.0768 25.5918 24.1598C25.6422 24.2429 25.7133 24.3115 25.7982 24.3591C25.883 24.4068 25.9789 24.4317 26.0763 24.4317C26.1016 24.4318 26.1268 24.4297 26.1517 24.4257L31.1414 23.7267C31.4755 23.6796 31.7876 23.5334 32.0368 23.3072C32.286 23.0809 32.4608 22.7851 32.5383 22.4584C32.6213 22.1455 32.6526 21.8213 32.6311 21.4984C32.5165 20.2114 31.838 19.9467 31.3307 19.9774ZM31.443 22.1892C31.418 22.2966 31.3612 22.3942 31.2799 22.4692C31.1986 22.5442 31.0965 22.5932 30.9869 22.6099L27.1114 23.1529C27.4429 22.5295 27.8222 21.9325 28.2459 21.3672C28.6455 21.2974 30.0966 21.1812 31.3849 21.1017C31.4671 21.254 31.5094 21.4245 31.5078 21.5974C31.5175 21.7968 31.4956 21.9965 31.443 22.1892ZM25.8268 20.8302C25.7699 20.7492 25.6925 20.6846 25.6026 20.6427C25.5126 20.6009 25.4132 20.5833 25.3142 20.5917C25.2622 20.5962 20.0689 21.0417 18.0019 21.0417C15.9348 21.0417 10.7408 20.5917 10.6896 20.5917C10.5906 20.583 10.491 20.6004 10.401 20.6423C10.3109 20.6842 10.2336 20.7489 10.1768 20.83C10.12 20.9111 10.0857 21.0057 10.0773 21.1043C10.069 21.2028 10.087 21.3018 10.1295 21.3912L11.6183 24.5344C11.6618 24.6258 11.7292 24.7038 11.8134 24.7604C11.8976 24.817 11.9956 24.8501 12.097 24.8562L17.9989 25.1922L23.9098 24.8562C24.0113 24.8502 24.1093 24.8172 24.1935 24.7606C24.2777 24.704 24.3451 24.6259 24.3885 24.5344L25.8773 21.3912C25.9194 21.3015 25.937 21.2024 25.9281 21.1039C25.9192 21.0053 25.8843 20.9109 25.8268 20.8302ZM23.5065 23.7552L18.0004 24.0717L12.4973 23.7552L11.5693 21.7962C13.1969 21.9282 16.4233 22.1712 18.0026 22.1712C19.5819 22.1712 22.8092 21.9282 24.4375 21.7962L23.5065 23.7552ZM21.2502 3.74216L22.084 4.05266C22.3566 4.15405 22.6042 4.31242 22.81 4.5171C23.0159 4.72178 23.1752 4.968 23.2773 5.23915L23.5894 6.07166C23.6301 6.17808 23.7024 6.26969 23.7966 6.33432C23.8909 6.39895 24.0026 6.43356 24.1171 6.43356C24.2316 6.43356 24.3433 6.39895 24.4376 6.33432C24.5318 6.26969 24.6041 6.17808 24.6448 6.07166L24.9569 5.24216C25.0591 4.9712 25.2184 4.72514 25.4241 4.52049C25.6298 4.31584 25.8771 4.15735 26.1495 4.05566L26.9832 3.74516C27.0902 3.70464 27.1823 3.63274 27.2472 3.53898C27.3122 3.44522 27.347 3.33403 27.347 3.22016C27.347 3.10628 27.3122 2.99509 27.2472 2.90133C27.1823 2.80757 27.0902 2.73567 26.9832 2.69516L26.1495 2.38466C25.8769 2.28309 25.6294 2.12456 25.4237 1.91975C25.218 1.71494 25.0588 1.46862 24.9569 1.1974L24.6478 0.361905C24.6071 0.255477 24.5348 0.163875 24.4406 0.0992427C24.3463 0.0346103 24.2346 0 24.1201 0C24.0056 0 23.8939 0.0346103 23.7996 0.0992427C23.7054 0.163875 23.6331 0.255477 23.5924 0.361905L23.2773 1.19141C23.1754 1.46262 23.0162 1.70894 22.8105 1.91375C22.6047 2.11856 22.3573 2.27709 22.0847 2.37866L21.251 2.68916C21.144 2.72967 21.0519 2.80157 20.987 2.89533C20.922 2.98909 20.8872 3.10028 20.8872 3.21415C20.8872 3.32803 20.922 3.43922 20.987 3.53298C21.0519 3.62674 21.144 3.69864 21.251 3.73915L21.2502 3.74216ZM24.1186 2.04641C24.3983 2.53341 24.8038 2.93711 25.2931 3.21565C24.8036 3.49399 24.3981 3.89775 24.1186 4.3849C23.8385 3.89799 23.4328 3.49433 22.9434 3.21565C23.4328 2.93698 23.8385 2.53332 24.1186 2.04641ZM27.6067 7.23341L28.2384 7.46891C28.4266 7.53921 28.5976 7.64881 28.7397 7.79034C28.8818 7.93187 28.9918 8.10204 29.0623 8.28941L29.299 8.91791C29.3394 9.02524 29.4117 9.11777 29.5064 9.18308C29.601 9.2484 29.7134 9.28341 29.8286 9.28341C29.9438 9.28341 30.0562 9.2484 30.1509 9.18308C30.2455 9.11777 30.3179 9.02524 30.3582 8.91791L30.5942 8.28941C30.6648 8.10199 30.7749 7.9318 30.9172 7.79027C31.0594 7.64874 31.2305 7.53916 31.4189 7.46891L32.0506 7.23341C32.1572 7.19259 32.249 7.12057 32.3137 7.02685C32.3784 6.93313 32.413 6.8221 32.413 6.70841C32.413 6.59471 32.3784 6.48368 32.3137 6.38996C32.249 6.29624 32.1572 6.22422 32.0506 6.1834L31.4189 5.94491C31.2306 5.87515 31.0597 5.7659 30.9176 5.62458C30.7756 5.48326 30.6658 5.31319 30.5957 5.12591L30.3582 4.49665C30.3179 4.38932 30.2455 4.2968 30.1509 4.23148C30.0562 4.16616 29.9438 4.13116 29.8286 4.13116C29.7134 4.13116 29.601 4.16616 29.5064 4.23148C29.4117 4.2968 29.3394 4.38932 29.299 4.49665L29.0623 5.12591C28.9918 5.31318 28.8818 5.48325 28.7397 5.62465C28.5976 5.76606 28.4266 5.87552 28.2384 5.94566L27.6059 6.18116C27.4989 6.22167 27.4069 6.29357 27.3419 6.38733C27.2769 6.48109 27.2421 6.59228 27.2421 6.70616C27.2421 6.82003 27.2769 6.93122 27.3419 7.02498C27.4069 7.11874 27.4989 7.19064 27.6059 7.23116L27.6067 7.23341ZM29.8282 6.07166C30.0003 6.31857 30.2156 6.53273 30.4637 6.70391C30.2161 6.87542 30.0009 7.08922 29.8282 7.33541C29.656 7.08908 29.4411 6.87524 29.1935 6.70391C29.4415 6.53271 29.6565 6.31855 29.8282 6.07166ZM31.1384 3.74216L31.7702 3.97766C31.9583 4.04771 32.1292 4.15706 32.2713 4.29833C32.4135 4.4396 32.5235 4.60952 32.5941 4.79666L32.8308 5.42516C32.8712 5.53249 32.9435 5.62501 33.0381 5.69033C33.1328 5.75565 33.2452 5.79066 33.3604 5.79066C33.4756 5.79066 33.588 5.75565 33.6827 5.69033C33.7773 5.62501 33.8496 5.53249 33.89 5.42516L34.1267 4.79666C34.197 4.60941 34.3069 4.43934 34.4489 4.29793C34.5909 4.15652 34.7617 4.04705 34.9499 3.97691L35.5824 3.74141C35.6893 3.70089 35.7814 3.62899 35.8464 3.53523C35.9113 3.44147 35.9461 3.33028 35.9461 3.21641C35.9461 3.10253 35.9113 2.99134 35.8464 2.89758C35.7814 2.80382 35.6893 2.73192 35.5824 2.69141L34.9506 2.45516C34.7625 2.38514 34.5917 2.2758 34.4497 2.13451C34.3077 1.99323 34.1978 1.82329 34.1274 1.63616L33.8907 1.0069C33.8504 0.899566 33.7781 0.807045 33.6834 0.741726C33.5888 0.676407 33.4763 0.641405 33.3611 0.641405C33.246 0.641405 33.1335 0.676407 33.0389 0.741726C32.9442 0.807045 32.8719 0.899566 32.8316 1.0069L32.5949 1.63616C32.5244 1.82334 32.4143 1.99331 32.2722 2.13459C32.1301 2.27587 31.9591 2.38518 31.7709 2.45516L31.1384 2.69141C31.0315 2.73192 30.9394 2.80382 30.8744 2.89758C30.8095 2.99134 30.7747 3.10253 30.7747 3.21641C30.7747 3.33028 30.8095 3.44147 30.8744 3.53523C30.9394 3.62899 31.0315 3.70164 31.1384 3.74216ZM33.36 2.58416C33.5326 2.83016 33.7475 3.04394 33.9948 3.21565C33.7475 3.38737 33.5326 3.60115 33.36 3.84715C33.1878 3.60083 32.9729 3.38699 32.7253 3.21565C32.9727 3.04412 33.1876 2.83032 33.36 2.58416ZM34.4425 31.7749C34.2926 31.7749 34.1488 31.8342 34.0428 31.9397C33.9367 32.0452 33.8772 32.1882 33.8772 32.3374V34.6729C33.8772 34.7256 33.8561 34.7762 33.8186 34.8134C33.7812 34.8507 33.7304 34.8717 33.6774 34.8717H30.7404C30.6874 34.8717 30.6366 34.8507 30.5991 34.8134C30.5617 34.7762 30.5406 34.7256 30.5406 34.6729V33.7099C30.5406 33.5607 30.4811 33.4176 30.375 33.3122C30.269 33.2067 30.1252 33.1474 29.9752 33.1474C29.8253 33.1474 29.6815 33.2067 29.5755 33.3122C29.4694 33.4176 29.4099 33.5607 29.4099 33.7099V34.6729C29.4103 35.0239 29.5506 35.3603 29.8 35.6085C30.0494 35.8567 30.3876 35.9963 30.7404 35.9967H33.6804C34.0332 35.9963 34.3714 35.8567 34.6208 35.6085C34.8702 35.3603 35.0105 35.0239 35.0109 34.6729V32.3374C35.0109 32.2633 34.9962 32.1899 34.9676 32.1215C34.939 32.053 34.8971 31.9909 34.8443 31.9386C34.7915 31.8863 34.7288 31.845 34.6598 31.8169C34.5909 31.7888 34.517 31.7745 34.4425 31.7749ZM5.98555 33.1467C5.8356 33.1467 5.69179 33.2059 5.58576 33.3114C5.47973 33.4169 5.42016 33.56 5.42016 33.7092V34.6722C5.42016 34.7247 5.39922 34.7752 5.36192 34.8124C5.32462 34.8497 5.274 34.8707 5.22115 34.8709H2.28114C2.22829 34.8707 2.17767 34.8497 2.14037 34.8124C2.10307 34.7752 2.08213 34.7247 2.08213 34.6722V32.3374C2.08213 32.1882 2.02256 32.0452 1.91653 31.9397C1.8105 31.8342 1.66669 31.7749 1.51674 31.7749C1.36679 31.7749 1.22298 31.8342 1.11695 31.9397C1.01092 32.0452 0.951355 32.1882 0.951355 32.3374V34.6729C0.951554 35.0235 1.09149 35.3598 1.34048 35.6079C1.58947 35.8561 1.92721 35.9959 2.27963 35.9967H5.21964C5.57233 35.9963 5.91045 35.8566 6.15977 35.6085C6.40909 35.3603 6.54923 35.0238 6.54943 34.6729V33.7099C6.54963 33.5609 6.49036 33.4178 6.38463 33.3122C6.2789 33.2066 6.13537 33.1471 5.98555 33.1467Z" fill="#13141A"></path><path d="M34.9084 14.1379L33.0238 13.8139C32.7485 13.7634 32.464 13.8077 32.2173 13.9395C31.9707 14.0713 31.7765 14.2828 31.6669 14.5392L31.5651 14.7642L30.2293 11.6292C29.9273 10.9103 29.4454 10.2804 28.8294 9.79936C28.2134 9.31833 27.4839 9.00223 26.7103 8.88116C23.8279 8.4458 20.9158 8.23366 18.0004 8.24666C15.0849 8.23391 12.1728 8.4463 9.29042 8.88191C8.51693 9.0029 7.78746 9.3189 7.17148 9.79979C6.55551 10.2807 6.07353 10.9105 5.77146 11.6292L4.43112 14.7672L4.33613 14.5467C4.22733 14.2892 4.03368 14.0763 3.78704 13.943C3.54041 13.8097 3.25549 13.7639 2.97921 13.8132L1.09459 14.1379C0.788745 14.1884 0.51084 14.3452 0.310381 14.5805C0.109923 14.8158 -6.92487e-05 15.1142 3.2709e-08 15.4227V15.7909C0.000282371 16.0878 0.102088 16.3758 0.288683 16.6075C0.475277 16.8392 0.735557 17.0009 1.02674 17.0659L2.81638 17.4679L2.02333 18.6717C1.33617 19.7118 0.970551 20.9295 0.97171 22.1742V28.5717C0.97171 30.9859 2.66184 32.5467 5.2792 32.5467H30.7216C33.3389 32.5467 35.029 30.9867 35.029 28.5717V22.1712C35.0302 20.9265 34.6646 19.7088 33.9774 18.6687L33.1844 17.4687L34.968 17.0682C35.26 17.0039 35.5213 16.8426 35.7089 16.6109C35.8965 16.3791 35.9992 16.0907 36 15.7932V15.4249C36.0009 15.1165 35.8916 14.8178 35.6917 14.582C35.4917 14.3463 35.2142 14.1889 34.9084 14.1379ZM1.27023 15.9649C1.23055 15.956 1.1951 15.9339 1.16974 15.9023C1.14439 15.8707 1.13064 15.8314 1.13077 15.7909V15.4227C1.13016 15.3802 1.14513 15.3389 1.17288 15.3066C1.20063 15.2743 1.23926 15.2532 1.28154 15.2472L3.17445 14.9217C3.201 14.9169 3.22839 14.9219 3.25154 14.9357C3.27468 14.9495 3.29202 14.9711 3.30035 14.9967L3.76245 16.0362L3.48051 16.4637L1.27023 15.9649ZM33.8983 26.8242H3.53555C3.3856 26.8242 3.24179 26.8834 3.13576 26.9889C3.02973 27.0944 2.97016 27.2375 2.97016 27.3867C2.97016 27.5358 3.02973 27.6789 3.13576 27.7844C3.24179 27.8899 3.3856 27.9492 3.53555 27.9492H33.8983V28.5717C33.8983 30.3552 32.711 31.4217 30.7216 31.4217H5.2792C3.28979 31.4217 2.10248 30.3559 2.10248 28.5717V22.1712C2.10169 21.1456 2.40281 20.1423 2.96865 19.2852L4.75075 16.5807H29.4174C29.5673 16.5807 29.7112 16.5214 29.8172 16.4159C29.9232 16.3104 29.9828 16.1673 29.9828 16.0182C29.9828 15.869 29.9232 15.7259 29.8172 15.6204C29.7112 15.5149 29.5673 15.4557 29.4174 15.4557H5.36815L6.81252 12.0717C7.03985 11.5287 7.40326 11.0528 7.86808 10.6894C8.33289 10.3259 8.88358 10.0871 9.46757 9.99566C12.2913 9.56774 15.1441 9.35911 18.0004 9.37166C20.8565 9.35836 23.7094 9.56624 26.5332 9.99341C27.1174 10.0851 27.6683 10.3242 28.1331 10.6881C28.5979 11.0519 28.9612 11.5283 29.1882 12.0717L30.8407 15.9469C30.8535 15.9779 30.8694 16.0076 30.8882 16.0354L33.0321 19.2882C33.5979 20.1453 33.8991 21.1486 33.8983 22.1742V26.8242ZM34.8692 15.7909C34.8692 15.8322 34.8549 15.8722 34.8286 15.9042C34.8024 15.9361 34.7659 15.9581 34.7252 15.9664L32.5225 16.4614L32.2406 16.0339L32.7057 14.9839C32.7161 14.9612 32.7339 14.9425 32.7561 14.9308C32.7783 14.9192 32.8038 14.9152 32.8286 14.9194L34.7177 15.2449C34.76 15.2509 34.7986 15.2721 34.8264 15.3044C34.8541 15.3367 34.8691 15.3779 34.8685 15.4204L34.8692 15.7909Z" fill="#13141A"></path></g></svg>                                                </div>
                                        <div class="content">
                                                                                                    <h6>Recieve The Car</h6>
                                                                                                                                                        <p>Car servicing is the regular maintenance and inspection of a vehicle to ensure.</p>
                                                                                            </div>
                                    </div>
                                </div>
                                                            </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 d-flex justify-content-center">
                    <div class="trustpilot-review">
                                                            <strong> Excellent!</strong>
                                                        <div class="star">
                            
                                                                    <ul class="trustpilot">
                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                            </ul>
                                                            </div>
                        <p>5 Rating out of 5.0 Based On<a href=""> 2348 Reviews</a> </p>
                                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/trstpilot-logo.svg" alt="Company Logo">
                                                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-f136fa4 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f136fa4" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-cdb25a8" data-id="cdb25a8" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-7936f43 elementor-widget elementor-widget-drivco_upcoming_vehicle" data-id="7936f43" data-element_type="widget" data-widget_type="drivco_upcoming_vehicle.default">
        <div class="elementor-widget-container">
            
<div class="modal signUp-modal fade" id="alartModal01" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                                    <h4 class="modal-title" id="alartModal01Label">Get Notify For Upcoming Car</h4>
                                                                <p>If you need to set up email want to receive notifications</p>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x"></i></button>
            </div>
            <div class="modal-body">
                
<div class="wpcf7 js" id="wpcf7-f327-p18-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/home-02/#wpcf7-f327-p18-o2" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="327">
<input type="hidden" name="_wpcf7_version" value="5.8.3">
<input type="hidden" name="_wpcf7_locale" value="en_US">
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f327-p18-o2">
<input type="hidden" name="_wpcf7_container_post" value="18">
<input type="hidden" name="_wpcf7_posted_data_hash" value="">
</div>
<div class="row g-4">
    <div class="col-md-6">
        <div class="form-inner">
            <label>Name*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-29"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Daniel" value="" type="text" name="text-29"></span>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-inner">
            <label>Vehicle Model*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-263"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Mercedes-Benz" value="" type="text" name="text-263"></span>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-inner">
            <label>Location*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-252"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Type location" value="" type="text" name="text-252"></span>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-inner">
            <label>Phone Number*</label>
            <span class="wpcf7-form-control-wrap" data-name="text-45"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="+91- 245 *** ****" value="" type="text" name="text-45"></span>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-inner">
            <label>E-mail*</label>
            <span class="wpcf7-form-control-wrap" data-name="email-983"><input size="40" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Enter your email address" value="" type="email" name="email-983"></span>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-inner">
            <button class="primary-btn2" type="submit">Submit Now</button>
        </div>
    </div>
</div><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
                                        <div class="terms-conditon two">
                    <p>Your notify instantly by email when new car will launch.</p>
                </div>
                                    </div>
        </div>
    </div>
</div>





    <div class="recent-launched-car">
        <div class="row mb-50">
            <div class="col-lg-12 d-flex align-items-end justify-content-between gap-3 flex-wrap">
                <div class="section-title-2">
                                            <h2>Upcoming Cars</h2>
                                                                            <p> Here are some of the featured cars in different categories</p>
                                            </div>
                <div class="slider-btn-group2">
                    <div class="slider-btn prev-5 swiper-button-disabled" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="true" fdprocessedid="vnqvva">
                        <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                            <path d="M0 6.50008L8 0L2.90909 6.50008L8 13L0 6.50008Z"></path>
                        </svg>
                    </div>
                    <div class="slider-btn next-5" tabindex="0" role="button" aria-label="Next slide" aria-disabled="false" fdprocessedid="14p6ad">
                        <svg width="9" height="15" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 6.50008L0 0L5.09091 6.50008L0 13L8 6.50008Z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="swiper recent-launch-car-slider swiper-container-initialized swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;">

                        
                            <div class="swiper-slide swiper-slide-active" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <div class="date">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#alartModal01">
                                                02 June, 2023 <i class="bi bi-exclamation-circle"></i>
                                            </button>
                                        </div>

                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/brand-7.jpg" alt="product-img">
                                    </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a data-bs-toggle="modal" data-bs-target="#alartModal01"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                                                                        <div class="price">
                                            <strong>$55,670</strong>
                                        </div>
                                                                                        <h6><a data-bs-toggle="modal" data-bs-target="#alartModal01">Lamborghini Aventador</a></h6>
                                    </div>
                                </div>
                            </div>

                        
                            <div class="swiper-slide swiper-slide-next" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <div class="date">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#alartModal01">
                                                02 June, 2023 <i class="bi bi-exclamation-circle"></i>
                                            </button>
                                        </div>

                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/brand-8.jpg" alt="product-img">
                                    </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a data-bs-toggle="modal" data-bs-target="#alartModal01"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                                                                        <div class="price">
                                            <strong>$45,670</strong>
                                        </div>
                                                                                        <h6><a data-bs-toggle="modal" data-bs-target="#alartModal01">Tesla Model S-2023</a></h6>
                                    </div>
                                </div>
                            </div>

                        
                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <div class="date">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#alartModal01">
                                                02 June, 2023 <i class="bi bi-exclamation-circle"></i>
                                            </button>
                                        </div>

                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/brand-9.jpg" alt="product-img">
                                    </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a data-bs-toggle="modal" data-bs-target="#alartModal01"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                                                                        <div class="price">
                                            <strong>$76,600</strong>
                                        </div>
                                                                                        <h6><a data-bs-toggle="modal" data-bs-target="#alartModal01">Nissan Altima S-2023</a></h6>
                                    </div>
                                </div>
                            </div>

                        
                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <div class="date">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#alartModal01">
                                                02 June, 2023 <i class="bi bi-exclamation-circle"></i>
                                            </button>
                                        </div>

                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/brand-11.jpg" alt="product-img">
                                    </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a data-bs-toggle="modal" data-bs-target="#alartModal01"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                                                                        <div class="price">
                                            <strong>$43,070</strong>
                                        </div>
                                                                                        <h6><a data-bs-toggle="modal" data-bs-target="#alartModal01">BMW 3 Series-2023</a></h6>
                                    </div>
                                </div>
                            </div>

                        
                            <div class="swiper-slide" style="width: 313.75px; margin-right: 15px;">
                                <div class="product-card2">
                                    <div class="product-img">
                                        <div class="date">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#alartModal01">
                                                02 June, 2023 <i class="bi bi-exclamation-circle"></i>
                                            </button>
                                        </div>

                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/brand-12.jpg" alt="product-img">
                                    </div>
                                    <div class="product-content">
                                        <div class="details-btn">
                                            <a data-bs-toggle="modal" data-bs-target="#alartModal01"><i class="bi bi-arrow-right-short"></i></a>
                                        </div>
                                                                                        <div class="price">
                                            <strong>$28.579</strong>
                                        </div>
                                                                                        <h6><a data-bs-toggle="modal" data-bs-target="#alartModal01">Kia Telluride-2023</a></h6>
                                    </div>
                                </div>
                            </div>

                                                    </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            </div>
        </div>
    </div>












</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-42e6a50 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="42e6a50" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5cef3e0" data-id="5cef3e0" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-ddd2f9f elementor-widget elementor-widget-drivco_marquee_slider" data-id="ddd2f9f" data-element_type="widget" data-widget_type="drivco_marquee_slider.default">
        <div class="elementor-widget-container">
            
            <div class="customar-feedback-area">
        <div class="row">
            <div class="col-lg-12">
                <div class="sub-title">
                                                    <h6>Our Trusted Partners</h6>
                                                <div class="dash"></div>
                </div>
                <div class="partner-slider">
                    <h2 class="marquee_text2"><div style="width: 100000px; transform: translateX(0px); animation: 24.1346s linear 0s infinite normal none running marqueeAnimation-4880718;" class="js-marquee-wrapper"><div class="js-marquee" style="margin-right: 50px; float: left;">
                                                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-01.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-02.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-03.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-04.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-05.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-06.png" alt="Logo image">
                                                                                        </div><div class="js-marquee" style="margin-right: 50px; float: left;">
                                                                                                    <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-01.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-02.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-03.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-04.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-05.png" alt="Logo image">
                                                                                                                                        <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/company-logo-06.png" alt="Logo image">
                                                                                        </div></div></h2>
                </div>
            </div>
        </div>
    </div>




</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-fa03f38 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fa03f38" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-bd047ea" data-id="bd047ea" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-dce5140 elementor-widget elementor-widget-drivco_heading" data-id="dce5140" data-element_type="widget" data-widget_type="drivco_heading.default">
        <div class="elementor-widget-container">
    


            <div class="section-title-2 ">
                    <h2> Comparing Car With Brand </h2>
                                        <p>Vehicle to ensure that it is operating safely and efficiently.</p>
                    </div>


</div>
        </div>
        <div class="elementor-element elementor-element-43fa5e7 elementor-widget elementor-widget-drivco_compare" data-id="43fa5e7" data-element_type="widget" data-widget_type="drivco_compare.default">
        <div class="elementor-widget-container">
    


            <div class="compare-car-section">
        <div class="modal compare-modal fade" id="compareModal01" tabindex="-1" aria-labelledby="compareModal01Label" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content" id="vehicle_compare_data">

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12" id="loadID">
                <div class="swiper compare-car-slider swiper-container-initialized swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transform: translate3d(-441.333px, 0px, 0px); transition-duration: 0ms;">

                                                            <div class="swiper-slide swiper-slide-prev" style="width: 417.333px; margin-right: 24px;">
                                <div class="single-compare-card">
                                    <div class="compare-top">
                                                                                            <div class="single-car">
                                                                                                            <div class="car-img">
                                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-1.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-1-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-1-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-1-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                            </div>
                                                                                                        <div class="content text-center">
                                                    <span>(Hyundai)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/mercedes-benz-c-class-2023/">Toyota Camry-2023</a></h6>
                                                    <h6 class="price">
                                                                                    $3,560			                                                            </h6>
                                                </div>
                                            </div>
                                        
                                        <div class="vs">
                                            <span>VS</span>
                                        </div>

                                                                                            <div class="single-car">
                                                                                                    <div class="car-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-2-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                    <div class="content text-center">
                                                    <span>(Mercedes)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/toyota-highlander/">Toyota Highlander</a></h6>
                                                    <h6 class="price">
                                                                                    $4,160				<del>$4,250</del>
                                                                </h6>
                                                </div>
                                            </div>

                                        
                                    </div>
                                    <div class="compare-btm">
                                        <button type="button" value="119_236" class="primary-btn2 compare_vehicle" data-bs-toggle="modal" data-bs-target="#compareModal01" fdprocessedid="xm6gcw">Compare Vehicles</button>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide swiper-slide-active" style="width: 417.333px; margin-right: 24px;">
                                <div class="single-compare-card">
                                    <div class="compare-top">
                                                                                            <div class="single-car">
                                                                                                            <div class="car-img">
                                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-768x414.jpg 768w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/10/vehicle-19-600x323.jpg 600w" sizes="(max-width: 900px) 100vw, 900px">                                                            </div>
                                                                                                        <div class="content text-center">
                                                    <span>(Mezda)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/tucsonplug-in-hybrid/">TUCSONPlug-in Hybrid</a></h6>
                                                    <h6 class="price">
                                                                                    $98,764			                                                            </h6>
                                                </div>
                                            </div>
                                        
                                        <div class="vs">
                                            <span>VS</span>
                                        </div>

                                                                                            <div class="single-car">
                                                                                                    <div class="car-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-21-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                    <div class="content text-center">
                                                    <span>(Ferrari)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/the-new-sonata/">The new SONATA</a></h6>
                                                    <h6 class="price">
                                                                                    $94,785				<del>$96,765</del>
                                                                </h6>
                                                </div>
                                            </div>

                                        
                                    </div>
                                    <div class="compare-btm">
                                        <button type="button" value="1149_1148" class="primary-btn2 compare_vehicle" data-bs-toggle="modal" data-bs-target="#compareModal01" fdprocessedid="dcsu9v">Compare Vehicles</button>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide swiper-slide-next" style="width: 417.333px; margin-right: 24px;">
                                <div class="single-compare-card">
                                    <div class="compare-top">
                                                                                            <div class="single-car">
                                                                                                            <div class="car-img">
                                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-18-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                            </div>
                                                                                                        <div class="content text-center">
                                                    <span>(Mezda)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/ferrari-f8-tributo/">Ferrari F8 Tributo</a></h6>
                                                    <h6 class="price">
                                                                                    $45,500				<del>$46,545</del>
                                                                </h6>
                                                </div>
                                            </div>
                                        
                                        <div class="vs">
                                            <span>VS</span>
                                        </div>

                                                                                            <div class="single-car">
                                                                                                    <div class="car-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-15-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                    <div class="content text-center">
                                                    <span>(BMW)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/bmw-3-series-sedan/">BMW 3 Series Sedan</a></h6>
                                                    <h6 class="price">
                                                                                    $654,165			                                                            </h6>
                                                </div>
                                            </div>

                                        
                                    </div>
                                    <div class="compare-btm">
                                        <button type="button" value="1140_1139" class="primary-btn2 compare_vehicle" data-bs-toggle="modal" data-bs-target="#compareModal01" fdprocessedid="29v74c">Compare Vehicles</button>
                                    </div>
                                </div>
                            </div>
                                                            <div class="swiper-slide" style="width: 417.333px; margin-right: 24px;">
                                <div class="single-compare-card">
                                    <div class="compare-top">
                                                                                            <div class="single-car">
                                                                                                            <div class="car-img">
                                                        <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-10-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                            </div>
                                                                                                        <div class="content text-center">
                                                    <span>(BMW)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/subaru-outback-2023/">Subaru Outback-2023</a></h6>
                                                    <h6 class="price">
                                                                                    $79,876			                                                            </h6>
                                                </div>
                                            </div>
                                        
                                        <div class="vs">
                                            <span>VS</span>
                                        </div>

                                                                                            <div class="single-car">
                                                                                                    <div class="car-img">
                                                    <img loading="lazy" decoding="async" width="900" height="485" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11.jpg 900w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-600x323.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-300x162.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/vehicle-11-768x414.jpg 768w" sizes="(max-width: 900px) 100vw, 900px">                                                        </div>
                                                                                                    <div class="content text-center">
                                                    <span>(Tesla)</span>
                                                    <h6 class="title"><a href="https://www.drivco-wp.egenslab.com/vehicle/kia-telluride-2023/">Kia Telluride-2023</a></h6>
                                                    <h6 class="price">
                                                                                    $36,464			                                                            </h6>
                                                </div>
                                            </div>

                                        
                                    </div>
                                    <div class="compare-btm">
                                        <button type="button" value="1123_1133" class="primary-btn2 compare_vehicle" data-bs-toggle="modal" data-bs-target="#compareModal01" fdprocessedid="4fl6ma">Compare Vehicles</button>
                                    </div>
                                </div>
                            </div>
                                                    </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            </div>
        </div>
                            <div class="row ">
                <div class="col-lg-12 divider">
                    <div class="slider-btn-group style-2 justify-content-md-between justify-content-center">
                        <div class="slider-btn prev-3 d-md-flex d-none" tabindex="0" role="button" aria-label="Previous slide" aria-disabled="false" fdprocessedid="1gl4z1">
                            <svg width="11" height="19" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                <path d="M0 6.50008L8 0L2.90909 6.50008L8 13L0 6.50008Z"></path>
                            </svg>
                        </div>
                        <div class="view-btn-area">
                            <p>There are Trending Car Available</p>
                            <a class="view-btn" href="/vehicle">View More</a>
                        </div>
                        <div class="slider-btn next-3 d-md-flex d-none swiper-button-disabled" tabindex="0" role="button" aria-label="Next slide" aria-disabled="true" fdprocessedid="g96p9c">
                            <svg width="11" height="19" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8 6.50008L0 0L5.09091 6.50008L0 13L8 6.50008Z"></path>
                            </svg>
                        </div>
                    </div>

                </div>
            </div>
                    </div>


</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-e8e7d98 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e8e7d98" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b8d53e1" data-id="b8d53e1" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-879d239 elementor-widget elementor-widget-drivco_testimonial" data-id="879d239" data-element_type="widget" data-widget_type="drivco_testimonial.default">
        <div class="elementor-widget-container">
            



            <div class="home2-testimonial-section ">
        <div class="container">
            <div class="row mb-50">
                <div class="col-lg-12 d-flex align-items-end justify-content-between gap-3 flex-wrap">
                    <div class="section-title-2">
                                                            <h2>Our Customer Reviews</h2>
                                                                                            <p>Here are some of the featured cars in different categories </p>
                                                    </div>
                    <div class="review-and-btn d-flex flex-wrap align-items-center gap-sm-5 gap-3">
                        <div class="rating">
                            <a>
                                <div class="review-top">
                                    <div class="logo">
                                                                                            <img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/trstpilot-logo.svg" alt="Company Logo">
                                                                                    </div>
                                    <div class="star">
                                        
                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                </ul>
                                                                                    </div>
                                </div>
                                <div class="content">
                                    <ul>
                                                                                            <li>Trust Rating <span> 5.0</span></li>
                                                                                                                                            <li> Based On 2348 Reviews</li>
                                                                                    </ul>
                                </div>
                            </a>
                        </div>
                                                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="swiper customer-feedback-slider2 swiper-container-initialized swiper-container-horizontal">
                        <div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(-1733.33px, 0px, 0px);"><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="0" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Jhon Abraham</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="1" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Rakab Uddin</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="2" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Michel Clark</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="0" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Jhon Abraham</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="1" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Rakab Uddin</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div>
                                                                    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="2" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Michel Clark</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div>
                                                            <div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="0" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Jhon Abraham</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="1" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Rakab Uddin</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="2" style="width: 409.333px; margin-right: 24px;">
                                    <div class="feedback-card">
                                        <div class="feedback-top">
                                            <div class="stat-area">
                                                
                                                                                                            <ul class="trustpilot">
                                                                                                                                                                                                                                                                    <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                                                                                                        <li><i class="bi bi-star-fill"></i></li>
                                                                                                                                                                                        </ul>
                                                                                                    </div>
                                            <div class="services">
                                                                                                            <span>Trusted Company</span>
                                                                                                    </div>
                                        </div>
                                                                                            <p>Drivco-Agencycustomer feedback is an invaluable source ofinformation that can help businesses improve their offerings and provide better experiences.</p>
                                                                                        <div class="author-name">
                                                                                                    <h6>Michel Clark</h6>
                                                                                                                                                        <span>25 Minutes Ago</span>
                                                                                            </div>
                                    </div>
                                </div></div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
                </div>
            </div>
                            </div>
    </div>






</div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
        <section class="elementor-section elementor-top-section elementor-element elementor-element-e7c8fd0 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e7c8fd0" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8546a29" data-id="8546a29" data-element_type="column">
    <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                <div class="elementor-element elementor-element-8957041 elementor-widget elementor-widget-drivco_blog" data-id="8957041" data-element_type="widget" data-widget_type="drivco_blog.default">
        <div class="elementor-widget-container">
            

            <div class="news-section">
        <div class="row mb-60">
            <div class="col-lg-12 d-flex align-items-end justify-content-between flex-wrap gap-4">
                <div class="section-title-2">
                                                    <h2> The Latest News Car &amp; Bids</h2>
                                                                                <p>Here are some of the featured cars in different categories</p>
                                            </div>
            </div>
        </div>
        <div class="row g-4 justify-content-center">
                                    <div class="col-lg-4 col-md-6">
                    <div class="news-card">
                                                            <div class="news-img">
                                <img loading="lazy" decoding="async" width="1200" height="650" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12.jpg 1200w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12-600x325.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12-300x163.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12-1024x555.jpg 1024w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-12-768x416.jpg 768w" sizes="(max-width: 1200px) 100vw, 1200px">                                        <div class="date">
                                                                                <a href="https://www.drivco-wp.egenslab.com/category/electric-car/"> Electric Car</a>
                                </div>
                            </div>
                                                        <div class="content">

                            <h6><a href="https://www.drivco-wp.egenslab.com/the-future-of-electric-cars-what-to-expect-in-the-next-decade/">The Future of Electric Cars What to Expect in the Next Decade</a>
                            </h6>

                            <div class="news-btm">
                                <div class="author-area">
                                    <div class="author-img">
                                        <img alt="" src="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=32&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo" height="32" width="32">                                            </div>
                                    <div class="author-content">
                                        <h6>Shafiqul</h6>
                                        <a href="https://www.drivco-wp.egenslab.com/2023/09/24">Posted On- September 24, 2023</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                                    <div class="col-lg-4 col-md-6">
                    <div class="news-card">
                                                            <div class="news-img">
                                <img loading="lazy" decoding="async" width="1200" height="650" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11.jpg 1200w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11-600x325.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11-300x163.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11-1024x555.jpg 1024w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-11-768x416.jpg 768w" sizes="(max-width: 1200px) 100vw, 1200px">                                        <div class="date">
                                                                                <a href="https://www.drivco-wp.egenslab.com/category/buying-advice/"> Buying Advice</a>
                                </div>
                            </div>
                                                        <div class="content">

                            <h6><a href="https://www.drivco-wp.egenslab.com/how-to-maintain-your-vehicles-resale-value-expert-insights/">How to Maintain Your Vehicle’s Resale Value: Expert Insights</a>
                            </h6>

                            <div class="news-btm">
                                <div class="author-area">
                                    <div class="author-img">
                                        <img alt="" src="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=32&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo" height="32" width="32">                                            </div>
                                    <div class="author-content">
                                        <h6>Shafiqul</h6>
                                        <a href="https://www.drivco-wp.egenslab.com/2023/09/24">Posted On- September 24, 2023</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                                    <div class="col-lg-4 col-md-6">
                    <div class="news-card">
                                                            <div class="news-img">
                                <img loading="lazy" decoding="async" width="1200" height="650" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10.jpg 1200w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10-600x325.jpg 600w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10-300x163.jpg 300w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10-1024x555.jpg 1024w, https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/blog-10-768x416.jpg 768w" sizes="(max-width: 1200px) 100vw, 1200px">                                        <div class="date">
                                                                                <a href="https://www.drivco-wp.egenslab.com/category/lifestyle/"> Lifestyle</a>
                                </div>
                            </div>
                                                        <div class="content">

                            <h6><a href="https://www.drivco-wp.egenslab.com/suv-vs-sedan-choosing-the-right-vehicle-for-your-lifestyle/">SUV vs. Sedan Choosing the Right Vehicle for Your Lifestyle</a>
                            </h6>

                            <div class="news-btm">
                                <div class="author-area">
                                    <div class="author-img">
                                        <img alt="" src="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=32&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/2ac0b89ced4ce2e492cab4aaf8529ac5?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo" height="32" width="32">                                            </div>
                                    <div class="author-content">
                                        <h6>Shafiqul</h6>
                                        <a href="https://www.drivco-wp.egenslab.com/2023/09/24">Posted On- September 24, 2023</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                            </div>
    </div>




        </div>
        </div>
                </div>
            </div>
</div>
                        </div>
            </div>
</section>
                            </div>
    </div>
            </div>
</div><!-- close #app div from header.php -->



<!-- Start Footer Section -->
<footer>
<div class="container-fluid">

    
        <!-- Footer Widgets Area -->
        
            <div class="footer-top">
        <div class="row row-cols-xl-5 row-cols-lg-4 row-cols-md-3 row-cols-sm-3 row-cols-1 justify-content-center g-lg-4 gy-5 ">
            <div class="col d-flex justify-content-lg-start">
                                            <div id="nav_menu-2" class="footer-widget widget_nav_menu"><div class="menu-container"><div class="widget-title"><h5>About Company</h5></div><div class="menu-about-company-container"><ul id="menu-about-company" class="menu"><li id="menu-item-62" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62"><a href="https://www.drivco-wp.egenslab.com/about-us/">About Us</a></li>
<li id="menu-item-63" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-63"><a href="#" class="active">Return &amp; Exchange</a></li>
<li id="menu-item-1262" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1262"><a href="https://www.drivco-wp.egenslab.com/refund_returns/">Refund Policy</a></li>
<li id="menu-item-1260" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1260"><a href="https://www.drivco-wp.egenslab.com/customer-feedback/">Reviews</a></li>
<li id="menu-item-1261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1261"><a href="https://www.drivco-wp.egenslab.com/faqs/">FAQ’s</a></li>
<li id="menu-item-1259" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1259"><a href="https://www.drivco-wp.egenslab.com/contact-us/">Contact Us</a></li>
</ul></div></div></div>                                            </div>
            <div class="col d-flex justify-content-sm-center">
                                            <div id="nav_menu-3" class="footer-widget widget_nav_menu"><div class="menu-container"><div class="widget-title"><h5>Search &amp; Explore</h5></div><div class="menu-search-explore-container"><ul id="menu-search-explore" class="menu"><li id="menu-item-1758" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-category menu-item-1758"><a href="https://www.drivco-wp.egenslab.com/vehicle-category/used-car/">Used Cars</a></li>
<li id="menu-item-1757" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-category menu-item-1757"><a href="https://www.drivco-wp.egenslab.com/vehicle-category/new-car/">New Cars</a></li>
<li id="menu-item-1759" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-category menu-item-1759"><a href="https://www.drivco-wp.egenslab.com/vehicle-category/auction-car/">Auction Cars</a></li>
<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-71"><a href="#" class="active">Sell My Car</a></li>
<li id="menu-item-72" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-72"><a href="https://www.drivco-wp.egenslab.com/shop/">Shop Now</a></li>
</ul></div></div></div>                                            </div>
            <div class="col d-flex justify-content-lg-center justify-content-sm-end">
                                            <div id="nav_menu-4" class="footer-widget widget_nav_menu"><div class="menu-container"><div class="widget-title"><h5>Cars By Brands</h5></div><div class="menu-car-by-brands-container"><ul id="menu-car-by-brands" class="menu"><li id="menu-item-281" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-281"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/bmw/">BMW</a></li>
<li id="menu-item-282" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-282"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/ferrari/">Ferrari</a></li>
<li id="menu-item-285" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-285"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/mercedes/">Mercedes</a></li>
<li id="menu-item-288" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-288"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/suzuki/">Suzuki</a></li>
<li id="menu-item-289" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-289"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/tata/">TATA</a></li>
<li id="menu-item-291" class="menu-item menu-item-type-taxonomy menu-item-object-vehicle-brand menu-item-291"><a href="https://www.drivco-wp.egenslab.com/vehicle-brand/toyota/">Toyota</a></li>
</ul></div></div></div>                                            </div>
            <div class="col d-flex justify-content-xl-center justify-content-lg-end justify-content-sm-center">
                                            <div id="nav_menu-5" class="footer-widget widget_nav_menu"><div class="menu-container"><div class="widget-title"><h5>Cars By Location</h5></div><div class="menu-car-by-location-container"><ul id="menu-car-by-location" class="menu"><li id="menu-item-294" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-294"><a href="https://www.drivco-wp.egenslab.com/location/new-delhi/">New Delhi</a></li>
<li id="menu-item-1791" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-1791"><a href="https://www.drivco-wp.egenslab.com/location/kualalumpur/">Kualalumpur</a></li>
<li id="menu-item-295" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-295"><a href="https://www.drivco-wp.egenslab.com/location/panama-city/">Panama City</a></li>
<li id="menu-item-296" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-296"><a href="https://www.drivco-wp.egenslab.com/location/sydney-city/">Sydney City</a></li>
<li id="menu-item-293" class="menu-item menu-item-type-taxonomy menu-item-object-location menu-item-293"><a href="https://www.drivco-wp.egenslab.com/location/melbourne-city/">Melbourne City</a></li>
</ul></div></div></div>                                            </div>
            <div class="col d-flex justify-content-xl-end justify-content-sm-center">
                                            <div id="block-14" class="footer-widget widget_block"><div class="app-download"><div class="widget-title"><h5>Download App</h5></div><div class="wp-widget-group__inner-blocks">
<div class="app-download">
                        <ul>
                            <li>
                                <a href="#" class="active"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/google-app.svg" alt=""></a>
                            </li>
                            <li>
                                <a href="#" class="active"><img decoding="async" src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/apple-app.svg" alt=""></a>
                            </li>
                        </ul>
                    </div>
</div></div></div>                                            </div>
        </div>
    </div>



        <!-- Footer Widgets Area -->
                            <div id="custom_footer_widget-2" class="footer-center widget_custom_footer_widget">
<div class="footer-logo">
    <img src="https://www.drivco-wp.egenslab.com/wp-content/uploads/2023/09/footer-logo.svg" alt="footer-logo">
</div>

<div class="contact-area">
                    <div class="hotline-area">
            <div class="icon">
                <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                    <path d="M31.1603 24.6852L24.6834 20.3658C23.8615 19.8221 22.7597 20.001 22.152 20.7769L20.2654 23.2027C20.1481 23.3573 19.9789 23.4645 19.789 23.5045C19.599 23.5444 19.4011 23.5145 19.2314 23.4203L18.8725 23.2224C17.6828 22.574 16.2025 21.7667 13.22 18.7831C10.2375 15.7995 9.42859 14.3181 8.78012 13.1306L8.58334 12.7717C8.48781 12.6021 8.45678 12.4037 8.49597 12.213C8.53516 12.0223 8.64193 11.8522 8.79662 11.734L11.2208 9.84792C11.9964 9.2402 12.1756 8.13874 11.6324 7.31655L7.31309 0.83963C6.75648 0.00237835 5.63977 -0.24896 4.77809 0.269026L2.06967 1.89597C1.21867 2.39626 0.594346 3.20652 0.327557 4.15695C-0.647737 7.71055 0.0859667 13.8435 9.12038 22.879C16.3071 30.0651 21.6572 31.9976 25.3345 31.9976C26.1809 32.0013 27.0239 31.8912 27.8409 31.6703C28.7915 31.4038 29.6018 30.7794 30.1018 29.9281L31.7304 27.2214C32.2491 26.3595 31.9979 25.2421 31.1603 24.6852ZM30.8115 26.6742L29.1867 29.3826C28.8277 29.997 28.2449 30.4488 27.5603 30.6432C24.2797 31.5439 18.5483 30.7979 9.87489 22.1245C1.20149 13.4511 0.455538 7.72017 1.35622 4.4391C1.55097 3.75367 2.00324 3.17011 2.61841 2.81053L5.32682 1.1857C5.7007 0.960737 6.18538 1.06978 6.4269 1.4331L8.77324 4.95577L10.7426 7.90946C10.9784 8.26609 10.9009 8.74409 10.5645 9.00798L8.13978 10.8941C7.40188 11.4583 7.19117 12.4792 7.64547 13.2895L7.83801 13.6393C8.51953 14.8892 9.36684 16.4442 12.4603 19.5371C15.5537 22.63 17.1081 23.4773 18.3575 24.1588L18.7078 24.3518C19.518 24.8061 20.539 24.5954 21.1032 23.8575L22.9893 21.4328C23.2533 21.0966 23.7311 21.0191 24.0879 21.2547L30.5642 25.5741C30.9278 25.8154 31.0368 26.3004 30.8115 26.6742ZM18.1324 5.33496C23.1367 5.34053 27.1921 9.39599 27.1977 14.4003C27.1977 14.6948 27.4364 14.9335 27.7309 14.9335C28.0255 14.9335 28.2642 14.6948 28.2642 14.4003C28.258 8.8072 23.7255 4.27462 18.1324 4.2685C17.8378 4.2685 17.5991 4.50721 17.5991 4.80173C17.5991 5.09625 17.8378 5.33496 18.1324 5.33496Z"></path>
                    <path d="M18.1324 8.53424C21.3704 8.53805 23.9944 11.162 23.9982 14.4001C23.9982 14.5415 24.0544 14.6771 24.1544 14.7771C24.2544 14.8771 24.39 14.9333 24.5314 14.9333C24.6728 14.9333 24.8085 14.8771 24.9085 14.7771C25.0085 14.6771 25.0646 14.5415 25.0646 14.4001C25.0602 10.5733 21.9591 7.47215 18.1324 7.46777C17.8378 7.46777 17.5991 7.70649 17.5991 8.00101C17.5991 8.29553 17.8378 8.53424 18.1324 8.53424Z"></path>
                    <path d="M18.1324 11.7344C19.6041 11.7362 20.7968 12.9289 20.7986 14.4007C20.7986 14.5422 20.8548 14.6778 20.9548 14.7778C21.0548 14.8778 21.1905 14.934 21.3319 14.934C21.4733 14.934 21.6089 14.8778 21.7089 14.7778C21.8089 14.6778 21.8651 14.5422 21.8651 14.4007C21.8627 12.3402 20.1929 10.6703 18.1324 10.668C17.8378 10.668 17.5991 10.9067 17.5991 11.2012C17.5991 11.4957 17.8378 11.7344 18.1324 11.7344Z"></path>
                </svg>
            </div>
            <div class="content">
                <span>To More Inquiry</span>
                <h6><a href="tel:+990-737 621 432">+990-737 621 432</a></h6>
            </div>
        </div>
    
                    <div class="hotline-area">
            <div class="icon">
                <svg width="32" height="33" viewBox="0 0 32 33" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16.6608 18.13C15.4654 18.1243 14.2777 17.9369 13.1387 17.5742C12.2446 17.2751 11.446 16.7441 10.8242 16.0355C10.2024 15.3269 9.77978 14.466 9.59946 13.5406C9.19786 11.6068 9.93012 9.56195 11.6069 7.92995C11.7871 7.75461 11.9742 7.58665 12.168 7.42649C13.0138 6.71831 14.0193 6.22662 15.0976 5.99386C16.1759 5.7611 17.2947 5.79426 18.3573 6.09049C19.3764 6.4159 20.2699 7.04873 20.915 7.90213C21.5601 8.75553 21.9253 9.78766 21.9605 10.8569C22.0387 12.1181 21.6276 13.3609 20.8128 14.3268C20.5045 14.715 20.0953 15.0108 19.6299 15.1816C19.1646 15.3525 18.6612 15.3918 18.1749 15.2953C17.9743 15.2536 17.7841 15.172 17.6158 15.0551C17.4474 14.9383 17.3044 14.7887 17.1952 14.6153C17.0972 14.4468 17.0342 14.2603 17.01 14.067C16.9858 13.8736 17.0009 13.6774 17.0544 13.49C17.5211 11.7268 17.9952 9.04729 18 9.02062C18.0122 8.95163 18.0378 8.88572 18.0755 8.82665C18.1132 8.76757 18.1621 8.7165 18.2195 8.67633C18.2769 8.63617 18.3416 8.6077 18.41 8.59256C18.4784 8.57742 18.5491 8.5759 18.6181 8.58809C18.6871 8.60027 18.753 8.62593 18.8121 8.66359C18.8712 8.70125 18.9222 8.75017 18.9624 8.80757C19.0026 8.86497 19.031 8.92972 19.0462 8.99812C19.0613 9.06652 19.0628 9.13723 19.0507 9.20622C19.0309 9.31769 18.5637 11.9566 18.0859 13.7625C18.069 13.812 18.0625 13.8645 18.0666 13.9167C18.0707 13.9689 18.0854 14.0197 18.1099 14.066C18.1836 14.1679 18.2949 14.2364 18.4192 14.2564C18.7169 14.3061 19.0226 14.2735 19.3032 14.1621C19.5838 14.0507 19.8286 13.8648 20.0112 13.6244C20.644 12.8674 20.961 11.8958 20.8965 10.9113C20.8711 10.0601 20.5829 9.23771 20.0714 8.55687C19.56 7.87603 18.8504 7.37014 18.04 7.10862C17.1472 6.86304 16.2081 6.83838 15.3036 7.03675C14.3992 7.23513 13.5566 7.65059 12.8485 8.24729C12.6773 8.38969 12.5104 8.53849 12.3504 8.69422C11.5216 9.50062 10.1973 11.1742 10.6437 13.3236C10.7911 14.0615 11.1287 14.7481 11.6231 15.3153C12.1175 15.8826 12.7515 16.3109 13.4624 16.5577C15.9637 17.3556 19.5584 17.4521 21.4517 15.0974C21.5414 14.9907 21.6693 14.9234 21.808 14.9098C21.9467 14.8962 22.0852 14.9375 22.1939 15.0248C22.3026 15.1121 22.3728 15.2384 22.3895 15.3768C22.4061 15.5151 22.368 15.6546 22.2832 15.7652C20.8827 17.507 18.7515 18.13 16.6608 18.13Z"></path>
                    <path d="M14.8353 15.3649C14.2714 15.3747 13.7214 15.1899 13.2779 14.8417C12.2545 14.0225 12.2262 12.599 12.5131 11.6299C12.6102 11.3073 12.7398 10.9953 12.9009 10.6993C13.301 9.89185 13.9409 9.22779 14.7329 8.79794C15.2132 8.54876 15.761 8.46069 16.2953 8.54674C16.8295 8.63279 17.322 8.8884 17.6998 9.27581C18.0847 9.69756 18.3746 10.197 18.5499 10.7403C18.594 10.8728 18.5844 11.0172 18.5232 11.1427C18.4621 11.2681 18.3541 11.3646 18.2226 11.4113C18.0911 11.4581 17.9465 11.4514 17.8198 11.3928C17.6932 11.3342 17.5946 11.2282 17.5451 11.0977C17.4187 10.6964 17.2085 10.3265 16.9286 10.0123C16.7085 9.78721 16.4209 9.6402 16.1095 9.59369C15.7981 9.54719 15.4801 9.60374 15.2038 9.75474C14.6098 10.0897 14.1325 10.5983 13.8358 11.2123C13.7112 11.4425 13.6106 11.6848 13.5355 11.9355C13.3281 12.6363 13.3739 13.5515 13.9457 14.0091C14.5707 14.5115 15.6257 14.2993 16.2193 13.7873C16.6614 13.389 17.0413 12.9266 17.3462 12.4155C17.3831 12.356 17.4314 12.3043 17.4884 12.2635C17.5453 12.2226 17.6097 12.1934 17.6779 12.1774C17.7461 12.1614 17.8168 12.159 17.886 12.1704C17.9551 12.1817 18.0213 12.2066 18.0809 12.2435C18.1404 12.2805 18.1921 12.3288 18.2329 12.3857C18.2738 12.4426 18.303 12.507 18.319 12.5753C18.335 12.6435 18.3374 12.7142 18.326 12.7833C18.3147 12.8524 18.2898 12.9187 18.2529 12.9782C17.8914 13.5802 17.4413 14.1245 16.9179 14.5926C16.3348 15.0847 15.5982 15.3578 14.8353 15.3649Z"></path>
                    <path d="M30.4005 32.0023H1.60049C1.17627 32.0019 0.769552 31.8332 0.469585 31.5332C0.169619 31.2332 0.000911967 30.8265 0.000488386 30.4023V10.669C0.000424993 10.5676 0.0292616 10.4683 0.0836186 10.3827C0.137976 10.2971 0.215601 10.2288 0.307397 10.1858C0.399192 10.1427 0.501355 10.1267 0.601912 10.1397C0.702468 10.1526 0.797252 10.1939 0.875155 10.2588L13.961 21.1346C14.535 21.6089 15.2564 21.8683 16.001 21.8683C16.7456 21.8683 17.467 21.6089 18.041 21.1346L31.1258 10.2583C31.2038 10.1934 31.2986 10.152 31.3992 10.1391C31.4998 10.1262 31.602 10.1422 31.6938 10.1853C31.7856 10.2284 31.8633 10.2968 31.9176 10.3825C31.9719 10.4682 32.0007 10.5675 32.0005 10.669V30.4023C32.0001 30.8265 31.8314 31.2332 31.5314 31.5332C31.2314 31.8332 30.8247 32.0019 30.4005 32.0023ZM1.06716 11.8055V30.4023C1.06716 30.6967 1.30609 30.9356 1.60049 30.9356H30.4005C30.5419 30.9356 30.6776 30.8794 30.7776 30.7794C30.8776 30.6794 30.9338 30.5438 30.9338 30.4023V11.8055L18.7216 21.9548C17.956 22.5875 16.994 22.9337 16.0009 22.9339C15.0079 22.934 14.0457 22.5882 13.28 21.9559L1.06716 11.8055Z"></path>
                    <path d="M0.534374 11.2024C0.42111 11.2026 0.310717 11.1668 0.219187 11.1C0.127657 11.0333 0.0597426 10.9392 0.0252829 10.8313C-0.00917678 10.7234 -0.00839247 10.6074 0.0275222 10.4999C0.063437 10.3925 0.132617 10.2993 0.22504 10.2339L5.02504 6.83119C5.14046 6.74936 5.28366 6.71673 5.42314 6.74049C5.56262 6.76424 5.68695 6.84243 5.76877 6.95785C5.8506 7.07327 5.88323 7.21648 5.85947 7.35595C5.83572 7.49543 5.75753 7.61976 5.64211 7.70159L0.842107 11.1043C0.752234 11.1682 0.644662 11.2025 0.534374 11.2024ZM31.4666 11.2024C31.3564 11.2025 31.2488 11.1682 31.1589 11.1043L26.3589 7.70159C26.2447 7.61935 26.1676 7.49531 26.1445 7.35649C26.1213 7.21768 26.154 7.07534 26.2353 6.9605C26.3167 6.84566 26.4401 6.76762 26.5788 6.7434C26.7174 6.71918 26.86 6.75073 26.9754 6.83119L31.7754 10.2339C31.8678 10.2993 31.9369 10.3924 31.9729 10.4997C32.0088 10.607 32.0097 10.723 31.9754 10.8308C31.941 10.9386 31.8733 11.0328 31.7819 11.0996C31.6906 11.1664 31.5798 11.2024 31.4666 11.2024ZM20.9285 3.73572C20.8181 3.73582 20.7103 3.70152 20.6202 3.63759L18.0709 1.82959C17.4975 1.34491 16.7721 1.07691 16.0213 1.07233C15.2705 1.06775 14.5419 1.32688 13.9626 1.80452L11.3813 3.63759C11.2659 3.71941 11.1227 3.75204 10.9832 3.72828C10.8437 3.70453 10.7194 3.62634 10.6376 3.51092C10.5557 3.3955 10.5231 3.2523 10.5469 3.11282C10.5706 2.97334 10.6488 2.84901 10.7642 2.76719L13.3136 0.959185C14.0773 0.33469 15.0346 -0.00443301 16.0212 4.37621e-05C17.0077 0.00452053 17.9619 0.352318 18.72 0.983718L21.2373 2.76719C21.3297 2.83266 21.3989 2.92585 21.4348 3.03327C21.4707 3.14069 21.4715 3.25675 21.4371 3.36465C21.4026 3.47254 21.3347 3.56667 21.2432 3.63338C21.1516 3.7001 21.0412 3.73594 20.928 3.73572H20.9285ZM0.880507 31.7144C0.770687 31.7146 0.663477 31.6809 0.573522 31.6179C0.483567 31.5549 0.415252 31.4657 0.377909 31.3624C0.340566 31.2591 0.336016 31.1468 0.364879 31.0409C0.393742 30.9349 0.454612 30.8405 0.539174 30.7704L12.7098 20.6584C12.7637 20.6136 12.8259 20.5799 12.8928 20.5592C12.9598 20.5385 13.0301 20.5311 13.0999 20.5376C13.1696 20.5441 13.2374 20.5642 13.2994 20.5969C13.3614 20.6295 13.4163 20.6741 13.461 20.728C13.5058 20.7819 13.5395 20.8441 13.5602 20.911C13.5809 20.9779 13.5883 21.0482 13.5818 21.118C13.5754 21.1878 13.5552 21.2556 13.5226 21.3175C13.4899 21.3795 13.4453 21.4344 13.3914 21.4792L1.22077 31.5912C1.12524 31.6708 1.00485 31.7144 0.880507 31.7144ZM31.12 31.7144C30.9956 31.7145 30.8752 31.6709 30.7797 31.5912L18.609 21.4792C18.5538 21.4349 18.5079 21.38 18.474 21.3178C18.4402 21.2556 18.4191 21.1872 18.4119 21.1167C18.4048 21.0463 18.4117 20.9751 18.4324 20.9073C18.4531 20.8396 18.4871 20.7766 18.5323 20.7221C18.5776 20.6676 18.6333 20.6227 18.6961 20.59C18.7589 20.5573 18.8276 20.5374 18.8982 20.5315C18.9688 20.5256 19.0399 20.5338 19.1073 20.5557C19.1746 20.5776 19.237 20.6127 19.2906 20.6589L31.4613 30.7709C31.5459 30.841 31.6067 30.9355 31.6356 31.0414C31.6645 31.1474 31.6599 31.2597 31.6226 31.3629C31.5852 31.4662 31.5169 31.5554 31.427 31.6184C31.337 31.6814 31.2298 31.7146 31.12 31.7144Z"></path>
                    <path d="M26.6672 15.1919C26.5258 15.1919 26.3901 15.1358 26.2901 15.0357C26.1901 14.9357 26.1339 14.8001 26.1339 14.6586V3.74021C26.1323 3.75088 26.1109 3.73595 26.0752 3.73595H5.92587C5.91421 3.73524 5.90252 3.73691 5.89152 3.74085C5.88052 3.7448 5.87043 3.75093 5.86187 3.75888L5.8672 14.6586C5.8672 14.8001 5.81101 14.9357 5.71099 15.0357C5.61097 15.1358 5.47532 15.1919 5.33387 15.1919C5.19242 15.1919 5.05677 15.1358 4.95675 15.0357C4.85673 14.9357 4.80054 14.8001 4.80054 14.6586V3.73595C4.80891 3.44547 4.93203 3.17014 5.14294 2.97023C5.35384 2.77032 5.63536 2.66211 5.92587 2.66928H26.0752C26.3657 2.66211 26.6472 2.77032 26.8581 2.97023C27.069 3.17014 27.1922 3.44547 27.2005 3.73595V14.6586C27.2005 14.8001 27.1443 14.9357 27.0443 15.0357C26.9443 15.1358 26.8087 15.1919 26.6672 15.1919Z"></path>
                </svg>
            </div>
            <div class="content">
                <span>To Send Mail</span>
                <h6><a href="mailto:info@gmail.com">info@gmail.com</a></h6>
            </div>
        </div>
            </div>

<!-- Fooer Center Menu -->
<div class="footer-btm-menu"><ul id="menu-footer-menu" class="ul"><li id="menu-item-299" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-299"><a href="#" class="active">Advertise With Us</a></li>
<li id="menu-item-300" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-300"><a href="#" class="active">Our Sitemap</a></li>
</ul></div>
</div>        


    
                    ?&gt;
        <div class="footer-btm ">
                                    <div class="copyright-area">
                    <p>Copyright 2023 <a href="#">DRIVCO</a> | Design By <a href="https://www.egenslab.com/">Egens Lab</a></p>
                </div>
            
                                    <div class="social-area">
                    <h6>Follow Drivco:</h6>
                                                    <ul>
                                                                        <li><a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a></li>
                                                                        <li><a href="https://twitter.com/"><i class="fab fa-twitter"></i></a></li>
                                                                        <li><a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a></li>
                                                                        <li><a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a></li>
                                                            </ul>
                                            </div>
                            </div>
    

</div>
</footer>
<!-- End Footer Section -->
<script type="text/javascript">
(function () {
    var c = document.body.className;
    c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
    document.body.className = c;
})();
</script>
<link rel="stylesheet" id="e-animations-css" href="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.17.3" type="text/css" media="all">
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0" id="jquery-selectBox-js"></script>
<script type="text/javascript" src="//www.drivco-wp.egenslab.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6" id="prettyPhoto-js" data-wp-strategy="defer"></script>
<script type="text/javascript" id="jquery-yith-wcwl-js-extra">
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","yith_wcwl_button_position":"after_add_to_cart","multi_wishlist":"","hide_add_button":"1","enable_ajax_loading":"","ajax_loader_url":"https:\/\/www.drivco-wp.egenslab.com\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader-alt.svg","remove_from_wishlist_after_add_to_cart":"1","is_wishlist_responsive":"1","time_to_close_prettyphoto":"3000","fragments_index_glue":".","reload_on_found_variation":"1","mobile_media_query":"768","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies on your browser are enabled.","added_to_cart_message":"<div class=\"woocommerce-notices-wrapper\"><div class=\"woocommerce-message\" role=\"alert\">Product added to cart successfully<\/div><\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem","load_mobile_action":"load_mobile","delete_item_action":"delete_item","save_title_action":"save_title","save_privacy_action":"save_privacy","load_fragments":"load_fragments"},"nonce":{"add_to_wishlist_nonce":"3b709a4103","remove_from_wishlist_nonce":"10fe13ec92","reload_wishlist_and_adding_elem_nonce":"4e06154737","load_mobile_nonce":"ea57f54a26","delete_item_nonce":"916b810c49","save_title_nonce":"9bfb68c964","save_privacy_nonce":"4f9f363227","load_fragments_nonce":"ddea3ff66a"},"redirect_after_ask_estimate":"","ask_estimate_redirect_url":"https:\/\/www.drivco-wp.egenslab.com"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.min.js?ver=3.27.0" id="jquery-yith-wcwl-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8.3" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.drivco-wp.egenslab.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8.3" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery-ui.js?ver=1699532534" id="jquery-ui-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/rangeSlider.min.js?ver=1699532534" id="range-slider-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/bootstrap.min.js?ver=1695285017" id="bootstrap-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6" id="swiper-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/slick.js?ver=1695285017" id="slick-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/waypoints.min.js?ver=1695285017" id="waypoints-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery.counterup.min.js?ver=1695285017" id="counterup-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/isotope.pkgd.min.js?ver=1695285017" id="isotope-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/datatable.js?ver=1698935724" id="datatable-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery.magnific-popup.min.js?ver=1695285017" id="magnific-popup-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/gsap.min.js?ver=1695285017" id="gsap-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/simpleParallax.min.js?ver=1695285017" id="simpleParallax-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/TweenMax.min.js?ver=1695285017" id="TweenMax-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery.marquee.min.js?ver=1695285017" id="marquee-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery.nice-select.min.js?ver=1695285017" id="nice-select-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/jquery.fancybox.min.js?ver=1695285017" id="fancybox-js"></script>
<script type="text/javascript" id="custom-js-extra">
/* <![CDATA[ */
var egns_localize = {"sticky_header_enable":"","animation_enable":"","is_egns_core_enable":"1","admin_ajax":"https:\/\/www.drivco-wp.egenslab.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/custom.js?ver=1701166065" id="custom-js"></script>
<script type="text/javascript" id="ajax-handler-js-extra">
/* <![CDATA[ */
var egens_ajax_handler_params = {"ajaxurl":"https:\/\/www.drivco-wp.egenslab.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/themes/drivco/assets/js/ajax-handler.js?ver=1698935724" id="ajax-handler-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.17.3" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.17.3" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.17.3" id="share-link-js"></script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.9.0" id="elementor-dialog-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
/* <![CDATA[ */
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselWrapperAriaLabel":"Carousel | Horizontal scrolling: Arrow Left & Right","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.17.3","is_static":false,"experimentalFeatures":{"container":true},"urls":{"assets":"https:\/\/www.drivco-wp.egenslab.com\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":18,"title":"Home%2002%20%E2%80%93%20Drivco","excerpt":"","featuredImage":false}};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.17.3" id="elementor-frontend-js"></script><span id="elementor-device-mode" class="elementor-screen-only"></span>
<script type="text/javascript" src="https://www.drivco-wp.egenslab.com/wp-content/plugins/elementor/assets/js/preloaded-modules.min.js?ver=3.17.3" id="preloaded-modules-js"></script><svg style="display: none;" class="e-font-icon-svg-symbols"></svg>


</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/index.blade.php ENDPATH**/ ?>