<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">Resume Template-1 Details</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                        <th>Sr. No</th>
                        <th>Full Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Pincode</th>
                        <th>Email Address</th>
                        <th>Number</th>
                        <th>Professional Summary</th>
                        <th>First Job Field</th>
                        <th>First Job Role</th>
                        <th>First Job City</th>
                        <th>First Job State</th>
                        <th>First Job Joining Date</th>
                        <th>Second Job Field</th>
                        <th>Second Job Role</th>
                        <th>Second Job City</th>
                        <th>Second Job State</th>
                        <th>Second Job Joining Date</th>
                        <th>School Name</th>
                        <th>School City</th>
                        <th>School State</th>
                        <th>10th PR</th>
                        <th>10th Passing Year</th>
                        <th>12th PR</th>
                        <th>12th Passing Year</th>
                        <th>College Name</th>
                        <th>College City</th>
                        <th>College State</th>
                        <th>Filed of Study</th>
                        <th>Degree</th>
                        <th>Skills 1</th>
                        <th>Skills 2</th>
                        <th>Skills 3</th>
                        <th>Skills 4</th>
                        <th>Skills 5</th>
                        <th>Hobby 1</th>
                        <th>Hobby 2</th>
                        <th>Hobby 3</th>
                        <th>Hobby 4</th>
                        <th>Hobby 5</th>
                        <th>Language 1</th>
                        <th>Language 2</th>
                        <th>Language 3</th>
                        <th>Language 4</th>
                        <th>Language 5</th>
                        <!-- <th>Edit</th> -->
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <!-- <td><?php echo e($in['id']); ?></td> -->
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($in['fullname']); ?></td>
                        <td><?php echo e($in['address']); ?></td>
                        <td><?php echo e($in['city']); ?></td>
                        <td><?php echo e($in['pincode']); ?></td>
                        <td><?php echo e($in['email']); ?></td>
                        <td><?php echo e($in['number']); ?></td>
                        <td><?php echo e($in['professionalsummary']); ?></td>
                        <td><?php echo e($in['firstjobfiled']); ?></td>
                        <td><?php echo e($in['firstyourrole']); ?></td>
                        <td><?php echo e($in['firstcity']); ?></td>
                        <td><?php echo e($in['firststate']); ?></td>
                        <td><?php echo e($in['firstdoj']); ?></td>
                        <td><?php echo e($in['secondjobfiled']); ?></td>
                        <td><?php echo e($in['secondyourrole']); ?></td>
                        <td><?php echo e($in['secondcity']); ?></td>
                        <td><?php echo e($in['secondstate']); ?></td>
                        <td><?php echo e($in['seconddoj']); ?></td>
                        <td><?php echo e($in['schoolname']); ?></td>
                        <td><?php echo e($in['schoolcity']); ?></td>
                        <td><?php echo e($in['schoolstate']); ?></td>
                        <td><?php echo e($in['xpr']); ?></td>
                        <td><?php echo e($in['passingyearx']); ?></td>
                        <td><?php echo e($in['xiipr']); ?></td>
                        <td><?php echo e($in['passingyearxii']); ?></td>
                        <td><?php echo e($in['collegename']); ?></td>
                        <td><?php echo e($in['collegecity']); ?></td>
                        <td><?php echo e($in['collegestate']); ?></td>
                        <td><?php echo e($in['fieldofstudy']); ?></td>
                        <td><?php echo e($in['degree']); ?></td>
                        <td><?php echo e($in['skill1']); ?></td>
                        <td><?php echo e($in['skill2']); ?></td>
                        <td><?php echo e($in['skill3']); ?></td>
                        <td><?php echo e($in['skill4']); ?></td>
                        <td><?php echo e($in['skill5']); ?></td>
                        <td><?php echo e($in['hobby1']); ?></td>
                        <td><?php echo e($in['hobby2']); ?></td>
                        <td><?php echo e($in['hobby3']); ?></td>
                        <td><?php echo e($in['hobby4']); ?></td>
                        <td><?php echo e($in['hobby5']); ?></td>
                        <td><?php echo e($in['language1']); ?></td>
                        <td><?php echo e($in['language2']); ?></td>
                        <td><?php echo e($in['language3']); ?></td>
                        <td><?php echo e($in['language4']); ?></td>
                        <td><?php echo e($in['language5']); ?></td>                        
                        <!-- <td><a href="EditResume/<?php echo e($in['id']); ?>">Edit</a></td> -->
                        <td><a href="Delete/<?php echo e($in['id']); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>
<?php /**PATH L:\Sem-4\Website\project\resources\views/search_resume1_data.blade.php ENDPATH**/ ?>