<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdminLogin</title>
    <link rel="stylesheet" href="<?php echo e(asset('adloginstyle.css')); ?>">
</head>
<body>
    <div class="container">
    <form method="get" action="">
        <?php echo csrf_field(); ?>
        <div class="text">
        <h1>Admin login</h1>
        </div>
        <div class="username">
        <span>Username</span><br>
        <input type="text" placeholder="Your Username" name="username"><br><br>
        <span>Password</span><br>
        <input type="password" placeholder="Your Password" name="password"><br>
        </div>
        <div class="submit">
        <a href="#">Login</a>
        </div>
    </form>
    </div>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/adminLogin.blade.php ENDPATH**/ ?>