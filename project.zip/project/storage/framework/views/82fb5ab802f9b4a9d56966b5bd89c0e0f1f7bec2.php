<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('resumetemp1.css')); ?>">
    <title>Resume Template 1</title>
</head>
<body>
    <?php if($info->isNotEmpty()): ?>
        <div class="container">
            <div class="title">
                <h1><?php echo e($info->last()['fname']); ?>'s Resume</h1>
                <hr>
            </div>
            <div class="personalinfo">
                <h1><?php echo e($info->last()['fname'].' '.$info->last()['lname']); ?></h1>
                <strong>Phone : </strong><?php echo e($info->last()['phone']); ?><br>
                <strong>Email : </strong><?php echo e($info->last()['email']); ?><br>
                <strong>Address : </strong><?php echo e($info->last()['address'].'-'.$info->last()['city']); ?><br><br>
                <h3>Professional Summary</h3>
                <hr><br>
                <p><?php echo e($info->last()['professionalsummary']); ?></p>
            </div><br>
            <h3>Employement History</h3>
            <hr><br>
            <div class="jobs">
                <div class="left">
                    <strong>Employer : </strong><?php echo e($info->last()['ename']); ?><br>
                    <strong>City : </strong><?php echo e($info->last()['ecity']); ?><br>
                    <strong>State : </strong><?php echo e($info->last()['jobstate']); ?><br>
                </div>
                <div class="right">
                    <strong>Job Title : </strong><?php echo e($info->last()['jobtitle']); ?><br>
                    <strong>Periods : </strong><?php echo e($info->last()['startdate'].' to '.$info->last()['enddate']); ?>

                </div>
            </div><br>
            <h3>Education</h3>
            <hr><br>
            <div class="education">
                <div class="left1">
                    <strong>Univercity/College Name : </strong><?php echo e($info->last()['sname']); ?><br>
                    <strong>City : </strong><?php echo e($info->last()['scity']); ?><br>
                    <strong>State : </strong><?php echo e($info->last()['schoolstate']); ?><br>
                </div>
                <div class="right1">
                    <strong>What i Study : </strong><?php echo e($info->last()['fos'].' to '.$info->last()['degreename']); ?><br>
                    <strong>Graduation Date : </strong><?php echo e($info->last()['graduationdate']); ?>

                </div>
            </div><br>
            <h3>Skills</h3>
            <hr><br>
            <div class="skills">
                <div class="left2">
                    <strong>Top Skill : </strong><?php echo e($info->last()['tskill']); ?><br>
                    <strong>Average Skill : </strong><?php echo e($info->last()['askill']); ?><br>
                    <strong>Law Skill : </strong><?php echo e($info->last()['lskill']); ?><br>
                </div>
                <div class="right2">
                    <strong>Top Skill Level : </strong><?php echo e($info->last()['topskilllevel']); ?><br>
                    <strong>Average Skill Level : </strong><?php echo e($info->last()['averageskilllevel']); ?><br>
                    <strong>Law Skill Level : </strong><?php echo e($info->last()['lawskilllevel']); ?><br>
                </div>
            </div>
            <div class="download">
                <a href="http://127.0.0.1:8000/ResumeTemp1" download="ResumeTemp1.pdf">Download Resume</a>
            </div>
         </div>
     <?php else: ?>
        <p>No data available</p>
    <?php endif; ?>
    <!-- <script>
        const downloadLinks = document.querySelectorAll('[data-download]');

        downloadLinks.forEach(button => {
            const id = button.dataset.download;
            const image = document.getElementById(id);
            const a = document.createElement("a");

            button.addEventListener("click",() => {
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            });
        });
    </script> -->
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/ResumeTemp1.blade.php ENDPATH**/ ?>