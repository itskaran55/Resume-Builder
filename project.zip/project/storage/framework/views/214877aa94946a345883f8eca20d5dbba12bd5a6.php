<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Templates</title>
    <link rel="stylesheet" href="<?php echo e(asset('resumetemplatestyle.css')); ?>">
</head>
<body>
    <h1 style="color: white;">Resume Templates</h1>
    <div class="container">
        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="main">
            <p><img style="height: 500px; width:340px;" src="<?php echo e(asset('storage/images/'.$img->templatename)); ?>"></p>
            <!-- <p><?php echo e(asset('storage/images/'.$img->templatename)); ?></p> -->

            <!-- <td><a href="Edit/<?php echo e($img['id']); ?>">Edit</a></td> -->
            <td><a href="Delete/<?php echo e($img['id']); ?>">Delete</a></td>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/resumetemplates.blade.php ENDPATH**/ ?>