<!-- resources/views/resumetemplates/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1 style="color: white;">Resume Templates</h1>
    <div class="container">
        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="main">
                <a href="<?php echo e(route('template.show', ['id' => $img->id])); ?>">
                    <img style="height: 200px; width:200px;" src="<?php echo e(asset('storage/images/'.$img->templatename)); ?>">
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\Sem-4\Website\project\resources\views/show.blade.php ENDPATH**/ ?>