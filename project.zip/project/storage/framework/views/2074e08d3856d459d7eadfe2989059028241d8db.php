<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">Resume Details</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                   
                        <th>Sr. No</th>
                        <th>First Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Email Address</th>
                        <th>Professional Summary</th>
                        <th>Last Name</th>
                        <th>Country</th>
                        <th>Phone</th>
                        <th>School Name</th>
                        <th>School State</th>
                        <th>Filed of Study</th>
                        <th>School City</th>
                        <th>Degree Name</th>
                        <th>Graduation Date</th>
                        <th>Top Skill</th>
                        <th>Average Skill</th>
                        <th>Law Skill</th>
                        <th>Top Skill Level</th>
                        <th>Average Skill Level</th>
                        <th>Law Skill Level</th>
                        <th>Employer</th>
                        <th>City</th>
                        <th>Start Date</th>
                        <th>Job Title</th>
                        <th>Job State</th>
                        <th>End Date</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <!-- <td><?php echo e($in['id']); ?></td> -->
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($in['fname']); ?></td>
                        <!-- <td><h5><?php echo e($in['fname']); ?> <?php echo e($in[ 'lname']); ?><h5><//td> -->
                        <td><?php echo e($in['address']); ?></td>
                        <td><?php echo e($in['city']); ?></td>
                        <td><?php echo e($in['email']); ?></td>
                        <td><?php echo e($in['professionalsummary']); ?></td>
                        <td><?php echo e($in['lname']); ?></td>
                        <td><?php echo e($in['country']); ?></td>
                        <td><?php echo e($in['phone']); ?></td>
                        <td><?php echo e($in['sname']); ?></td>
                        <td><?php echo e($in['schoolstate']); ?></td>
                        <td><?php echo e($in['fos']); ?></td>
                        <td><?php echo e($in['scity']); ?></td>
                        <td><?php echo e($in['degreename']); ?></td>
                        <td><?php echo e($in['graduationdate']); ?></td>
                        <td><?php echo e($in['tskill']); ?></td>
                        <td><?php echo e($in['askill']); ?></td>
                        <td><?php echo e($in['lskill']); ?></td>
                        <td><?php echo e($in['topskilllevel']); ?></td>
                        <td><?php echo e($in['averageskilllevel']); ?></td>
                        <td><?php echo e($in['lawskilllevel']); ?></td>
                        <td><?php echo e($in['ename']); ?></td>
                        <td><?php echo e($in['city']); ?></td>
                        <td><?php echo e($in['startdate']); ?></td>
                        <td><?php echo e($in['jobtitle']); ?></td>
                        <td><?php echo e($in['jobstate']); ?></td>
                        <td><?php echo e($in['enddate']); ?></td>
                        <td><a href="EditResume/<?php echo e($in['id']); ?>">Edit</a></td>
                        <td><a href="Delete/<?php echo e($in['id']); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <!-- <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <td><h5><?php echo e($in['fname']); ?> <?php echo e($in[ 'lname']); ?><h5></td>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
        </section>
    </main>
</body>
</html>
<?php /**PATH L:\Sem-4\Website\project\resources\views/search_resume_data.blade.php ENDPATH**/ ?>