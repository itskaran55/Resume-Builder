<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Data</title>
    <link rel="stylesheet" href="registration_data.css">
</head>
<body>
    <main class="table">
        <section class="table_header">
            <h1 style="text-align: center;">User Registration Data</h1>
        </section>
        <section class="table_body">
            <table>
                <thead>
                    <tr>
                        <th>Sr. No</th>
                        <th>Full Name</th>
                        <th>Username</th>
                        <th>Password</th>
                        <!-- <th>Confirm Password</th> -->
                        <th>Role</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <!-- <td><?php echo e($in['id']); ?></td> -->
                        <td><?php echo e($in['fullname']); ?></td>
                        <td><strong><?php echo e($in['username']); ?></strong></td>
                        <td><?php echo e($in['password']); ?></td>
                        <!-- <td><?php echo e($in['cpassword']); ?></td> -->
                        <td><?php echo e($in['role']); ?></td>
                        <td><a href="Edit/<?php echo e($in['id']); ?>">Edit</a></td>
                        <td><a href="Delete/<?php echo e($in['id']); ?>">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>




<?php /**PATH L:\Sem-4\Website\project\resources\views/search_registration_data.blade.php ENDPATH**/ ?>