<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="<?php echo e(asset('userLogin.css')); ?>">
</head>
<body>
    <section>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
            
        <form action="/edit" method="post" class="login">
        <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>
            <div class="content">
                <h2>Update Form</h2>
                <div class="form">
                    <div class="inputBx">
                        <input type="hidden" required name="id" value="<?php echo e($data['id']); ?>">    
                        <!-- <i>Id</i> -->
                    </div>
                    <div class="inputBx">
                        <input type="text" required name="fullname" value="<?php echo e($data['fullname']); ?>">    
                        <i>FullName</i>
                    </div>
                    <div class="inputBx">
                        <input type="text" required name="username" value="<?php echo e($data['username']); ?>">    
                        <i>Username</i>
                    </div>
                    <!-- <div class="inputBx">
                        <input type="Password" name="password" value="<?php echo e($data['password']); ?>">    
                        <i>Password</i>
                    </div> -->
                    <div class="inputBx">
                        <input type="submit" value="Edit" name="Edit">
                    </div>
                </div>
            </div>
        </form>
        </div>
    </section>
</body>
</html>




<!-- <form action="/edit" method="post" >
<?php echo e(method_field('PUT')); ?>

    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($data['id']); ?>"/><br>
    Name:<input type="text" name="name" value="<?php echo e($data['fullname']); ?>"/><br>
    Username:<input type="text" name="name" value="<?php echo e($data['username']); ?>"/><br>
    Password:<input type="password" name="password" value="<?php echo e($data['password']); ?>"/><br>
    <input type="submit" name="Edit" value="Edit"/><br>
</form> --><?php /**PATH L:\Sem-4\Website\project\resources\views/editloginData.blade.php ENDPATH**/ ?>