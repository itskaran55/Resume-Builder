<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Template 1</title>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Hedvig+Letters+Serif:opsz@12..24&family=Mooli&family=Nunito+Sans:opsz,wght@6..12,300&family=Poppins:wght@300;500&display=swap');
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            text-decoration: none;
            list-style: none;
        }
        body
        {
            background-color: rgba(28, 29, 47, 0.92);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container
        {
            z-index: 2;
            height: 120vh;
            width: 650px;
            border: 2px solid black;
            padding: 15px 22px;
            background: rgba(211, 211, 211, 0.11);
            box-shadow: 2px 2px 30px rgba(0, 0, 0, 0.5),
                        -2px -2px 30px rgba(0, 0, 0, 0.5);
            transition: 0.5s; 
            color: white;
        }

    </style>
</head>
<body>
    <?php if($info->isNotEmpty()): ?>
        <div class="container">
            <div class="personalinfo">
                
            </div>
        </div>
    <?php else: ?>
    <p>No data available</p>
    <?php endif; ?>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/Resume Template 1.blade.php ENDPATH**/ ?>