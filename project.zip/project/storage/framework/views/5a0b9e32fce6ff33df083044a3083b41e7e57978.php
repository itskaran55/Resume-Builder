<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="secondadmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <section class="page1">
        <div class="conatainer">
            <div class="side-bar">
                <div class="user">
                <?php 
                    if(session()->has('username'))
                    {
                ?>
                    <li class="nav-item">
                        <a class="nav-link" style="color: black; font-weight:bold;">Hello, <?php echo e(session('username')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout" style="color: black;">Home</a>
                    </li>
                <?php
                }
                    else
                {
                ?>
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="userLogin" style="color: white;">Login</a> -->
                    </li>
                    <?php
                        }
                    ?>
                </div>
                <div class="menubar">
                    <div class="item"><a href="" class="active"><i class="fas fa-desktop"></i>Desktop</a></div>
                    <div class="item" id = "table"><i class="fas fa-table"></i>Tables
                        <i class="fas fa-angle-right dropdown"></i>
                    
                        <div class="sub-menu">
                            <a href="" class="sub-item">Registration Data</a>
                            <a href="" class="sub-item">Resume Data</a>
                        </div>
                    </div>
                    <div class="item"><a href=""><i class="fas fa-file"></i>Resume Templates</a></div>
                    <div class="item"><a href=""><i class="fas fa-user"></i>Public</a></div>
                    <div class="item"><a href=""><i class="fas fa-gear"></i>Setting</a></div>
                </div>
            </div>
        </div>
    </section>
    <script>
        let TableClicked = document.querySelector('#table');
        let subMenu = document.querySelector('.sub-menu');
        // let btn = document.querySelector('.fas fa-angle-right dropdown')
    
        TableClicked.addEventListener('click',() => {
            console.log("Table Clicked");
            subMenu.classList.toggle('visible');
            // Toggle the arrow icon
            let dropdownIcon = TableClicked.querySelector('.fas.fa-angle-right.dropdown');
                dropdownIcon.classList.toggle('rotate');
        });
    </script>
</body>
</html>

<!-- <script>
        let TableClicked = document.querySelector('#table');
        let subMenu = document.querySelector('.sub-menu')
    
        TableClicked.addEventListener('click',() => {
            console.log("Table Clicked");
            // event.preventDefault();
            let subMenuStyle = window.getComputedStyle(subMenu);
            if(subMenu.style.display === "none"){
                subMenu.style.display = "block";
            }
            else{
                subMenu.style.display = "none";
            }
        });
    </script> --><?php /**PATH L:\Sem-4\Website\project\resources\views/AdminPage.blade.php ENDPATH**/ ?>