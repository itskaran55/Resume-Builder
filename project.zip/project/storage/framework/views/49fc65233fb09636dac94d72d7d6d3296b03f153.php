<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Template Upload</title>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Hedvig+Letters+Serif:opsz@12..24&family=Mooli&family=Nunito+Sans:opsz,wght@6..12,300&family=Poppins:wght@300;500&display=swap');
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            text-decoration: none;
            list-style: none;
        }
        body
        {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: rgba(28, 29, 47, 0.92);
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            color: white;
        }
        body::before
        {
            content: "";
            height: 200px;
            width: 200px;
            border-radius: 50%;
            background: linear-gradient(rgba(156, 48, 19, 0.6),rgba(138, 17, 186, 0.305));
            position: absolute;
            top: 50%;
            left: 30%;
            transition: 0.5s;
            animation: rotate 1s infinite;
        }
        body::after
        {
            content: "";
            height: 200px;
            width: 200px;
            border-radius: 50%;
            background: linear-gradient(rgba(156, 48, 19, 0.6),rgba(138, 17, 186, 0.305));
            position: absolute;
            bottom: 50%;
            right: 30%;
            transition: 0.5s;
            animation: rotate 1s infinite;
        }
        .container
        {
            height: 350px;
            width: 550px;
            background-color: rgba(0, 0, 0, 0.135);
            box-shadow: 0px 2px 18px black;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            transition: 0.5s;
            z-index: 2;
        }
        .container:hover
        {
            backdrop-filter: blur(15px);
            box-shadow: 0px 2px 28px black;
        }
        @keyframes  rotate{
            0%{
                transform: rotate(0deg);
                /* right: 30%; */
                /* transform: translate(20%, 30%, 40%, 50%); */
            }
            50%{
                /* bottom: 23%; */
                /* transform: translate(-50%, -30%, -40%, -50%); */
                transform: rotate(180deg);
            }
            100%{
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="username">
        <?php 
                    if(session()->has('username'))
                    {
                ?>
                    <li class="nav-item">
                        <h1><a class="nav-link" style="color: White; font-weight:bold;">Hello, <?php echo e(session('username')); ?></a></h1>
                    </li>
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="logout" style="color: White;">Logout</a> -->
                    </li>
                <?php
                }
                    else
                {
                ?>
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="userLogin" style="color: white;">Login</a> -->
                    </li>
                    <?php
                        }
                    ?>
        </div><br>
        <div class="text">
            <h2>Enter Resume Templates</h2>
        </div><br>
        <div class="form">
            <form action="/ResumeTemplateUpload" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                Resume Template Name : <input type="text" style="padding: 5px 10px;" placeholder="Enter template name" name="templatename"><br><br>
                Resume Template Upload : <input type="file" name="image" >
                <input type="submit" name="Upload" value="Add" style="padding: 7px 10px;">
            </form>
        </div>
    </div>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/ResumeTemplateUpload.blade.php ENDPATH**/ ?>