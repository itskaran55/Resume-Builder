<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin.css')); ?>">
</head>
<body>
    <section class="first">
         <div class="container">
            <div class="header">
                <div class="logo">
                    <h1><a href="adminDashboard">Admin Dashboard</a></h1>
                </div>
                <div class="links">
                    <ul>
                        <li><a href="search_registration_data">Users Registration Data</a></li>
                        <li><a href="search_resume_data">Users Resume Details</a></li>
                        <li><a href="ResumeTemplateUpload">Resume Templates</a></li>
                        <?php 
                    if(session()->has('username'))
                    {
                ?>
                    <li class="nav-item">
                        <a class="nav-link" style="color: White; font-weight:bold;">Hello, <?php echo e(session('username')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout" style="color: White;">Logout</a>
                    </li>
                <?php
                }
                    else
                {
                ?>
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="userLogin" style="color: white;">Login</a> -->
                    </li>
                    <?php
                        }
                    ?>
                    </ul>
                </div>
            </div>
            <div class="main">
                <div class="text">
                    <h1>Welcome to Admin Panel</h1>
                    <h1>Hello I am,</h1>
                    <h1>Admin</h1>
                </div>
                <div class="admin">
                    <img src="admin2.png">
                </div>
            </div>
    </section>
</body>
</html><?php /**PATH L:\Sem-4\Website\project\resources\views/adminDashboard.blade.php ENDPATH**/ ?>